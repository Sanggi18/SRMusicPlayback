package com.sr.music

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.sr.music.core.navigation.Screen
import com.sr.music.data.dummy.DummyData
import com.sr.music.feature.album.AlbumViewModel
import com.sr.music.feature.artist.ArtistViewModel
import com.sr.music.feature.equalizer.EqualizerViewModel
import com.sr.music.feature.folder.FolderViewModel
import com.sr.music.feature.home.HomeViewModel
import com.sr.music.feature.lyrics.LyricsViewModel
import com.sr.music.feature.player.PlayerViewModel
import com.sr.music.feature.settings.SettingsViewModel
import com.sr.music.feature.song.SongViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SRMusic", appName)
    }

    @Test
    fun `activity launches and survives recreation`() {
        val activityController = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = activityController.get()
        assertNotNull(activity)

        // Simulate Activity recreation (rotation / config change)
        activityController.recreate()
        assertNotNull(activityController.get())
    }

    @Test
    fun `all view models initialize safely without crash`() {
        val homeVm = HomeViewModel()
        assertNotNull(homeVm.uiState.value)

        val playerVm = PlayerViewModel()
        assertNotNull(playerVm.uiState.value)
        assertTrue(playerVm.uiState.value.queue.isNotEmpty())

        val artistVm = ArtistViewModel()
        assertNotNull(artistVm.uiState.value)

        val albumVm = AlbumViewModel()
        assertNotNull(albumVm.uiState.value)

        val songVm = SongViewModel()
        assertNotNull(songVm.uiState.value)

        val folderVm = FolderViewModel()
        assertNotNull(folderVm.uiState.value)

        val eqVm = EqualizerViewModel()
        assertNotNull(eqVm.uiState.value)

        val lyricsVm = LyricsViewModel()
        assertNotNull(lyricsVm.uiState.value)

        val settingsVm = SettingsViewModel()
        assertNotNull(settingsVm.uiState.value)
    }

    @Test
    fun `navigation routes are valid and unique`() {
        val routes = listOf(
            Screen.Home.route,
            Screen.Artist.route,
            Screen.Album.route,
            Screen.Song.route,
            Screen.Folder.route,
            Screen.NowPlaying.route,
            Screen.Equalizer.route,
            Screen.Lyrics.route,
            Screen.Settings.route,
            Screen.SettingsTheme.route,
            Screen.SettingsNavigation.route,
            Screen.SettingsAudio.route,
            Screen.SettingsLibrary.route,
            Screen.SettingsApp.route
        )
        assertEquals(routes.size, routes.distinct().size)
    }

    @Test
    fun `accent color system resolves primary correctly without changing background`() {
        val lightPurple = com.sr.music.core.theme.ThemePalette.buildLight(com.sr.music.core.theme.AccentColor.PURPLE)
        val lightBlue = com.sr.music.core.theme.ThemePalette.buildLight(com.sr.music.core.theme.AccentColor.BLUE)

        // Primary changes with accent
        assertEquals(com.sr.music.core.theme.AccentPalettes.PurpleLight.primary, lightPurple.primary)
        assertEquals(com.sr.music.core.theme.AccentPalettes.BlueLight.primary, lightBlue.primary)

        // Background remains identical light background
        assertEquals(lightPurple.background, lightBlue.background)

        // Dark + Pink
        val darkPink = com.sr.music.core.theme.ThemePalette.buildDark(com.sr.music.core.theme.AccentColor.PINK)
        assertEquals(com.sr.music.core.theme.AccentPalettes.PinkDark.primary, darkPink.primary)

        // AMOLED produces pure #000000 black background
        val amoledScheme = com.sr.music.core.theme.ThemePalette.buildAmoled(com.sr.music.core.theme.AccentColor.TEAL)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF000000), amoledScheme.background)
    }
}
