package com.sr.music.feature.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sr.music.SRMusicApplication
import com.sr.music.domain.model.Folder
import com.sr.music.domain.model.Song
import com.sr.music.domain.repository.MusicRepository
import com.sr.music.playback.MediaControllerManager
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class PlayerViewModel(
    private val repository: MusicRepository = SRMusicApplication.musicRepository,
    private val controllerManager: MediaControllerManager = MediaControllerManager.getInstance(SRMusicApplication.instance)
) : ViewModel() {

    val uiState: StateFlow<PlayerUiState> = controllerManager.uiState

    fun playSongs(songs: List<Song>, startIndex: Int = 0, startPositionMs: Long = 0L) {
        controllerManager.playSongs(songs, startIndex, startPositionMs)
        val song = songs.getOrNull(startIndex) ?: return
        viewModelScope.launch {
            repository.updatePlayCount(song.id)
        }
    }

    fun playSong(song: Song) {
        controllerManager.playSong(song)
        viewModelScope.launch {
            repository.updatePlayCount(song.id)
        }
    }

    fun togglePlayPause() {
        controllerManager.togglePlayPause()
    }

    fun resumePlayback() {
        controllerManager.play()
    }

    fun pausePlayback() {
        controllerManager.pause()
    }

    fun dismissMiniPlayerOnSwipe() {
        controllerManager.dismissMiniPlayer()
    }

    fun playNext() {
        controllerManager.playNext()
    }

    fun playPrevious() {
        controllerManager.playPrevious()
    }

    fun seekTo(positionMs: Long) {
        controllerManager.seekTo(positionMs)
    }

    fun toggleShuffle() {
        controllerManager.toggleShuffle()
    }

    fun toggleRepeat() {
        controllerManager.toggleRepeat()
    }

    fun toggleFavorite() {
        val currentSong = uiState.value.currentSong ?: return
        val newFav = !uiState.value.isFavorite
        controllerManager.setFavorite(newFav)
        viewModelScope.launch {
            repository.toggleFavorite(currentSong.id)
        }
    }

    fun addToQueue(song: Song) {
        controllerManager.addToQueue(song)
    }

    fun insertNextInQueue(song: Song) {
        controllerManager.insertNextInQueue(song)
    }

    fun removeFromQueue(songId: String) {
        controllerManager.removeFromQueue(songId)
    }

    fun playFolder(folder: Folder) {
        viewModelScope.launch {
            val songsInFolder = repository.getSongsByFolder(folder.path).firstOrNull() ?: emptyList()
            if (songsInFolder.isNotEmpty()) {
                playSongs(songsInFolder, 0, 0L)
            }
        }
    }

    fun insertFolderNext(folder: Folder) {
        viewModelScope.launch {
            val songsInFolder = repository.getSongsByFolder(folder.path).firstOrNull() ?: emptyList()
            songsInFolder.reversed().forEach { song ->
                controllerManager.insertNextInQueue(song)
            }
        }
    }

    fun addFolderToQueue(folder: Folder) {
        viewModelScope.launch {
            val songsInFolder = repository.getSongsByFolder(folder.path).firstOrNull() ?: emptyList()
            songsInFolder.forEach { song ->
                controllerManager.addToQueue(song)
            }
        }
    }

    fun deleteSong(song: Song) {
        viewModelScope.launch {
            repository.deleteSong(song.id)
        }
        controllerManager.removeFromQueue(song.id)
    }

    fun stopPlayback() {
        controllerManager.pause()
    }

    fun dismissPlayer() {
        controllerManager.dismissMiniPlayer()
    }
}
