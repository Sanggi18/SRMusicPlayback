package com.sr.music.feature.home

import com.sr.music.domain.model.Album
import com.sr.music.domain.model.Artist
import com.sr.music.domain.model.LibraryState
import com.sr.music.domain.model.Song

data class HomeUiState(
    val libraryState: LibraryState = LibraryState.Loading,
    val recentArtists: List<Artist> = emptyList(),
    val recentAlbums: List<Album> = emptyList(),
    val recentTracks: List<Song> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = false
)
