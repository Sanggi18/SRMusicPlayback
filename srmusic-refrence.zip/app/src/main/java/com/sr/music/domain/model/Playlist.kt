package com.sr.music.domain.model

data class Playlist(
    val id: String,
    val name: String,
    val songCount: Int,
    val artworkUrl: String? = null
)
