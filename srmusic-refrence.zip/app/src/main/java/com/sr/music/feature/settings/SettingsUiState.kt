package com.sr.music.feature.settings

import com.sr.music.core.theme.ThemeMode
import com.sr.music.domain.model.AppSettings

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val appVersion: String = "1.0.0 (Phase 1 UI Foundation)"
)
