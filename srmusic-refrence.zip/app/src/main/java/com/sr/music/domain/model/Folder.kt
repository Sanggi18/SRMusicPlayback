package com.sr.music.domain.model

data class Folder(
    val id: String,
    val name: String,
    val path: String,
    val songCount: Int,
    val parentPath: String? = null
)
