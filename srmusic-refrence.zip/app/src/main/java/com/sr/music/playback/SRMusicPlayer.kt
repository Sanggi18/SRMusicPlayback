package com.sr.music.playback

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/**
 * SRMusicPlayer adapts the core AyraMusic player model for SRMusic.
 * It manages an underlying ExoPlayer with proper audio attributes, audio focus,
 * becoming-noisy handling, and background wake lock while exposing the Media3 Player interface.
 */
class SRMusicPlayer(
    context: Context,
    private val exoPlayer: ExoPlayer = buildExoPlayer(context)
) : ForwardingPlayer(exoPlayer) {

    companion object {
        private fun buildExoPlayer(context: Context): ExoPlayer {
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build()

            return ExoPlayer.Builder(context)
                .setAudioAttributes(audioAttributes, true)
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .build()
        }
    }

    val wrappedPlayer: ExoPlayer
        get() = exoPlayer

    fun releasePlayer() {
        exoPlayer.release()
    }
}
