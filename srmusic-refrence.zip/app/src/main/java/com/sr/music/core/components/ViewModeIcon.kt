package com.sr.music.core.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Renders an accurate visual representation icon for:
 * 1: List mode
 * 2: 2-column Grid mode
 * 3: 3-column Grid mode
 * 4: 4-column Grid mode
 */
@Composable
fun ViewModeIcon(
    columns: Int,
    modifier: Modifier = Modifier.size(22.dp),
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        when (columns) {
            1 -> {
                // List mode: 3 horizontal rows with box on left + bar on right
                val rowHeight = h / 4.2f
                val spacing = h / 9f
                for (i in 0..2) {
                    val y = i * (rowHeight + spacing) + spacing * 0.4f
                    // left square / thumbnail
                    drawRoundRect(
                        color = tint,
                        topLeft = Offset(0f, y),
                        size = Size(rowHeight, rowHeight),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                    // right content bar
                    val barX = rowHeight + 4.dp.toPx()
                    drawRoundRect(
                        color = tint,
                        topLeft = Offset(barX, y + rowHeight * 0.25f),
                        size = Size((w - barX).coerceAtLeast(0f), rowHeight * 0.5f),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                }
            }
            2 -> {
                // 2-column mode: 2x2 grid
                val gap = 3.dp.toPx()
                val cellSize = (w - gap) / 2f
                for (r in 0..1) {
                    for (c in 0..1) {
                        drawRoundRect(
                            color = tint,
                            topLeft = Offset(c * (cellSize + gap), r * (cellSize + gap)),
                            size = Size(cellSize, cellSize),
                            cornerRadius = CornerRadius(2.5.dp.toPx(), 2.5.dp.toPx())
                        )
                    }
                }
            }
            3 -> {
                // 3-column mode: 3x2 grid
                val gap = 2.dp.toPx()
                val cellW = (w - 2 * gap) / 3f
                val cellH = (h - gap) / 2f
                for (r in 0..1) {
                    for (c in 0..2) {
                        drawRoundRect(
                            color = tint,
                            topLeft = Offset(c * (cellW + gap), r * (cellH + gap)),
                            size = Size(cellW, cellH),
                            cornerRadius = CornerRadius(1.5.dp.toPx(), 1.5.dp.toPx())
                        )
                    }
                }
            }
            else -> {
                // 4-column mode: 4x2 grid
                val gap = 1.5.dp.toPx()
                val cellW = (w - 3 * gap) / 4f
                val cellH = (h - gap) / 2f
                for (r in 0..1) {
                    for (c in 0..3) {
                        drawRoundRect(
                            color = tint,
                            topLeft = Offset(c * (cellW + gap), r * (cellH + gap)),
                            size = Size(cellW, cellH),
                            cornerRadius = CornerRadius(1.dp.toPx(), 1.dp.toPx())
                        )
                    }
                }
            }
        }
    }
}
