package com.sr.music.domain.model

data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val year: Int? = null,
    val songCount: Int = 0,
    val artworkUrl: String? = null
)
