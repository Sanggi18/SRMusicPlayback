package com.sr.music.feature.folder

import com.sr.music.core.components.SortOption
import com.sr.music.domain.model.Folder

data class FolderUiState(
    val folders: List<Folder> = emptyList(),
    val searchQuery: String = "",
    val sortOption: SortOption = SortOption.NAME,
    val isAscending: Boolean = true,
    val isLoading: Boolean = false
)
