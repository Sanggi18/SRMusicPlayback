package com.sr.music.feature.folder

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sr.music.SRMusicApplication
import com.sr.music.core.components.SortOption
import com.sr.music.domain.model.Folder
import com.sr.music.domain.repository.MusicRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class FolderViewModel(
    private val repository: MusicRepository = SRMusicApplication.musicRepository
) : ViewModel() {

    private var rawFolders: List<Folder> = emptyList()
    private val _uiState = MutableStateFlow(FolderUiState())
    val uiState: StateFlow<FolderUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.folders.collectLatest { folderList ->
                rawFolders = folderList
                applyFilterAndSort()
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        applyFilterAndSort()
    }

    fun updateSort(option: SortOption) {
        _uiState.update { it.copy(sortOption = option) }
        applyFilterAndSort()
    }

    fun toggleAscending() {
        _uiState.update { it.copy(isAscending = !it.isAscending) }
        applyFilterAndSort()
    }

    private fun applyFilterAndSort() {
        val query = _uiState.value.searchQuery
        val sort = _uiState.value.sortOption
        val isAsc = _uiState.value.isAscending

        var list = if (query.isBlank()) {
            rawFolders
        } else {
            rawFolders.filter { it.name.contains(query, ignoreCase = true) }
        }

        list = when (sort) {
            SortOption.NAME -> if (isAsc) list.sortedBy { it.name } else list.sortedByDescending { it.name }
            SortOption.SONG_COUNT -> if (isAsc) list.sortedBy { it.songCount } else list.sortedByDescending { it.songCount }
            else -> list
        }

        _uiState.update { it.copy(folders = list) }
    }
}
