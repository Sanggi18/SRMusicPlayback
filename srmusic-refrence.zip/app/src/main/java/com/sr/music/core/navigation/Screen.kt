package com.sr.music.core.navigation

import com.sr.music.core.utils.Constants

sealed class Screen(val route: String) {
    data object Home : Screen(Constants.ROUTE_HOME)
    data object Artist : Screen(Constants.ROUTE_ARTIST)
    data object Album : Screen(Constants.ROUTE_ALBUM)
    data object Song : Screen(Constants.ROUTE_SONG)
    data object Folder : Screen(Constants.ROUTE_FOLDER)
    data object NowPlaying : Screen(Constants.ROUTE_NOW_PLAYING)
    data object Equalizer : Screen(Constants.ROUTE_EQUALIZER)
    data object Lyrics : Screen(Constants.ROUTE_LYRICS)
    data object Settings : Screen(Constants.ROUTE_SETTINGS)

    // Settings Nested Screens
    data object SettingsAppearance : Screen(Constants.ROUTE_SETTINGS_APPEARANCE)
    data object SettingsTheme : Screen(Constants.ROUTE_SETTINGS_THEME)
    data object SettingsCustomThemes : Screen(Constants.ROUTE_SETTINGS_CUSTOM_THEMES)
    data object SettingsFontStyle : Screen(Constants.ROUTE_SETTINGS_FONT_STYLE)
    data object SettingsNavigation : Screen(Constants.ROUTE_SETTINGS_NAVIGATION)
    data object SettingsAudio : Screen(Constants.ROUTE_SETTINGS_AUDIO)
    data object SettingsLibrary : Screen(Constants.ROUTE_SETTINGS_LIBRARY)
    data object SettingsApp : Screen(Constants.ROUTE_SETTINGS_APP)
    data object SettingsAppCredits : Screen(Constants.ROUTE_SETTINGS_APP_CREDITS)
    data object SettingsAppSupport : Screen(Constants.ROUTE_SETTINGS_APP_SUPPORT)
    data object SettingsAppInfo : Screen(Constants.ROUTE_SETTINGS_APP_INFO)
    data object SettingsAppChangelog : Screen(Constants.ROUTE_SETTINGS_APP_CHANGELOG)

    data object AlbumDetail : Screen(Constants.ROUTE_ALBUM_DETAIL) {
        fun createRoute(albumId: String) = "album_detail/$albumId"
    }
    data object ArtistDetail : Screen(Constants.ROUTE_ARTIST_DETAIL) {
        fun createRoute(artistId: String) = "artist_detail/$artistId"
    }
    data object FolderDetail : Screen(Constants.ROUTE_FOLDER_DETAIL) {
        fun createRoute(folderId: String) = "folder_detail/$folderId"
    }
}
