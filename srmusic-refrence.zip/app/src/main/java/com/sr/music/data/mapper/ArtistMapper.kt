package com.sr.music.data.mapper

import com.sr.music.data.local.entity.ArtistEntity
import com.sr.music.domain.model.Artist

fun ArtistEntity.toDomainModel(): Artist {
    return Artist(
        id = id,
        name = name,
        songCount = songCount,
        albumCount = albumCount,
        artworkUrl = artworkUrl
    )
}
