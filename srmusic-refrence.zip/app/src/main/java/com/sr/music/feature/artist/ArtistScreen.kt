package com.sr.music.feature.artist

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.sr.music.core.components.ArtistItem
import com.sr.music.core.components.EmptyState
import com.sr.music.core.components.SearchPill
import com.sr.music.core.components.SortBar
import com.sr.music.core.components.SortOption
import com.sr.music.core.components.VerticalAlphabetIndex
import com.sr.music.core.components.VerticalFastGridScrollBar
import com.sr.music.core.components.VerticalFastScrollBar
import com.sr.music.core.components.ViewModeIcon
import com.sr.music.domain.model.Artist
import kotlinx.coroutines.launch

@Composable
fun ArtistScreen(
    viewModel: ArtistViewModel,
    onArtistClick: (Artist) -> Unit,
    onMenuClick: () -> Unit = {},
    onNavigateToEqualizer: () -> Unit,
    onNavigateToLyrics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    val artistNames = remember(uiState.artists) {
        uiState.artists.map { it.name }
    }

    val letterIndexMap = remember(uiState.artists) {
        val map = mutableMapOf<String, Int>()
        uiState.artists.forEachIndexed { index, artist ->
            val target = artist.name.trim()
            val firstChar = target.firstOrNull()
            val letterKey = when {
                firstChar == null -> "#"
                firstChar.uppercaseChar() in 'A'..'Z' -> firstChar.uppercaseChar().toString()
                firstChar.isDigit() || (!firstChar.isLetter() && firstChar.code < 0x2E80) -> "#"
                else -> firstChar.toString()
            }
            if (!map.containsKey(letterKey)) {
                map[letterKey] = index
            }
        }
        map
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("artist_screen")
    ) {
        SearchPill(
            searchQuery = uiState.searchQuery,
            onQueryChange = viewModel::updateSearchQuery,
            placeholder = "Search artists...",
            onMenuClick = onMenuClick
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                SortBar(
                    currentSort = uiState.sortOption,
                    isAscending = uiState.isAscending,
                    onSortChange = viewModel::updateSort,
                    onToggleAscending = viewModel::toggleAscending,
                    availableOptions = listOf(SortOption.TITLE, SortOption.SONG_COUNT, SortOption.DATE_ADDED)
                )
            }

            IconButton(
                onClick = {
                    val nextCols = if (uiState.gridColumns >= 4) 1 else uiState.gridColumns + 1
                    viewModel.setGridColumns(nextCols)
                },
                modifier = Modifier.testTag("artist_grid_toggle")
            ) {
                ViewModeIcon(
                    columns = uiState.gridColumns,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (uiState.artists.isEmpty()) {
            EmptyState(
                title = "No artists found",
                subtitle = "No artists match your search query"
            )
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                if (uiState.gridColumns == 1) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 0.dp,
                            end = 24.dp,
                            top = 0.dp,
                            bottom = 90.dp
                        )
                    ) {
                        items(uiState.artists, key = { it.id }) { artist ->
                            ArtistItem(
                                artist = artist,
                                onClick = { onArtistClick(artist) },
                                isGrid = false
                            )
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(uiState.gridColumns),
                        state = gridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 8.dp,
                            end = 24.dp,
                            top = 6.dp,
                            bottom = 90.dp
                        ),
                    ) {
                        items(uiState.artists, key = { it.id }) { artist ->
                            ArtistItem(
                                artist = artist,
                                onClick = { onArtistClick(artist) },
                                isGrid = true,
                                gridColumns = uiState.gridColumns
                            )
                        }
                    }
                }

                // Fast Scroll Right Rail: Single scrollbar for Date Added / Modified, Alphabet Index for Title / Artist / Album
                if (uiState.sortOption == SortOption.DATE_ADDED || uiState.sortOption == SortOption.DATE_MODIFIED) {
                    if (uiState.gridColumns == 1) {
                        VerticalFastScrollBar(
                            listState = listState,
                            totalItemsCount = uiState.artists.size,
                            modifier = Modifier.align(Alignment.CenterEnd)
                        )
                    } else {
                        VerticalFastGridScrollBar(
                            gridState = gridState,
                            totalItemsCount = uiState.artists.size,
                            modifier = Modifier.align(Alignment.CenterEnd)
                        )
                    }
                } else {
                    VerticalAlphabetIndex(
                        titles = artistNames,
                        onLetterSelected = { token ->
                            val targetIndex = letterIndexMap[token]
                            if (targetIndex != null && targetIndex in uiState.artists.indices) {
                                scope.launch {
                                    if (uiState.gridColumns == 1) {
                                        listState.scrollToItem(targetIndex)
                                    } else {
                                        gridState.scrollToItem(targetIndex)
                                    }
                                }
                            }
                        },
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                }
            }
        }
    }
}
