package com.sr.music.feature.artist

import com.sr.music.core.components.SortOption
import com.sr.music.domain.model.Artist

data class ArtistUiState(
    val artists: List<Artist> = emptyList(),
    val searchQuery: String = "",
    val sortOption: SortOption = SortOption.TITLE,
    val selectedIndex: String? = null,
    val isAscending: Boolean = true,
    val gridColumns: Int = 1, // 1 = list mode (default as in screenshot), 2, 3, 4 = grid
    val isLoading: Boolean = false
)
