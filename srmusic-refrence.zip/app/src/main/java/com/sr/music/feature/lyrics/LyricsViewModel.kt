package com.sr.music.feature.lyrics

import androidx.lifecycle.ViewModel
import com.sr.music.domain.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class LyricsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(LyricsUiState())
    val uiState: StateFlow<LyricsUiState> = _uiState.asStateFlow()

    fun setSong(song: Song?) {
        _uiState.update {
            if (song == null) {
                LyricsUiState()
            } else {
                it.copy(
                    song = song,
                    lyrics = song.embeddedLyrics,
                    currentLineIndex = if (song.embeddedLyrics?.lines?.isNotEmpty() == true) 0 else -1
                )
            }
        }
    }

    fun selectLine(index: Int) {
        _uiState.update { it.copy(currentLineIndex = index) }
    }
}
