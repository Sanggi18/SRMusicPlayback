package com.sr.music.feature.settings

import androidx.lifecycle.ViewModel
import com.sr.music.core.theme.AccentColor
import com.sr.music.core.theme.AppFontStyle
import com.sr.music.core.theme.CatppuccinVariant
import com.sr.music.core.theme.ThemeMode
import com.sr.music.core.theme.ThemePresetCatalog
import com.sr.music.core.utils.AppPreferences
import com.sr.music.domain.model.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class SettingsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(
        SettingsUiState(
            settings = AppPreferences.get()?.loadSettings() ?: AppSettings()
        )
    )
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    private fun updateSettings(updateBlock: (AppSettings) -> AppSettings) {
        _uiState.update { current ->
            val newSettings = updateBlock(current.settings)
            AppPreferences.get()?.saveSettings(newSettings)
            current.copy(settings = newSettings)
        }
    }

    // Theme Actions
    fun setThemeMode(mode: ThemeMode) {
        updateSettings { it.copy(themeMode = mode) }
    }

    fun setCatppuccinVariant(variant: CatppuccinVariant) {
        val defaultAccentHex = when (variant) {
            CatppuccinVariant.MOCHA -> "#CBA6F7"
            CatppuccinVariant.MACCHIATO -> "#C6A0F6"
            CatppuccinVariant.FRAPPE -> "#CA9EE6"
            CatppuccinVariant.LATTE -> "#8839EF"
        }
        val defaultAccentColor = AccentColor.fromHex(defaultAccentHex) ?: AccentColor.PURPLE

        updateSettings {
            it.copy(
                themeMode = ThemeMode.CATPPUCCIN,
                catppuccinVariant = variant,
                selectedPresetThemeId = "catppuccin",
                selectedPresetVariantId = variant.name.lowercase(),
                accentColor = defaultAccentColor,
                customAccentHex = defaultAccentHex
            )
        }
    }

    fun setPresetTheme(presetId: String, variantId: String) {
        val variant = ThemePresetCatalog.getVariant(presetId, variantId)
        val defaultAccentHex = variant?.previewPrimary?.let { color ->
            val r = (color.red * 255).toInt().coerceIn(0, 255)
            val g = (color.green * 255).toInt().coerceIn(0, 255)
            val b = (color.blue * 255).toInt().coerceIn(0, 255)
            String.format("#%02X%02X%02X", r, g, b)
        } ?: "#6750A4"
        val defaultAccentColor = AccentColor.fromHex(defaultAccentHex) ?: AccentColor.PURPLE

        updateSettings {
            it.copy(
                themeMode = ThemeMode.PRESET,
                selectedPresetThemeId = presetId,
                selectedPresetVariantId = variantId,
                accentColor = defaultAccentColor,
                customAccentHex = defaultAccentHex
            )
        }
    }

    fun toggleAmoled(enabled: Boolean) {
        updateSettings { it.copy(amoledEnabled = enabled) }
    }

    fun setAccentColor(accent: AccentColor) {
        updateSettings {
            it.copy(
                accentColor = accent,
                customAccentHex = accent.hexString
            )
        }
    }

    fun setCustomAccent(accent: AccentColor, hex: String) {
        updateSettings {
            it.copy(
                accentColor = accent,
                customAccentHex = hex
            )
        }
    }

    fun setAccentFromHex(hex: String) {
        val matched = AccentColor.fromHex(hex)
        updateSettings {
            it.copy(
                accentColor = matched ?: it.accentColor,
                customAccentHex = hex
            )
        }
    }

    fun toggleDynamicColor(enabled: Boolean) {
        updateSettings { it.copy(dynamicColor = enabled) }
    }

    fun setFontStyle(fontStyle: AppFontStyle) {
        updateSettings { it.copy(fontStyle = fontStyle) }
    }

    // Navigation / Bottom Tab Customization
    fun reorderBottomTabs(fromIndex: Int, toIndex: Int) {
        if (fromIndex == toIndex) return
        updateSettings { state ->
            val list = state.visibleBottomTabs.toMutableList()
            if (fromIndex in list.indices && toIndex in list.indices) {
                val item = list.removeAt(fromIndex)
                list.add(toIndex, item)
                state.copy(visibleBottomTabs = list)
            } else {
                state
            }
        }
    }

    fun moveBottomTabUp(index: Int) {
        if (index <= 0) return
        updateSettings { state ->
            val list = state.visibleBottomTabs.toMutableList()
            val item = list.removeAt(index)
            list.add(index - 1, item)
            state.copy(visibleBottomTabs = list)
        }
    }

    fun moveBottomTabDown(index: Int) {
        updateSettings { state ->
            val list = state.visibleBottomTabs.toMutableList()
            if (index >= list.size - 1) return@updateSettings state
            val item = list.removeAt(index)
            list.add(index + 1, item)
            state.copy(visibleBottomTabs = list)
        }
    }

    fun removeBottomTab(route: String) {
        updateSettings { state ->
            val list = state.visibleBottomTabs.toMutableList()
            if (list.size <= 2) return@updateSettings state // Minimum 2 tabs retained
            list.remove(route)
            state.copy(visibleBottomTabs = list)
        }
    }

    fun addBottomTab(route: String) {
        if (route == "settings") return
        updateSettings { state ->
            val list = state.visibleBottomTabs.toMutableList()
            if (!list.contains(route)) {
                list.add(route)
            }
            state.copy(visibleBottomTabs = list)
        }
    }

    fun resetBottomTabs() {
        updateSettings { state ->
            state.copy(
                visibleBottomTabs = listOf("home", "song", "folder", "artist", "album")
            )
        }
    }

    // Audio Settings
    fun toggleGaplessPlayback(enabled: Boolean) {
        updateSettings { it.copy(gaplessPlayback = enabled) }
    }

    fun setCrossfadeDuration(seconds: Int) {
        updateSettings { it.copy(crossfadeDurationSec = seconds) }
    }

    fun toggleReplayGain(enabled: Boolean) {
        updateSettings { it.copy(isReplayGainEnabled = enabled) }
    }

    fun setReplayGainMode(mode: String) {
        updateSettings { it.copy(replayGainMode = mode) }
    }

    fun setPlaybackSpeed(speed: Float) {
        updateSettings { it.copy(playbackSpeed = speed) }
    }

    // Library Settings
    fun togglePreferEmbeddedArtwork(enabled: Boolean) {
        updateSettings { it.copy(preferEmbeddedArtwork = enabled) }
    }

    fun toggleProceduralArtwork(enabled: Boolean) {
        updateSettings { it.copy(proceduralArtwork = enabled) }
    }

    fun toggleSplitMultiArtist(enabled: Boolean) {
        updateSettings { it.copy(splitMultiArtist = enabled) }
    }

    fun toggleFilterShortAudio(enabled: Boolean) {
        updateSettings { it.copy(filterShortAudio = enabled) }
    }
}
