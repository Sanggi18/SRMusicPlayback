package com.sr.music.core.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Album
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.sr.music.core.utils.Constants

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Home : BottomNavItem(
        route = Constants.ROUTE_HOME,
        title = "Home",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    )

    data object Song : BottomNavItem(
        route = Constants.ROUTE_SONG,
        title = "Songs",
        selectedIcon = Icons.Filled.MusicNote,
        unselectedIcon = Icons.Outlined.MusicNote
    )

    data object Folder : BottomNavItem(
        route = Constants.ROUTE_FOLDER,
        title = "Folder",
        selectedIcon = Icons.Filled.Folder,
        unselectedIcon = Icons.Outlined.Folder
    )

    data object Artist : BottomNavItem(
        route = Constants.ROUTE_ARTIST,
        title = "Artist",
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person
    )

    data object Album : BottomNavItem(
        route = Constants.ROUTE_ALBUM,
        title = "Album",
        selectedIcon = Icons.Filled.Album,
        unselectedIcon = Icons.Outlined.Album
    )

    data object Equalizer : BottomNavItem(
        route = Constants.ROUTE_EQUALIZER,
        title = "Equalizer",
        selectedIcon = Icons.Filled.GraphicEq,
        unselectedIcon = Icons.Outlined.GraphicEq
    )

    data object Lyrics : BottomNavItem(
        route = Constants.ROUTE_LYRICS,
        title = "Lyrics",
        selectedIcon = Icons.Filled.Description,
        unselectedIcon = Icons.Outlined.Description
    )

    data object Settings : BottomNavItem(
        route = Constants.ROUTE_SETTINGS,
        title = "Settings",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    )

    companion object {
        val configurableTabs = listOf(Home, Song, Folder, Artist, Album, Equalizer, Lyrics)
        val allTabs = listOf(Home, Song, Folder, Artist, Album, Equalizer, Lyrics, Settings)

        fun fromRoute(route: String): BottomNavItem? {
            return allTabs.firstOrNull { it.route == route }
        }
    }
}
