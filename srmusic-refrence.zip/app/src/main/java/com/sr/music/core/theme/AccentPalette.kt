package com.sr.music.core.theme

import androidx.compose.ui.graphics.Color

data class AccentPalette(
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val secondary: Color,
    val onSecondary: Color,
    val secondaryContainer: Color,
    val onSecondaryContainer: Color,
    val tertiary: Color,
    val onTertiary: Color,
    val tertiaryContainer: Color,
    val onTertiaryContainer: Color
)

object AccentPalettes {

    // Light Accents
    val PurpleLight = AccentPalette(
        primary = Color(0xFF6750A4),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFEADDFF),
        onPrimaryContainer = Color(0xFF21005D),
        secondary = Color(0xFF625B71),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFE8DEF8),
        onSecondaryContainer = Color(0xFF1D192B),
        tertiary = Color(0xFF7D5260),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFFFD8E4),
        onTertiaryContainer = Color(0xFF31111D)
    )

    val BlueLight = AccentPalette(
        primary = Color(0xFF0061A4),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFD1E4FF),
        onPrimaryContainer = Color(0xFF001D36),
        secondary = Color(0xFF535F70),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFD7E3F7),
        onSecondaryContainer = Color(0xFF101C2B),
        tertiary = Color(0xFF6B5778),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFF2DAFF),
        onTertiaryContainer = Color(0xFF251431)
    )

    val TealLight = AccentPalette(
        primary = Color(0xFF006A6A),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFF9CF1F0),
        onPrimaryContainer = Color(0xFF002020),
        secondary = Color(0xFF4A6363),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFCCE8E7),
        onSecondaryContainer = Color(0xFF051F1F),
        tertiary = Color(0xFF4B607C),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFD3E4FF),
        onTertiaryContainer = Color(0xFF041C35)
    )

    val GreenLight = AccentPalette(
        primary = Color(0xFF006E2C),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFF98F7A4),
        onPrimaryContainer = Color(0xFF002108),
        secondary = Color(0xFF516350),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFD4E8D1),
        onSecondaryContainer = Color(0xFF0F1F11),
        tertiary = Color(0xFF38656A),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFBCEBF0),
        onTertiaryContainer = Color(0xFF002023)
    )

    val PinkLight = AccentPalette(
        primary = Color(0xFF9C4057),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFFFD9E2),
        onPrimaryContainer = Color(0xFF3E001D),
        secondary = Color(0xFF75565F),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFFFD9E2),
        onSecondaryContainer = Color(0xFF2B151C),
        tertiary = Color(0xFF7C5635),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFFFDCC1),
        onTertiaryContainer = Color(0xFF2E1500)
    )

    val OrangeLight = AccentPalette(
        primary = Color(0xFF9C4300),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFFFDBCC),
        onPrimaryContainer = Color(0xFF351000),
        secondary = Color(0xFF77574B),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFFFDBCE),
        onSecondaryContainer = Color(0xFF2C160C),
        tertiary = Color(0xFF6A5F2F),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFF4E3A7),
        onTertiaryContainer = Color(0xFF221B00)
    )

    val RedLight = AccentPalette(
        primary = Color(0xFFB3261E),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFF9DEDC),
        onPrimaryContainer = Color(0xFF410E0B),
        secondary = Color(0xFF775656),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFFFDAD6),
        onSecondaryContainer = Color(0xFF2C1516),
        tertiary = Color(0xFF755B2F),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFFFDEA8),
        onTertiaryContainer = Color(0xFF271900)
    )

    val YellowLight = AccentPalette(
        primary = Color(0xFF6B5F00),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFFFE16F),
        onPrimaryContainer = Color(0xFF201C00),
        secondary = Color(0xFF655F40),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFECE3BC),
        onSecondaryContainer = Color(0xFF201C04),
        tertiary = Color(0xFF426650),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFC4ECD0),
        onTertiaryContainer = Color(0xFF002111)
    )

    val IndigoLight = AccentPalette(
        primary = Color(0xFF3F51B5),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFDEE0FF),
        onPrimaryContainer = Color(0xFF00105C),
        secondary = Color(0xFF5B5D72),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFDFE1F9),
        onSecondaryContainer = Color(0xFF181A2C),
        tertiary = Color(0xFF77536D),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFFFD7F3),
        onTertiaryContainer = Color(0xFF2D1228)
    )

    val CyanLight = AccentPalette(
        primary = Color(0xFF00838F),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFB8EAFF),
        onPrimaryContainer = Color(0xFF001F28),
        secondary = Color(0xFF4C626B),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFCFE6F1),
        onSecondaryContainer = Color(0xFF071E26),
        tertiary = Color(0xFF5B5B7E),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFE2DFFF),
        onTertiaryContainer = Color(0xFF181837)
    )

    val AmberLight = AccentPalette(
        primary = Color(0xFFC67C00),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFFFDEAC),
        onPrimaryContainer = Color(0xFF281900),
        secondary = Color(0xFF6F5B40),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFFBDEBC),
        onSecondaryContainer = Color(0xFF271904),
        tertiary = Color(0xFF516440),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFD4EABF),
        onTertiaryContainer = Color(0xFF102004)
    )

    val LimeLight = AccentPalette(
        primary = Color(0xFF689F38),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFC9F19E),
        onPrimaryContainer = Color(0xFF102000),
        secondary = Color(0xFF5B624C),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFDFE7CB),
        onSecondaryContainer = Color(0xFF181E0E),
        tertiary = Color(0xFF396660),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFBCECE4),
        onTertiaryContainer = Color(0xFF00201D)
    )

    // Dark Accents
    val PurpleDark = AccentPalette(
        primary = Color(0xFFD0BCFF),
        onPrimary = Color(0xFF381E72),
        primaryContainer = Color(0xFF4F378B),
        onPrimaryContainer = Color(0xFFEADDFF),
        secondary = Color(0xFFCCC2DC),
        onSecondary = Color(0xFF332D41),
        secondaryContainer = Color(0xFF4A4458),
        onSecondaryContainer = Color(0xFFE8DEF8),
        tertiary = Color(0xFFEFB8C8),
        onTertiary = Color(0xFF492532),
        tertiaryContainer = Color(0xFF633B48),
        onTertiaryContainer = Color(0xFFFFD8E4)
    )

    val BlueDark = AccentPalette(
        primary = Color(0xFF9ECAFF),
        onPrimary = Color(0xFF003258),
        primaryContainer = Color(0xFF00497D),
        onPrimaryContainer = Color(0xFFD1E4FF),
        secondary = Color(0xFFBBC7DB),
        onSecondary = Color(0xFF253140),
        secondaryContainer = Color(0xFF3B4858),
        onSecondaryContainer = Color(0xFFD7E3F7),
        tertiary = Color(0xFFD6BEE4),
        onTertiary = Color(0xFF3B2948),
        tertiaryContainer = Color(0xFF523F5F),
        onTertiaryContainer = Color(0xFFF2DAFF)
    )

    val TealDark = AccentPalette(
        primary = Color(0xFF80D5D4),
        onPrimary = Color(0xFF003737),
        primaryContainer = Color(0xFF004F4F),
        onPrimaryContainer = Color(0xFF9CF1F0),
        secondary = Color(0xFFB0CCCB),
        onSecondary = Color(0xFF1B3535),
        secondaryContainer = Color(0xFF324B4B),
        onSecondaryContainer = Color(0xFFCCE8E7),
        tertiary = Color(0xFFB3C8E8),
        onTertiary = Color(0xFF1C324C),
        tertiaryContainer = Color(0xFF344963),
        onTertiaryContainer = Color(0xFFD3E4FF)
    )

    val GreenDark = AccentPalette(
        primary = Color(0xFF7DDA8A),
        onPrimary = Color(0xFF003913),
        primaryContainer = Color(0xFF005320),
        onPrimaryContainer = Color(0xFF98F7A4),
        secondary = Color(0xFFB8CCB5),
        onSecondary = Color(0xFF243424),
        secondaryContainer = Color(0xFF3A4B3A),
        onSecondaryContainer = Color(0xFFD4E8D1),
        tertiary = Color(0xFFA0CFD4),
        onTertiary = Color(0xFF00363B),
        tertiaryContainer = Color(0xFF1F4D52),
        onTertiaryContainer = Color(0xFFBCEBF0)
    )

    val PinkDark = AccentPalette(
        primary = Color(0xFFFFB1C3),
        onPrimary = Color(0xFF5F102B),
        primaryContainer = Color(0xFF7E2840),
        onPrimaryContainer = Color(0xFFFFD9E2),
        secondary = Color(0xFFE5BDC6),
        onSecondary = Color(0xFF432931),
        secondaryContainer = Color(0xFF5B3F48),
        onSecondaryContainer = Color(0xFFFFD9E2),
        tertiary = Color(0xFFEFBD94),
        onTertiary = Color(0xFF47280C),
        tertiaryContainer = Color(0xFF613E1F),
        onTertiaryContainer = Color(0xFFFFDCC1)
    )

    val OrangeDark = AccentPalette(
        primary = Color(0xFFFFB68E),
        onPrimary = Color(0xFF542100),
        primaryContainer = Color(0xFF773200),
        onPrimaryContainer = Color(0xFFFFDBCC),
        secondary = Color(0xFFE6BEB0),
        onSecondary = Color(0xFF442A20),
        secondaryContainer = Color(0xFF5C4035),
        onSecondaryContainer = Color(0xFFFFDBCE),
        tertiary = Color(0xFFD7C78D),
        onTertiary = Color(0xFF3B3005),
        tertiaryContainer = Color(0xFF524719),
        onTertiaryContainer = Color(0xFFF4E3A7)
    )

    val RedDark = AccentPalette(
        primary = Color(0xFFF2B8B5),
        onPrimary = Color(0xFF601410),
        primaryContainer = Color(0xFF8C1D18),
        onPrimaryContainer = Color(0xFFF9DEDC),
        secondary = Color(0xFFE6BDBC),
        onSecondary = Color(0xFF442929),
        secondaryContainer = Color(0xFF5D3F3F),
        onSecondaryContainer = Color(0xFFFFDAD6),
        tertiary = Color(0xFFE5C18D),
        onTertiary = Color(0xFF422C05),
        tertiaryContainer = Color(0xFF5B4319),
        onTertiaryContainer = Color(0xFFFFDEA8)
    )

    val YellowDark = AccentPalette(
        primary = Color(0xFFE5C549),
        onPrimary = Color(0xFF383000),
        primaryContainer = Color(0xFF514700),
        onPrimaryContainer = Color(0xFFFFE16F),
        secondary = Color(0xFFCFC7A2),
        onSecondary = Color(0xFF363116),
        secondaryContainer = Color(0xFF4D472B),
        onSecondaryContainer = Color(0xFFECE3BC),
        tertiary = Color(0xFFA8D0B5),
        onTertiary = Color(0xFF133724),
        tertiaryContainer = Color(0xFF2B4E39),
        onTertiaryContainer = Color(0xFFC4ECD0)
    )

    val IndigoDark = AccentPalette(
        primary = Color(0xFFBAC3FF),
        onPrimary = Color(0xFF08218A),
        primaryContainer = Color(0xFF2639A0),
        onPrimaryContainer = Color(0xFFDEE0FF),
        secondary = Color(0xFFC3C5DD),
        onSecondary = Color(0xFF2D2F42),
        secondaryContainer = Color(0xFF434659),
        onSecondaryContainer = Color(0xFFDFE1F9),
        tertiary = Color(0xFFE6BAD7),
        onTertiary = Color(0xFF45263E),
        tertiaryContainer = Color(0xFF5E3C55),
        onTertiaryContainer = Color(0xFFFFD7F3)
    )

    val CyanDark = AccentPalette(
        primary = Color(0xFF80D4EA),
        onPrimary = Color(0xFF00363F),
        primaryContainer = Color(0xFF004E5B),
        onPrimaryContainer = Color(0xFFB8EAFF),
        secondary = Color(0xFFB3CAD4),
        onSecondary = Color(0xFF1E333C),
        secondaryContainer = Color(0xFF344A53),
        onSecondaryContainer = Color(0xFFCFE6F1),
        tertiary = Color(0xFFC4C3EA),
        onTertiary = Color(0xFF2D2D4D),
        tertiaryContainer = Color(0xFF434365),
        onTertiaryContainer = Color(0xFFE2DFFF)
    )

    val AmberDark = AccentPalette(
        primary = Color(0xFFFFBA53),
        onPrimary = Color(0xFF442B00),
        primaryContainer = Color(0xFF623F00),
        onPrimaryContainer = Color(0xFFFFDEAC),
        secondary = Color(0xFFDDC2A1),
        onSecondary = Color(0xFF3D2D16),
        secondaryContainer = Color(0xFF55432B),
        onSecondaryContainer = Color(0xFFFBDEBC),
        tertiary = Color(0xFFB7CDA5),
        onTertiary = Color(0xFF243516),
        tertiaryContainer = Color(0xFF3A4C2B),
        onTertiaryContainer = Color(0xFFD4EABF)
    )

    val LimeDark = AccentPalette(
        primary = Color(0xFFAED581),
        onPrimary = Color(0xFF233600),
        primaryContainer = Color(0xFF354E13),
        onPrimaryContainer = Color(0xFFC9F19E),
        secondary = Color(0xFFC3CBB0),
        onSecondary = Color(0xFF2E3320),
        secondaryContainer = Color(0xFF444A35),
        onSecondaryContainer = Color(0xFFDFE7CB),
        tertiary = Color(0xFFA1D0C9),
        onTertiary = Color(0xFF023732),
        tertiaryContainer = Color(0xFF204E49),
        onTertiaryContainer = Color(0xFFBCECE4)
    )

    fun getLight(accent: AccentColor, customHex: String = ""): AccentPalette {
        val custom = getCustomPalette(customHex, isDark = false)
        if (custom != null) return custom
        return when (accent) {
            AccentColor.RED -> RedLight
            AccentColor.ORANGE -> OrangeLight
            AccentColor.AMBER -> AmberLight
            AccentColor.YELLOW -> YellowLight
            AccentColor.LIME -> LimeLight
            AccentColor.GREEN -> GreenLight
            AccentColor.TEAL -> TealLight
            AccentColor.CYAN -> CyanLight
            AccentColor.BLUE -> BlueLight
            AccentColor.INDIGO -> IndigoLight
            AccentColor.PURPLE -> PurpleLight
            AccentColor.PINK -> PinkLight
        }
    }

    fun getDark(accent: AccentColor, customHex: String = ""): AccentPalette {
        val custom = getCustomPalette(customHex, isDark = true)
        if (custom != null) return custom
        return when (accent) {
            AccentColor.RED -> RedDark
            AccentColor.ORANGE -> OrangeDark
            AccentColor.AMBER -> AmberDark
            AccentColor.YELLOW -> YellowDark
            AccentColor.LIME -> LimeDark
            AccentColor.GREEN -> GreenDark
            AccentColor.TEAL -> TealDark
            AccentColor.CYAN -> CyanDark
            AccentColor.BLUE -> BlueDark
            AccentColor.INDIGO -> IndigoDark
            AccentColor.PURPLE -> PurpleDark
            AccentColor.PINK -> PinkDark
        }
    }

    private fun getCustomPalette(hex: String, isDark: Boolean): AccentPalette? {
        if (hex.isBlank()) return null
        val matched = AccentColor.fromHex(hex)
        if (matched != null) {
            return if (isDark) getDark(matched) else getLight(matched)
        }
        val rgb = AccentColor.parseHexToRgb(hex) ?: return null
        val c = Color(rgb.first, rgb.second, rgb.third)
        return if (isDark) {
            AccentPalette(
                primary = c,
                onPrimary = Color.Black,
                primaryContainer = c.copy(alpha = 0.35f),
                onPrimaryContainer = Color.White,
                secondary = c.copy(alpha = 0.7f),
                onSecondary = Color.Black,
                secondaryContainer = c.copy(alpha = 0.25f),
                onSecondaryContainer = Color.White,
                tertiary = c,
                onTertiary = Color.Black,
                tertiaryContainer = c.copy(alpha = 0.2f),
                onTertiaryContainer = Color.White
            )
        } else {
            AccentPalette(
                primary = c,
                onPrimary = Color.White,
                primaryContainer = c.copy(alpha = 0.18f),
                onPrimaryContainer = c,
                secondary = c.copy(alpha = 0.75f),
                onSecondary = Color.White,
                secondaryContainer = c.copy(alpha = 0.12f),
                onSecondaryContainer = Color.Black,
                tertiary = c,
                onTertiary = Color.White,
                tertiaryContainer = c.copy(alpha = 0.15f),
                onTertiaryContainer = Color.Black
            )
        }
    }
}
