package com.sr.music.data.mediastore

data class ScannedAudio(
    val mediaStoreId: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val artistId: Long,
    val album: String,
    val albumId: Long,
    val albumArtist: String?,
    val durationMs: Long,
    val trackNumber: Int,
    val discNumber: Int,
    val year: Int?,
    val genre: String?,
    val path: String,
    val folderPath: String,
    val size: Long,
    val dateAdded: Long,
    val dateModified: Long,
    val mimeType: String?,
    val sampleRateHz: Int? = null,
    val bitDepth: Int? = null,
    val channelCount: Int? = null,
    val bitRateKbps: Int? = null,
    val codec: String? = null
)
