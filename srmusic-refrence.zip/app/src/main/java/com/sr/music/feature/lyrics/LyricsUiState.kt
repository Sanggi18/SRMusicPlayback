package com.sr.music.feature.lyrics

import com.sr.music.domain.model.EmbeddedLyricsFormat
import com.sr.music.domain.model.Lyrics
import com.sr.music.domain.model.Song

data class LyricsUiState(
    val song: Song? = null,
    val lyrics: Lyrics? = null,
    val currentLineIndex: Int = -1,
    val currentWordIndex: Int = 0,
    val isLoading: Boolean = false
) {
    val hasEmbeddedLyrics: Boolean
        get() = lyrics != null && (lyrics.lines.isNotEmpty() || lyrics.plainText.isNotBlank())

    val detectedFormat: EmbeddedLyricsFormat
        get() {
            val l = lyrics ?: return EmbeddedLyricsFormat.NONE
            if (l.format != EmbeddedLyricsFormat.NONE) return l.format
            return if (l.lines.any { it.words.isNotEmpty() }) {
                EmbeddedLyricsFormat.WORD_BY_WORD
            } else if (l.isSynced && l.lines.isNotEmpty()) {
                EmbeddedLyricsFormat.SYNCED
            } else if (l.plainText.isNotBlank() || l.lines.isNotEmpty()) {
                EmbeddedLyricsFormat.UNSYNCHRONIZED
            } else {
                EmbeddedLyricsFormat.NONE
            }
        }
}
