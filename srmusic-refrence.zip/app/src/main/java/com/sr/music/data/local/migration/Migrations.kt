package com.sr.music.data.local.migration

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        // 1. Add new audio metadata and URI columns to songs table
        db.execSQL("ALTER TABLE songs ADD COLUMN uri TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE songs ADD COLUMN sample_rate_hz INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE songs ADD COLUMN bit_depth INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE songs ADD COLUMN channel_count INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE songs ADD COLUMN bit_rate_kbps INTEGER DEFAULT NULL")
        db.execSQL("ALTER TABLE songs ADD COLUMN codec TEXT DEFAULT NULL")

        // 2. Recreate playlist_tracks to enforce Foreign Key cascade on songs(id)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS playlist_tracks_new (
                playlist_id INTEGER NOT NULL,
                song_id TEXT NOT NULL,
                position INTEGER NOT NULL,
                added_at INTEGER NOT NULL,
                PRIMARY KEY(playlist_id, song_id, position),
                FOREIGN KEY(playlist_id) REFERENCES playlists(id) ON UPDATE NO ACTION ON DELETE CASCADE,
                FOREIGN KEY(song_id) REFERENCES songs(id) ON UPDATE NO ACTION ON DELETE CASCADE
            )
        """.trimIndent())

        db.execSQL("""
            INSERT INTO playlist_tracks_new (playlist_id, song_id, position, added_at)
            SELECT playlist_id, song_id, position, added_at FROM playlist_tracks
        """.trimIndent())

        db.execSQL("DROP TABLE playlist_tracks")
        db.execSQL("ALTER TABLE playlist_tracks_new RENAME TO playlist_tracks")

        db.execSQL("CREATE INDEX IF NOT EXISTS index_playlist_tracks_playlist_id ON playlist_tracks(playlist_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_playlist_tracks_song_id ON playlist_tracks(song_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_playlist_tracks_playlist_id_position ON playlist_tracks(playlist_id, position)")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS songs_new (
                id TEXT NOT NULL PRIMARY KEY,
                media_store_id INTEGER NOT NULL,
                uri TEXT NOT NULL DEFAULT '',
                title TEXT NOT NULL,
                artist TEXT NOT NULL,
                artist_id INTEGER NOT NULL DEFAULT 0,
                album TEXT NOT NULL,
                album_id INTEGER NOT NULL DEFAULT 0,
                album_artist TEXT DEFAULT NULL,
                duration_ms INTEGER NOT NULL,
                track_number INTEGER NOT NULL DEFAULT 1,
                disc_number INTEGER NOT NULL DEFAULT 1,
                year INTEGER DEFAULT NULL,
                genre TEXT DEFAULT NULL,
                path TEXT NOT NULL,
                folder_path TEXT NOT NULL,
                size INTEGER NOT NULL,
                date_added INTEGER NOT NULL,
                date_modified INTEGER NOT NULL,
                mime_type TEXT DEFAULT NULL,
                sample_rate_hz INTEGER DEFAULT NULL,
                bit_depth INTEGER DEFAULT NULL,
                channel_count INTEGER DEFAULT NULL,
                bit_rate_kbps INTEGER DEFAULT NULL,
                codec TEXT DEFAULT NULL,
                is_favorite INTEGER NOT NULL DEFAULT 0,
                play_count INTEGER NOT NULL DEFAULT 0,
                last_played_time INTEGER NOT NULL DEFAULT 0,
                embedded_lyrics TEXT DEFAULT NULL
            )
        """.trimIndent())

        db.execSQL("""
            INSERT INTO songs_new (
                id, media_store_id, uri, title, artist, artist_id, album, album_id, album_artist,
                duration_ms, track_number, disc_number, year, genre, path, folder_path, size,
                date_added, date_modified, mime_type, sample_rate_hz, bit_depth, channel_count,
                bit_rate_kbps, codec, is_favorite, play_count, last_played_time, embedded_lyrics
            )
            SELECT 
                id, media_store_id, uri, title, artist, artist_id, album, album_id, album_artist,
                duration_ms, track_number, disc_number, year, genre, path, folder_path, size,
                date_added, date_modified, mime_type, sample_rate_hz, bit_depth, channel_count,
                bit_rate_kbps, codec, is_favorite, play_count, last_played_time, embedded_lyrics
            FROM songs
        """.trimIndent())

        db.execSQL("DROP TABLE songs")
        db.execSQL("ALTER TABLE songs_new RENAME TO songs")

        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_songs_media_store_id ON songs(media_store_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_songs_artist ON songs(artist)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_songs_album ON songs(album)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_songs_folder_path ON songs(folder_path)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_songs_is_favorite ON songs(is_favorite)")
    }
}
