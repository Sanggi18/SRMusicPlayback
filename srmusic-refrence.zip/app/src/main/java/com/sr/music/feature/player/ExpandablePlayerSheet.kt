package com.sr.music.feature.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp
import com.sr.music.core.components.MiniPlayer
import com.sr.music.feature.lyrics.LyricsViewModel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * ExpandablePlayerSheet manages the interactive real-time drag transition
 * between the compact Mini Player pill and the full-screen Now Playing screen.
 *
 * It uses a single shared transitional surface driven by [expandProgress]:
 * - progress = 0.0f -> Exact compact Mini Player pill
 * - 0.0f < progress < 1.0f -> Interactive expanding transformation following user's finger in real-time
 * - progress = 1.0f -> Full-screen Now Playing screen
 */
@Composable
fun ExpandablePlayerSheet(
    playerViewModel: PlayerViewModel,
    lyricsViewModel: LyricsViewModel,
    onNavigateToEqualizer: () -> Unit,
    modifier: Modifier = Modifier,
    expandProgress: Animatable<Float, AnimationVector1D> = remember { Animatable(0f) },
    bottomBarHeight: Dp = 0.dp
) {
    val playerUiState by playerViewModel.uiState.collectAsState()
    val currentSong = playerUiState.currentSong ?: return

    if (playerUiState.isMiniPlayerDismissed) return

    val scope = rememberCoroutineScope()

    // Handle system back button when Now Playing is expanded or expanding
    BackHandler(enabled = expandProgress.value > 0.01f) {
        scope.launch {
            expandProgress.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
            )
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val screenHeight = constraints.maxHeight.toFloat()
        val screenHeightDp = maxHeight
        val density = LocalDensity.current

        val collapsedHeight = 56.dp
        val dismissOffsetY = remember { Animatable(0f) }
        val progress = expandProgress.value.coerceIn(0f, 1f)

        var cachedBottomPadding by remember {
            mutableStateOf(bottomBarHeight + 6.dp)
        }

        LaunchedEffect(progress, bottomBarHeight) {
            if (progress == 0f) {
                cachedBottomPadding = bottomBarHeight + 6.dp
            }
        }

        val currentHorizontalPadding = (12 * (1f - progress)).dp
        val currentCornerRadius = (20 * (1f - progress)).dp
        val currentBottomPadding = lerp(cachedBottomPadding, 0.dp, progress)
        val currentHeight = lerp(collapsedHeight, screenHeightDp, progress)

        val surfaceShape = RoundedCornerShape(currentCornerRadius)
        val containerColor = lerp(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.surface,
            progress
        )
        val shadowElevation = (6 * (1f - progress)).dp
        val tonalElevation = (3 * (1f - progress)).dp
        val borderWidth = (0.5f * (1f - progress)).dp
        val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f * (1f - progress))
        val dismissAlpha = if (progress == 0f && dismissOffsetY.value > 0f) {
            (1f - (dismissOffsetY.value / 250f)).coerceIn(0f, 1f)
        } else {
            1f
        }

        var dragStartProgress by remember { mutableFloatStateOf(0f) }
        var isDismissDragActive by remember { mutableStateOf(false) }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = currentHorizontalPadding)
                .padding(bottom = currentBottomPadding)
                .height(currentHeight)
                .offset { IntOffset(0, dismissOffsetY.value.roundToInt()) }
                .graphicsLayer {
                    alpha = dismissAlpha
                }
                .clip(surfaceShape)
                .then(
                    if (progress < 0.99f) {
                        Modifier.border(
                            width = borderWidth,
                            color = borderColor,
                            shape = surfaceShape
                        )
                    } else {
                        Modifier
                    }
                )
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = {
                            dragStartProgress = expandProgress.value
                            isDismissDragActive = false
                        },
                        onVerticalDrag = { change, dragAmount ->
                            change.consume()
                            scope.launch {
                                // Disambiguate downward dismiss gesture from upward expansion gesture
                                if (expandProgress.value == 0f && dismissOffsetY.value == 0f) {
                                    if (dragAmount > 0f) {
                                        isDismissDragActive = true
                                    }
                                }

                                if (isDismissDragActive || dismissOffsetY.value > 0f) {
                                    val newDismissOffset = (dismissOffsetY.value + dragAmount).coerceAtLeast(0f)
                                    dismissOffsetY.snapTo(newDismissOffset)
                                    
                                    // Reset dismiss state if user drags back to resting position
                                    if (dismissOffsetY.value == 0f) {
                                        isDismissDragActive = false
                                    }
                                } else {
                                    val deltaProgress = -dragAmount / (screenHeight * 0.85f)
                                    val newProgress = (expandProgress.value + deltaProgress).coerceIn(0f, 1f)
                                    expandProgress.snapTo(newProgress)
                                }
                            }
                        },
                        onDragEnd = {
                            scope.launch {
                                if (isDismissDragActive || dismissOffsetY.value > 0f) {
                                    if (dismissOffsetY.value > 80f) {
                                        // Sufficient dismiss drag -> smoothly animate out then dismiss
                                        dismissOffsetY.animateTo(
                                            targetValue = with(density) { 200.dp.toPx() },
                                            animationSpec = tween(
                                                durationMillis = 180,
                                                easing = FastOutSlowInEasing
                                            )
                                        )
                                        playerViewModel.dismissMiniPlayerOnSwipe()
                                        dismissOffsetY.snapTo(0f)
                                    } else {
                                        // Insufficient drag -> smoothly spring back
                                        dismissOffsetY.animateTo(
                                            targetValue = 0f,
                                            animationSpec = tween(
                                                durationMillis = 200,
                                                easing = FastOutSlowInEasing
                                            )
                                        )
                                    }
                                    isDismissDragActive = false
                                } else {
                                    val target = if (dragStartProgress < 0.5f) {
                                        // Gesture started while opening
                                        if (expandProgress.value > 0.20f) 1f else 0f
                                    } else {
                                        // Gesture started while closing
                                        if (expandProgress.value < 0.80f) 0f else 1f
                                    }
                                    expandProgress.animateTo(
                                        targetValue = target,
                                        animationSpec = tween(
                                            durationMillis = 260,
                                            easing = FastOutSlowInEasing
                                        )
                                    )
                                }
                            }
                        },
                        onDragCancel = {
                            scope.launch {
                                if (dismissOffsetY.value > 0f) {
                                    dismissOffsetY.animateTo(
                                        targetValue = 0f,
                                        animationSpec = tween(
                                            durationMillis = 200,
                                            easing = FastOutSlowInEasing
                                        )
                                    )
                                    isDismissDragActive = false
                                } else {
                                    val target = if (expandProgress.value > 0.5f) 1f else 0f
                                    expandProgress.animateTo(
                                        targetValue = target,
                                        animationSpec = tween(
                                            durationMillis = 200,
                                            easing = FastOutSlowInEasing
                                        )
                                    )
                                }
                            }
                        }
                    )
                },
            shape = surfaceShape,
            color = containerColor,
            tonalElevation = tonalElevation,
            shadowElevation = shadowElevation
        ) {
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                // Full-screen Now Playing screen during expanded and expanding states
                if (progress > 0.01f) {
                    NowPlayingScreen(
                        viewModel = playerViewModel,
                        lyricsViewModel = lyricsViewModel,
                        onBackClick = {
                            scope.launch {
                                expandProgress.animateTo(
                                    targetValue = 0f,
                                    animationSpec = tween(
                                        durationMillis = 280,
                                        easing = FastOutSlowInEasing
                                    )
                                )
                            }
                        },
                        onNavigateToEqualizer = onNavigateToEqualizer,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                alpha = ((progress - 0.01f) / 0.35f).coerceIn(0f, 1f)
                            }
                    )
                }

                // Compact Mini Player pill anchored at bottom, fading out as player expands
                if (progress < 0.99f) {
                    val miniPlayerAlpha = (1f - (progress / 0.35f)).coerceIn(0f, 1f)

                    MiniPlayer(
                        currentSong = currentSong,
                        isPlaying = playerUiState.isPlaying,
                        onPlayPauseClick = {
                            playerViewModel.togglePlayPause()
                        },
                        onPreviousClick = {
                            playerViewModel.playPrevious()
                        },
                        onNextClick = {
                            playerViewModel.playNext()
                        },
                        onPlayerClick = {
                            scope.launch {
                                expandProgress.animateTo(
                                    targetValue = 1f,
                                    animationSpec = tween(
                                        durationMillis = 280,
                                        easing = FastOutSlowInEasing
                                    )
                                )
                            }
                        },
                        onDismissSwipe = {
                            playerViewModel.dismissMiniPlayerOnSwipe()
                        },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .graphicsLayer {
                                alpha = miniPlayerAlpha
                            }
                    )
                }
            }
        }
    }
}
