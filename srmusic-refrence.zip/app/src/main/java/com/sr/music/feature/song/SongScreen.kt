package com.sr.music.feature.song

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.sr.music.core.components.EmptyState
import com.sr.music.core.components.SearchPill
import com.sr.music.core.components.SongItem
import com.sr.music.core.components.SortBar
import com.sr.music.core.components.SortOption
import com.sr.music.core.components.VerticalAlphabetIndex
import com.sr.music.core.components.VerticalFastScrollBar
import com.sr.music.domain.model.Song
import kotlinx.coroutines.launch

@Composable
fun SongScreen(
    viewModel: SongViewModel,
    onSongClick: (Song, List<Song>) -> Unit,
    onMenuClick: () -> Unit = {},
    onNavigateToEqualizer: () -> Unit,
    onNavigateToLyrics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier,
    currentPlayingSongId: String? = null,
    onPlayNext: (Song) -> Unit = {},
    onAddToQueue: (Song) -> Unit = {},
    onGoToArtist: (String) -> Unit = {},
    onGoToAlbum: (String) -> Unit = {},
    onGoToFolder: (String) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val songTitles = remember(uiState.songs, uiState.sortOption) {
        uiState.songs.map { song ->
            when (uiState.sortOption) {
                SortOption.ARTIST -> song.artist
                SortOption.ALBUM -> song.album
                else -> song.title
            }
        }
    }

    // Precalculate letter / token to first song index mapping for instant lookup
    val letterIndexMap = remember(uiState.songs, uiState.sortOption) {
        val map = mutableMapOf<String, Int>()
        uiState.songs.forEachIndexed { index, song ->
            val target = when (uiState.sortOption) {
                SortOption.ARTIST -> song.artist
                SortOption.ALBUM -> song.album
                else -> song.title
            }.trim()
            val firstChar = target.firstOrNull()
            if (firstChar != null) {
                if (firstChar.uppercaseChar() in 'A'..'Z') {
                    val key = firstChar.uppercaseChar().toString()
                    if (!map.containsKey(key)) map[key] = index
                } else if (firstChar.isDigit()) {
                    if (target.startsWith("10") && !map.containsKey("10")) {
                        map["10"] = index
                    }
                    val digitKey = firstChar.toString()
                    if (!map.containsKey(digitKey)) map[digitKey] = index
                    if (!map.containsKey("#")) map["#"] = index
                } else if (!firstChar.isLetter() && firstChar.code < 0x2E80) {
                    if (!map.containsKey("#")) map["#"] = index
                } else {
                    val langKey = firstChar.toString()
                    if (!map.containsKey(langKey)) map[langKey] = index
                }
            } else {
                if (!map.containsKey("#")) map["#"] = index
            }
        }
        map
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("song_screen")
    ) {
        SearchPill(
            searchQuery = uiState.searchQuery,
            onQueryChange = viewModel::updateSearchQuery,
            placeholder = "Search songs...",
            onMenuClick = onMenuClick
        )

        SortBar(
            currentSort = uiState.sortOption,
            isAscending = uiState.isAscending,
            onSortChange = viewModel::updateSort,
            onToggleAscending = viewModel::toggleAscending,
            onShuffleClick = {
                val shuffled = uiState.songs.shuffled()
                if (shuffled.isNotEmpty()) {
                    onSongClick(shuffled.first(), shuffled)
                }
            },
            availableOptions = listOf(
                SortOption.TITLE,
                SortOption.ALBUM,
                SortOption.ARTIST,
                SortOption.DATE_MODIFIED,
                SortOption.DATE_ADDED
            )
        )

        if (uiState.songs.isEmpty()) {
            EmptyState(
                title = "No songs found",
                subtitle = "No songs match your search query"
            )
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 0.dp,
                        end = 24.dp, // Space for right-side vertical index
                        top = 0.dp,
                        bottom = 90.dp
                    )
                ) {
                    items(uiState.songs, key = { it.id }) { song ->
                        SongItem(
                            song = song,
                            onClick = { onSongClick(song, uiState.songs) },
                            isPlaying = song.id == currentPlayingSongId,
                            onPlayNext = onPlayNext,
                            onAddToQueue = onAddToQueue,
                            onGoToArtist = onGoToArtist,
                            onGoToAlbum = onGoToAlbum,
                            onGoToFolder = onGoToFolder,
                            onDelete = { viewModel.deleteSong(it) }
                        )
                    }
                }

                // Fast Scroll Right Rail: Single scrollbar for Date Added / Modified, Alphabet Index for Title / Artist / Album
                if (uiState.sortOption == SortOption.DATE_ADDED || uiState.sortOption == SortOption.DATE_MODIFIED) {
                    VerticalFastScrollBar(
                        listState = listState,
                        totalItemsCount = uiState.songs.size,
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                } else {
                    VerticalAlphabetIndex(
                        titles = songTitles,
                        onLetterSelected = { token ->
                            val targetIndex = letterIndexMap[token]
                            if (targetIndex != null && targetIndex in uiState.songs.indices) {
                                scope.launch {
                                    listState.scrollToItem(targetIndex)
                                }
                            }
                        },
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                }
            }
        }
    }
}
