package com.sr.music.feature.equalizer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sr.music.core.utils.formatDb
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EqualizerScreen(
    viewModel: EqualizerViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    val bandFrequencies = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
    val presets = listOf("Flat", "Bass Boost", "Rock", "Pop", "Classical", "Vocal", "Jazz", "Electronic")
    var showAudioOutputDialog by remember { mutableStateOf(false) }

    val audioOutputOptions = listOf(
        "Default" to "Auto-detect optimal output engine",
        "AAudio" to "Low latency high performance audio API",
        "AudioTrack" to "Standard Android audio pipeline",
        "OpenSL ES" to "Native legacy audio engine"
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Equalizer & Audio",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick, modifier = Modifier.testTag("eq_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Bit Perfect Mode Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (uiState.isBitPerfectEnabled)
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                    else
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Bit Perfect Mode",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Hardware direct audio without resampling or DSP",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                        Switch(
                            checked = uiState.isBitPerfectEnabled,
                            onCheckedChange = { viewModel.toggleBitPerfect(it) },
                            modifier = Modifier.testTag("bit_perfect_switch")
                        )
                    }

                    if (uiState.isBitPerfectEnabled) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Text(
                                text = "Equalizer and Tone Controls are disabled in Bit Perfect mode to preserve untouched PCM data.",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                }
            }

            // 2. Audio Output (Compact Settings Row)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { showAudioOutputDialog = true }
                    .testTag("audio_output_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Audio Output",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = when (uiState.selectedAudioOutput) {
                                "AAudio" -> "AAudio (Low latency high performance)"
                                "AudioTrack" -> "AudioTrack (Standard Android pipeline)"
                                "OpenSL ES" -> "OpenSL ES (Native legacy engine)"
                                else -> "Default (Auto-detect optimal)"
                            },
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = uiState.selectedAudioOutput,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Audio Output Selection Dialog
            if (showAudioOutputDialog) {
                AlertDialog(
                    onDismissRequest = { showAudioOutputDialog = false },
                    title = {
                        Text(
                            text = "Audio Output",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            audioOutputOptions.forEach { (optionName, description) ->
                                val isSelected = uiState.selectedAudioOutput == optionName
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            viewModel.selectAudioOutput(optionName)
                                            showAudioOutputDialog = false
                                        }
                                        .testTag("output_option_${optionName.lowercase()}")
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = optionName,
                                                style = MaterialTheme.typography.bodyLarge.copy(
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                                )
                                            )
                                            Text(
                                                text = description,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            )
                                        }
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = {
                                                viewModel.selectAudioOutput(optionName)
                                                showAudioOutputDialog = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showAudioOutputDialog = false }) {
                            Text("Done")
                        }
                    }
                )
            }

            // 3. Equalizer Toggle Switch
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Equalizer",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = if (uiState.isEqActive) "Active" else if (uiState.isBitPerfectEnabled) "Bypassed by Bit Perfect" else "Disabled",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    Switch(
                        checked = uiState.isEqualizerEnabled,
                        onCheckedChange = { viewModel.toggleEqualizer(it) },
                        enabled = !uiState.isBitPerfectEnabled,
                        modifier = Modifier.testTag("eq_master_switch")
                    )
                }
            }

            // 4. Preamp Section
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Preamp Gain",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = uiState.preampGain.formatDb(),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                    Slider(
                        value = uiState.preampGain,
                        onValueChange = { viewModel.updatePreamp(it) },
                        valueRange = 0f..12f,
                        enabled = uiState.isEqActive,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // 5. 10-Band Graphic EQ (Real Hardware Graphic Equalizer Panel)
            GraphicEqualizerPanel(
                frequencies = bandFrequencies,
                bands = uiState.bands,
                enabled = uiState.isEqActive,
                onBandChange = { index, gain -> viewModel.updateBand(index, gain) },
                onResetBands = { viewModel.resetBands() },
                modifier = Modifier.fillMaxWidth()
            )

            // 6. Presets Wrapped Flow (Placed below Graphic EQ)
            Column {
                Text(
                    text = "Presets",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    presets.forEach { preset ->
                        FilterChip(
                            selected = uiState.selectedPreset == preset,
                            onClick = { if (uiState.isEqActive) viewModel.applyPreset(preset) },
                            label = { Text(preset) },
                            enabled = uiState.isEqActive,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            }

            // 7. Tone Controls (Bass, Vocal, Treble)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Tone Control",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )

                    // Bass
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Bass Boost", style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(80.dp))
                        Slider(
                            value = uiState.bassBoost,
                            onValueChange = { viewModel.updateBassBoost(it) },
                            valueRange = 0f..10f,
                            enabled = uiState.isEqActive,
                            modifier = Modifier.weight(1f)
                        )
                        Text(uiState.bassBoost.formatDb(), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
                    }

                    // Vocal
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Vocal Boost", style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(80.dp))
                        Slider(
                            value = uiState.vocalBoost,
                            onValueChange = { viewModel.updateVocalBoost(it) },
                            valueRange = 0f..10f,
                            enabled = uiState.isEqActive,
                            modifier = Modifier.weight(1f)
                        )
                        Text(uiState.vocalBoost.formatDb(), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
                    }

                    // Treble
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Treble Boost", style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(80.dp))
                        Slider(
                            value = uiState.trebleBoost,
                            onValueChange = { viewModel.updateTrebleBoost(it) },
                            valueRange = 0f..10f,
                            enabled = uiState.isEqActive,
                            modifier = Modifier.weight(1f)
                        )
                        Text(uiState.trebleBoost.formatDb(), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
                    }
                }
            }
        }
    }
}

/**
 * Real 10-band hardware-inspired Graphic Equalizer Panel.
 * Features side-by-side vertical faders with dB grid lines, 0 dB center baseline,
 * and responsive scaling across mobile portrait and landscape viewports.
 */
@Composable
fun GraphicEqualizerPanel(
    frequencies: List<String>,
    bands: List<Float>,
    enabled: Boolean,
    onBandChange: (Int, Float) -> Unit,
    onResetBands: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val outlineColor = MaterialTheme.colorScheme.outlineVariant
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface
    val onSurfaceVariant = MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("graphic_equalizer_panel")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 12.dp)
        ) {
            // Header: Title, range and small reset button for 10-band EQ
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 2.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "10-Band Graphic EQ",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = onSurfaceColor
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "±15 dB",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = primaryColor
                        )
                    )
                }

                // Small reset button specifically for 10-Band EQ
                IconButton(
                    onClick = onResetBands,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("eq_reset_bands_button"),
                    enabled = enabled
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset 10-Band EQ",
                        tint = if (enabled) primaryColor else onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Main Equalizer Graph Body (Left dB scale column removed, full width utilized)
            val descriptions = remember {
                listOf("Sub Bass", "Bass", "Bass", "Low Mid", "Mid", "Mid", "Upper Mid", "Presence", "Treble", "Air")
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                val faderTrackHeight = maxHeight - 50.dp // Reserve space for bottom freq & role labels
                val faderTrackHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { faderTrackHeight.toPx() }

                // 1. Background Grid & Response Curve Canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(faderTrackHeight)
                ) {
                    val width = size.width
                    val height = size.height

                    // Horizontal dB Grid Lines (+15, +10, +5, 0, -5, -10, -15)
                    val dbSteps = listOf(15f, 10f, 5f, 0f, -5f, -10f, -15f)
                    val dashEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)

                    dbSteps.forEach { db ->
                        val y = height * (15f - db) / 30f
                        val isZeroDb = db == 0f

                        drawLine(
                            color = if (isZeroDb) primaryColor.copy(alpha = if (enabled) 0.65f else 0.25f)
                            else outlineColor.copy(alpha = 0.35f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = if (isZeroDb) 1.5f else 1f,
                            pathEffect = if (isZeroDb) null else dashEffect
                        )
                    }

                    // Response Curve across all 10 bands
                    if (bands.isNotEmpty()) {
                        val curvePath = Path()
                        val fillPath = Path()
                        val numBands = bands.size
                        val stepX = width / numBands

                        val points = bands.mapIndexed { index, gain ->
                            val x = stepX * index + (stepX / 2f)
                            val y = height * ((15f - gain) / 30f).coerceIn(0f, 1f)
                            Offset(x, y)
                        }

                        if (points.isNotEmpty()) {
                            curvePath.moveTo(points.first().x, points.first().y)
                            fillPath.moveTo(points.first().x, height / 2f)
                            fillPath.lineTo(points.first().x, points.first().y)

                            for (i in 0 until points.size - 1) {
                                val p0 = points[i]
                                val p1 = points[i + 1]
                                val midX = (p0.x + p1.x) / 2f
                                curvePath.cubicTo(midX, p0.y, midX, p1.y, p1.x, p1.y)
                                fillPath.cubicTo(midX, p0.y, midX, p1.y, p1.x, p1.y)
                            }

                            fillPath.lineTo(points.last().x, height / 2f)
                            fillPath.close()

                            // Translucent EQ curve fill
                            drawPath(
                                path = fillPath,
                                color = primaryColor.copy(alpha = if (enabled) 0.12f else 0.04f)
                            )

                            // EQ curve outline
                            drawPath(
                                path = curvePath,
                                color = primaryColor.copy(alpha = if (enabled) 0.5f else 0.2f),
                                style = Stroke(width = 2f, cap = StrokeCap.Round)
                            )
                        }
                    }
                }

                // 2. Interactive Vertical Faders Row (10 bands side-by-side)
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    frequencies.forEachIndexed { index, freqLabel ->
                        val gain = bands.getOrElse(index) { 0f }
                        val description = descriptions.getOrElse(index) { "" }

                        VerticalBandFader(
                            index = index,
                            freqLabel = freqLabel,
                            roleDescription = description,
                            gain = gain,
                            enabled = enabled,
                            trackHeight = faderTrackHeight,
                            trackHeightPx = faderTrackHeightPx,
                            onGainChange = { newGain -> onBandChange(index, newGain) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Individual vertical fader band with touch handling and frequency label at bottom.
 */
@Composable
fun VerticalBandFader(
    index: Int,
    freqLabel: String,
    roleDescription: String = "",
    gain: Float,
    enabled: Boolean,
    trackHeight: androidx.compose.ui.unit.Dp,
    trackHeightPx: Float,
    onGainChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val onSurfaceVariant = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = modifier
            .fillMaxHeight()
            .testTag("eq_band_fader_$index"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Draggable Fader Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(trackHeight)
                .pointerInput(enabled, trackHeightPx) {
                    if (!enabled || trackHeightPx <= 0f) return@pointerInput
                    detectTapGestures { offset ->
                        val fraction = 1f - (offset.y / trackHeightPx).coerceIn(0f, 1f)
                        val rawGain = -15f + fraction * 30f
                        val stepped = ((rawGain * 2f).roundToInt() / 2f).coerceIn(-15f, 15f)
                        onGainChange(stepped)
                    }
                }
                .pointerInput(enabled, trackHeightPx) {
                    if (!enabled || trackHeightPx <= 0f) return@pointerInput
                    detectVerticalDragGestures { change, _ ->
                        change.consume()
                        val fraction = 1f - (change.position.y / trackHeightPx).coerceIn(0f, 1f)
                        val rawGain = -15f + fraction * 30f
                        val stepped = ((rawGain * 2f).roundToInt() / 2f).coerceIn(-15f, 15f)
                        onGainChange(stepped)
                    }
                },
            contentAlignment = Alignment.TopCenter
        ) {
            // Track Centerline
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(1.5.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )

            // Fader Thumb / Knob
            val normalizedGain = ((15f - gain) / 30f).coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            x = 0,
                            y = (normalizedGain * (trackHeightPx - 20.dp.toPx())).roundToInt()
                        )
                    }
                    .size(width = 24.dp, height = 18.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (enabled) {
                            if (gain != 0f) primaryColor else MaterialTheme.colorScheme.surfaceVariant
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        }
                    )
                    .border(
                        width = 1.dp,
                        color = if (enabled && gain != 0f) primaryColor else MaterialTheme.colorScheme.outlineVariant,
                        shape = RoundedCornerShape(6.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Center metallic grip indicator line on the knob
                Box(
                    modifier = Modifier
                        .width(10.dp)
                        .height(2.dp)
                        .clip(RoundedCornerShape(1.dp))
                        .background(
                            if (enabled && gain != 0f) MaterialTheme.colorScheme.onPrimary
                            else onSurfaceVariant.copy(alpha = 0.7f)
                        )
                )
            }
        }

        // Frequency Label, Role Description, and Gain at Bottom
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .padding(top = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Text(
                text = freqLabel,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = if (gain != 0f && enabled) FontWeight.Bold else FontWeight.SemiBold
                ),
                color = if (gain != 0f && enabled) primaryColor else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            if (roleDescription.isNotEmpty()) {
                Text(
                    text = roleDescription,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Normal
                    ),
                    color = onSurfaceVariant.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
            Text(
                text = if (gain > 0) "+${gain.roundToInt()} dB" else if (gain < 0) "${gain.roundToInt()} dB" else "0 dB",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 7.5.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = if (gain != 0f && enabled) primaryColor.copy(alpha = 0.95f) else onSurfaceVariant.copy(alpha = 0.45f),
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}
