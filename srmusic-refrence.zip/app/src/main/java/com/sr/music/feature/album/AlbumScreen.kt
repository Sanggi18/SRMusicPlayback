package com.sr.music.feature.album

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.sr.music.core.components.AlbumItem
import com.sr.music.core.components.EmptyState
import com.sr.music.core.components.SearchPill
import com.sr.music.core.components.SortBar
import com.sr.music.core.components.SortOption
import com.sr.music.core.components.VerticalAlphabetIndex
import com.sr.music.core.components.VerticalFastGridScrollBar
import com.sr.music.core.components.ViewModeIcon
import com.sr.music.domain.model.Album
import kotlinx.coroutines.launch

@Composable
fun AlbumScreen(
    viewModel: AlbumViewModel,
    onAlbumClick: (Album) -> Unit,
    onMenuClick: () -> Unit = {},
    onNavigateToEqualizer: () -> Unit,
    onNavigateToLyrics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    val albumTitles = remember(uiState.albums, uiState.sortOption) {
        uiState.albums.map { album ->
            when (uiState.sortOption) {
                SortOption.ARTIST -> album.artist
                else -> album.title
            }
        }
    }

    val letterIndexMap = remember(uiState.albums, uiState.sortOption) {
        val map = mutableMapOf<String, Int>()
        uiState.albums.forEachIndexed { index, album ->
            val target = when (uiState.sortOption) {
                SortOption.ARTIST -> album.artist
                else -> album.title
            }.trim()
            val firstChar = target.firstOrNull()
            val letterKey = when {
                firstChar == null -> "#"
                firstChar.uppercaseChar() in 'A'..'Z' -> firstChar.uppercaseChar().toString()
                firstChar.isDigit() || (!firstChar.isLetter() && firstChar.code < 0x2E80) -> "#"
                else -> firstChar.toString()
            }
            if (!map.containsKey(letterKey)) {
                map[letterKey] = index
            }
        }
        map
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("album_screen")
    ) {
        SearchPill(
            searchQuery = uiState.searchQuery,
            onQueryChange = viewModel::updateSearchQuery,
            placeholder = "Search albums...",
            onMenuClick = onMenuClick
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                SortBar(
                    currentSort = uiState.sortOption,
                    isAscending = uiState.isAscending,
                    onSortChange = viewModel::updateSort,
                    onToggleAscending = viewModel::toggleAscending,
                    availableOptions = listOf(SortOption.TITLE, SortOption.ARTIST, SortOption.DATE_ADDED)
                )
            }

            IconButton(
                onClick = {
                    val nextCols = if (uiState.gridColumns >= 4) 1 else uiState.gridColumns + 1
                    viewModel.setGridColumns(nextCols)
                },
                modifier = Modifier.testTag("album_grid_toggle")
            ) {
                ViewModeIcon(
                    columns = uiState.gridColumns,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (uiState.albums.isEmpty()) {
            EmptyState(
                title = "No albums found",
                subtitle = "No albums match your search query"
            )
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(uiState.gridColumns),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = if (uiState.gridColumns == 1) 0.dp else 8.dp,
                        end = 24.dp,
                        top = 6.dp,
                        bottom = 90.dp
                    )
                ) {
                    items(uiState.albums, key = { it.id }) { album ->
                        AlbumItem(
                            album = album,
                            onClick = { onAlbumClick(album) },
                            isGrid = uiState.gridColumns > 1,
                            gridColumns = uiState.gridColumns,
                            isCarousel = false
                        )
                    }
                }

                // Fast Scroll Right Rail: Single scrollbar for Date Added / Modified, Alphabet Index for Title / Artist / Album
                if (uiState.sortOption == SortOption.DATE_ADDED || uiState.sortOption == SortOption.DATE_MODIFIED) {
                    VerticalFastGridScrollBar(
                        gridState = gridState,
                        totalItemsCount = uiState.albums.size,
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                } else {
                    VerticalAlphabetIndex(
                        titles = albumTitles,
                        onLetterSelected = { token ->
                            val targetIndex = letterIndexMap[token]
                            if (targetIndex != null && targetIndex in uiState.albums.indices) {
                                scope.launch {
                                    gridState.scrollToItem(targetIndex)
                                }
                            }
                        },
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                }
            }
        }
    }
}
