package com.sr.music.playback

import android.net.Uri
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.sr.music.domain.model.Song

object MediaItemMapper {

    private const val KEY_SONG_ID = "song_id"
    private const val KEY_DURATION_MS = "duration_ms"
    private const val KEY_TRACK_NUMBER = "track_number"
    private const val KEY_ARTWORK_URL = "artwork_url"
    private const val KEY_GENRE = "genre"
    private const val KEY_YEAR = "year"
    private const val KEY_FOLDER_PATH = "folder_path"
    private const val KEY_URI = "uri"
    private const val KEY_SAMPLE_RATE_HZ = "sample_rate_hz"
    private const val KEY_BIT_DEPTH = "bit_depth"
    private const val KEY_CHANNEL_COUNT = "channel_count"
    private const val KEY_BIT_RATE_KBPS = "bit_rate_kbps"
    private const val KEY_CODEC = "codec"
    private const val KEY_IS_FAVORITE = "is_favorite"

    fun toMediaItem(song: Song): MediaItem {
        val audioUri = if (song.uri.isNotBlank()) {
            Uri.parse(song.uri)
        } else {
            Uri.parse(song.folderPath)
        }

        val artworkUri = song.artworkUrl?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }

        val extras = Bundle().apply {
            putString(KEY_SONG_ID, song.id)
            putLong(KEY_DURATION_MS, song.durationMs)
            putInt(KEY_TRACK_NUMBER, song.trackNumber)
            putString(KEY_ARTWORK_URL, song.artworkUrl)
            putString(KEY_GENRE, song.genre)
            song.year?.let { putInt(KEY_YEAR, it) }
            putString(KEY_FOLDER_PATH, song.folderPath)
            putString(KEY_URI, song.uri)
            song.sampleRateHz?.let { putInt(KEY_SAMPLE_RATE_HZ, it) }
            song.bitDepth?.let { putInt(KEY_BIT_DEPTH, it) }
            song.channelCount?.let { putInt(KEY_CHANNEL_COUNT, it) }
            song.bitRateKbps?.let { putInt(KEY_BIT_RATE_KBPS, it) }
            putString(KEY_CODEC, song.codec)
            putBoolean(KEY_IS_FAVORITE, song.isFavorite)
        }

        val metadata = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
            .setAlbumArtist(song.artist)
            .setTrackNumber(song.trackNumber)
            .setArtworkUri(artworkUri)
            .setExtras(extras)
            .build()

        return MediaItem.Builder()
            .setMediaId(song.id)
            .setUri(audioUri)
            .setMediaMetadata(metadata)
            .build()
    }

    fun toSong(mediaItem: MediaItem): Song {
        val metadata = mediaItem.mediaMetadata
        val extras = metadata.extras

        val id = extras?.getString(KEY_SONG_ID) ?: mediaItem.mediaId
        val title = metadata.title?.toString() ?: "Unknown Title"
        val artist = metadata.artist?.toString() ?: "Unknown Artist"
        val album = metadata.albumTitle?.toString() ?: "Unknown Album"
        val durationMs = extras?.getLong(KEY_DURATION_MS, 0L) ?: 0L
        val trackNumber = extras?.getInt(KEY_TRACK_NUMBER, 1) ?: 1
        val artworkUrl = extras?.getString(KEY_ARTWORK_URL) ?: metadata.artworkUri?.toString()
        val genre = extras?.getString(KEY_GENRE)
        val year = if (extras?.containsKey(KEY_YEAR) == true) extras.getInt(KEY_YEAR) else null
        val folderPath = extras?.getString(KEY_FOLDER_PATH) ?: ""
        val uri = extras?.getString(KEY_URI) ?: (mediaItem.localConfiguration?.uri?.toString() ?: "")
        val sampleRateHz = if (extras?.containsKey(KEY_SAMPLE_RATE_HZ) == true) extras.getInt(KEY_SAMPLE_RATE_HZ) else null
        val bitDepth = if (extras?.containsKey(KEY_BIT_DEPTH) == true) extras.getInt(KEY_BIT_DEPTH) else null
        val channelCount = if (extras?.containsKey(KEY_CHANNEL_COUNT) == true) extras.getInt(KEY_CHANNEL_COUNT) else null
        val bitRateKbps = if (extras?.containsKey(KEY_BIT_RATE_KBPS) == true) extras.getInt(KEY_BIT_RATE_KBPS) else null
        val codec = extras?.getString(KEY_CODEC)
        val isFavorite = extras?.getBoolean(KEY_IS_FAVORITE, false) ?: false

        return Song(
            id = id,
            title = title,
            artist = artist,
            album = album,
            durationMs = durationMs,
            trackNumber = trackNumber,
            artworkUrl = artworkUrl,
            genre = genre,
            year = year,
            folderPath = folderPath,
            uri = uri,
            sampleRateHz = sampleRateHz,
            bitDepth = bitDepth,
            channelCount = channelCount,
            bitRateKbps = bitRateKbps,
            codec = codec,
            isFavorite = isFavorite
        )
    }

    fun toMediaItems(songs: List<Song>): List<MediaItem> {
        return songs.map { toMediaItem(it) }
    }
}
