package com.sr.music.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.sr.music.core.components.AlbumItem
import com.sr.music.core.components.ArtistItem
import com.sr.music.core.components.EmptyState
import com.sr.music.core.components.SearchPill
import com.sr.music.core.components.SectionHeader
import com.sr.music.core.components.SongItem
import com.sr.music.domain.model.Album
import com.sr.music.domain.model.Artist
import com.sr.music.domain.model.Song

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onSongClick: (Song, List<Song>) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onMenuClick: () -> Unit = {},
    onNavigateToEqualizer: () -> Unit = {},
    onNavigateToLyrics: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    modifier: Modifier = Modifier,
    currentPlayingSongId: String? = null,
    onPlayNext: (Song) -> Unit = {},
    onAddToQueue: (Song) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen")
    ) {
        SearchPill(
            searchQuery = uiState.searchQuery,
            onQueryChange = viewModel::updateSearchQuery,
            placeholder = "Search songs, artists, albums...",
            onMenuClick = onMenuClick
        )

        if (uiState.recentTracks.isEmpty() && uiState.searchQuery.isNotEmpty()) {
            EmptyState(
                title = "No matches found",
                subtitle = "Try searching for another artist, title, or album"
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Section: Recent Added Artist
                if (uiState.searchQuery.isEmpty()) {
                    item {
                        SectionHeader(title = "Recent Added Artist")
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(uiState.recentArtists, key = { it.id }) { artist ->
                                ArtistItem(
                                    artist = artist,
                                    onClick = { onArtistClick(artist) },
                                    isCarousel = true
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Section: Recent Added Album
                    item {
                        SectionHeader(title = "Recent Added Album")
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(uiState.recentAlbums, key = { it.id }) { album ->
                                AlbumItem(
                                    album = album,
                                    onClick = { onAlbumClick(album) },
                                    isCarousel = true,
                                    itemWidth = 150.dp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                // Section: Recent Added Track
                item {
                    SectionHeader(
                        title = if (uiState.searchQuery.isEmpty()) "Recent Added Track" else "Search Results"
                    )
                }

                items(uiState.recentTracks, key = { it.id }) { song ->
                    SongItem(
                        song = song,
                        onClick = { onSongClick(song, uiState.recentTracks) },
                        isPlaying = song.id == currentPlayingSongId,
                        onPlayNext = onPlayNext,
                        onAddToQueue = onAddToQueue
                    )
                }
            }
        }
    }
}
