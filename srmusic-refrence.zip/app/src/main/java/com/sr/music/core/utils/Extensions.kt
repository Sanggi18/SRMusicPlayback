package com.sr.music.core.utils

import java.util.Locale

fun Long.formatDuration(): String {
    val totalSeconds = this / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
}

fun Float.formatDb(): String {
    return if (this > 0) {
        String.format(Locale.getDefault(), "+%.1fdB", this)
    } else {
        String.format(Locale.getDefault(), "%.1fdB", this)
    }
}
