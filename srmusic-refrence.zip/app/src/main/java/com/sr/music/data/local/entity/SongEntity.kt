package com.sr.music.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "songs",
    indices = [
        Index(value = ["media_store_id"], unique = true),
        Index(value = ["artist"]),
        Index(value = ["album"]),
        Index(value = ["folder_path"]),
        Index(value = ["is_favorite"])
    ]
)
data class SongEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "media_store_id")
    val mediaStoreId: Long,

    @ColumnInfo(name = "uri", defaultValue = "''")
    val uri: String = "",

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "artist")
    val artist: String,

    @ColumnInfo(name = "artist_id")
    val artistId: Long = 0L,

    @ColumnInfo(name = "album")
    val album: String,

    @ColumnInfo(name = "album_id")
    val albumId: Long = 0L,

    @ColumnInfo(name = "album_artist")
    val albumArtist: String? = null,

    @ColumnInfo(name = "duration_ms")
    val durationMs: Long,

    @ColumnInfo(name = "track_number")
    val trackNumber: Int = 1,

    @ColumnInfo(name = "disc_number")
    val discNumber: Int = 1,

    @ColumnInfo(name = "year")
    val year: Int? = null,

    @ColumnInfo(name = "genre")
    val genre: String? = null,

    @ColumnInfo(name = "path")
    val path: String,

    @ColumnInfo(name = "folder_path")
    val folderPath: String,

    @ColumnInfo(name = "size")
    val size: Long,

    @ColumnInfo(name = "date_added")
    val dateAdded: Long,

    @ColumnInfo(name = "date_modified")
    val dateModified: Long,

    @ColumnInfo(name = "mime_type")
    val mimeType: String? = null,

    @ColumnInfo(name = "sample_rate_hz")
    val sampleRateHz: Int? = null,

    @ColumnInfo(name = "bit_depth")
    val bitDepth: Int? = null,

    @ColumnInfo(name = "channel_count")
    val channelCount: Int? = null,

    @ColumnInfo(name = "bit_rate_kbps")
    val bitRateKbps: Int? = null,

    @ColumnInfo(name = "codec")
    val codec: String? = null,

    @ColumnInfo(name = "is_favorite")
    val isFavorite: Boolean = false,

    @ColumnInfo(name = "play_count")
    val playCount: Int = 0,

    @ColumnInfo(name = "last_played_time")
    val lastPlayedTime: Long = 0L,

    @ColumnInfo(name = "embedded_lyrics")
    val embeddedLyrics: String? = null
)

data class SongSyncMeta(
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "media_store_id")
    val mediaStoreId: Long,

    @ColumnInfo(name = "date_modified")
    val dateModified: Long,

    @ColumnInfo(name = "size")
    val size: Long
)
