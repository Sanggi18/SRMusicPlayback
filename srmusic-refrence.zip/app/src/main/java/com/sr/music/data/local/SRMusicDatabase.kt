package com.sr.music.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.sr.music.data.local.dao.AlbumDao
import com.sr.music.data.local.dao.ArtistDao
import com.sr.music.data.local.dao.FolderDao
import com.sr.music.data.local.dao.PlaylistDao
import com.sr.music.data.local.dao.SongDao
import com.sr.music.data.local.entity.AlbumEntity
import com.sr.music.data.local.entity.ArtistEntity
import com.sr.music.data.local.entity.FolderEntity
import com.sr.music.data.local.entity.PlaylistEntity
import com.sr.music.data.local.entity.PlaylistTrackEntity
import com.sr.music.data.local.entity.SongEntity
import com.sr.music.data.local.migration.MIGRATION_1_2
import com.sr.music.data.local.migration.MIGRATION_2_3

@Database(
    entities = [
        SongEntity::class,
        AlbumEntity::class,
        ArtistEntity::class,
        FolderEntity::class,
        PlaylistEntity::class,
        PlaylistTrackEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class SRMusicDatabase : RoomDatabase() {

    abstract fun songDao(): SongDao
    abstract fun albumDao(): AlbumDao
    abstract fun artistDao(): ArtistDao
    abstract fun folderDao(): FolderDao
    abstract fun playlistDao(): PlaylistDao

    companion object {
        @Volatile
        private var INSTANCE: SRMusicDatabase? = null

        fun getInstance(context: Context): SRMusicDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SRMusicDatabase::class.java,
                    "srmusic_library.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
