package com.sr.music.core.components

import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sr.music.domain.model.Artist

@Composable
fun ArtistItem(
    artist: Artist,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isGrid: Boolean = false,
    gridColumns: Int = 2,
    isCarousel: Boolean = false,
    itemWidth: Dp = 86.dp
) {
    if (isCarousel) {
        Column(
            modifier = modifier
                .width(itemWidth)
                .clip(RoundedCornerShape(12.dp))
                .clickable { onClick() }
                .padding(vertical = 4.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Circle is strictly for the artwork
            ArtworkCard(
                artworkUrl = artist.artworkUrl,
                size = 72.dp,
                shapeType = ArtworkShape.CIRCLE
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Text stays completely outside the artwork container
            Text(
                text = artist.name,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                ),
                maxLines = 1,
                modifier = Modifier.basicMarquee(),
                textAlign = TextAlign.Center
            )
        }
    } else if (isGrid) {
        val artworkSize = when (gridColumns) {
            4 -> 56.dp
            3 -> 76.dp
            else -> 108.dp
        }
        val titleSize = when (gridColumns) {
            4 -> 11.sp
            3 -> 12.sp
            else -> 14.sp
        }
        val subtitleSize = when (gridColumns) {
            4 -> 10.sp
            3 -> 11.sp
            else -> 12.sp
        }

        Column(
            modifier = modifier
                .fillMaxWidth()
                .clickable { onClick() }
                .padding(if (gridColumns >= 3) 4.dp else 8.dp)
                .testTag("artist_grid_item_${artist.id}"),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ArtworkCard(
                artworkUrl = artist.artworkUrl,
                size = artworkSize,
                shapeType = ArtworkShape.CIRCLE
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = artist.name,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = titleSize
                ),
                maxLines = 1,
                modifier = Modifier.basicMarquee(),
                textAlign = TextAlign.Center
            )

            Text(
                text = "${artist.songCount} songs",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = subtitleSize
                ),
                textAlign = TextAlign.Center
            )
        }
    } else {
        // Vertical List style matching Artists.png screenshot
        Row(
            modifier = modifier
                .fillMaxWidth()
                .clickable { onClick() }
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .testTag("artist_list_item_${artist.id}"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArtworkCard(
                artworkUrl = artist.artworkUrl,
                size = 46.dp,
                shapeType = ArtworkShape.CIRCLE
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = artist.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    maxLines = 1,
                    modifier = Modifier.basicMarquee()
                )

                Text(
                    text = "${artist.songCount} songs",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                )
            }
        }
    }
}
