package com.sr.music.core.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.sr.music.R

enum class AppFontStyle(
    val id: String,
    val displayName: String,
    val description: String = ""
) {
    SYSTEM_DEFAULT("system_default", "System Default", "Default device system typography"),
    HELVETICA("helvetica", "Helvetica", "Clean neo-grotesque sans-serif"),
    GOOGLE_SANS("google_sans", "Google Sans", "Geometric modern product sans"),
    NUNITO("nunito", "Nunito", "Rounded, balanced modern sans"),
    LINOTTE("linotte", "Linotte", "Friendly rounded display sans"),
    JETBRAINS("jetbrains", "JetBrains", "Monospaced developer typeface"),
    ARIAL("arial", "Arial", "Classic grotesque neutral sans"),
    CALIBRI("calibri", "Calibri", "Humanist warm condensed sans"),
    JAKARTA_SF_PRO("jakarta_sf_pro", "Jakarta / SF Pro", "Contemporary high-legibility UI"),
    APPLE_FONT("apple_font", "Apple Font", "San Francisco neutral style"),
    INTER("inter", "Inter", "Precision interface typography");

    val fontFamily: FontFamily
        get() = when (this) {
            SYSTEM_DEFAULT -> FontFamily.Default
            HELVETICA -> FontFamily(Font(R.font.helvetica))
            GOOGLE_SANS -> FontFamily(Font(R.font.google_sans))
            NUNITO -> FontFamily(Font(R.font.nunito))
            LINOTTE -> FontFamily(Font(R.font.linotte))
            JETBRAINS -> FontFamily(Font(R.font.jetbrains))
            ARIAL -> FontFamily(Font(R.font.arial))
            CALIBRI -> FontFamily(Font(R.font.calibri))
            JAKARTA_SF_PRO -> FontFamily(Font(R.font.plus_jakarta_sans))
            APPLE_FONT -> FontFamily(Font(R.font.apple_font))
            INTER -> FontFamily(Font(R.font.inter))
        }

    companion object {
        fun fromId(id: String): AppFontStyle {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) }
                ?: SYSTEM_DEFAULT
        }
    }
}
