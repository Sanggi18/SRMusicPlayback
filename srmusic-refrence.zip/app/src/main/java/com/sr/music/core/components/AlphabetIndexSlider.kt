package com.sr.music.core.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Data utilities for Right-Side Vertical Alphabet Index.
 *
 * Sequence of all token sections from top to bottom:
 * 1. Standard Alphabet A..Z
 * 2. # (numbers/symbols)
 * 3. Numbers 1..10
 * 4. Japanese dynamic tokens (strictly from actual data)
 * 5. Chinese dynamic tokens (strictly from actual data)
 * 6. Korean dynamic tokens (strictly from actual data)
 */
object VerticalIndexHelper {
    val numberTokens: List<String> = (1..10).map { it.toString() }
    val latinAlphabet: List<String> = ('A'..'Z').map { it.toString() }
    const val HASH_TOKEN = "#"

    // Default visible window is A..Z + # (27 items)
    val defaultWindowSize: Int = latinAlphabet.size + 1 // 27

    fun isJapaneseChar(c: Char): Boolean =
        c in '\u3040'..'\u309F' || c in '\u30A0'..'\u30FF'

    fun isChineseChar(c: Char): Boolean =
        c in '\u4E00'..'\u9FFF' || c in '\u3400'..'\u4DBF'

    fun isKoreanChar(c: Char): Boolean =
        c in '\uAC00'..'\uD7AF' || c in '\u1100'..'\u11FF' || c in '\u3130'..'\u318F'

    /**
     * Extracts dynamic language tokens directly from actual title first characters.
     * Order MUST be: JAPANESE -> CHINESE -> KOREAN.
     */
    fun extractDynamicLanguageTokens(titles: List<String>): List<String> {
        val japanese = sortedSetOf<String>()
        val chinese = sortedSetOf<String>()
        val korean = sortedSetOf<String>()

        for (raw in titles) {
            val title = raw.trim()
            if (title.isEmpty()) continue
            val first = title.first()
            when {
                isJapaneseChar(first) -> japanese.add(first.toString())
                isChineseChar(first) -> chinese.add(first.toString())
                isKoreanChar(first) -> korean.add(first.toString())
            }
        }

        return buildList {
            addAll(japanese)
            addAll(chinese)
            addAll(korean)
        }
    }

    /**
     * Identifies which letters/tokens actually have items in the dataset.
     */
    fun extractAvailableTokens(titles: List<String>): Set<String> {
        val set = mutableSetOf<String>()
        for (raw in titles) {
            val title = raw.trim()
            if (title.isEmpty()) continue
            if (title.startsWith("10")) {
                set.add("10")
            }
            val first = title.first()
            when {
                first.uppercaseChar() in 'A'..'Z' -> set.add(first.uppercaseChar().toString())
                first.isDigit() -> {
                    set.add(first.toString())
                    set.add(HASH_TOKEN)
                }
                isJapaneseChar(first) || isChineseChar(first) || isKoreanChar(first) -> {
                    set.add(first.toString())
                }
                else -> set.add(HASH_TOKEN)
            }
        }
        return set
    }
}

/**
 * Right-side Vertical Alphabet Index Window / Slider.
 *
 * Requirements:
 * - Normal State Viewport: A B C ... Z # (Window size = 27, exactly matching A-Z + #)
 * - Fixed Viewport, Font Size, Spacing & Width (No shrinking of fonts or expanding height)
 * - Uses awaitEachGesture for unified, conflict-free touch and drag tracking
 * - Smooth 60fps edge scrolling loop with dynamic hotzones at top and bottom
 * - Hidden 1..10 section above A: revealed when dragging UP past A
 * - Language sections after #: revealed in order JAPANESE -> CHINESE -> KOREAN when dragging DOWN past #
 * - Language tokens are generated strictly from actual dataset
 * - A-Z always present: normal if dataset has matching items, muted if no items
 * - Vertical placement: bottom of the rail ends cleanly above Mini Player
 */
@Composable
fun VerticalAlphabetIndex(
    titles: List<String>,
    onLetterSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // Dynamic tokens derived strictly from actual dataset
    val dynamicAsianTokens = remember(titles) {
        VerticalIndexHelper.extractDynamicLanguageTokens(titles)
    }
    val availableTokens = remember(titles) {
        VerticalIndexHelper.extractAvailableTokens(titles)
    }

    // Full token stream: [A..Z] + [#] + [1..10] + [Japanese...] + [Chinese...] + [Korean...]
    val fullTokenList = remember(dynamicAsianTokens) {
        buildList {
            addAll(VerticalIndexHelper.latinAlphabet)
            add(VerticalIndexHelper.HASH_TOKEN)
            addAll(VerticalIndexHelper.numberTokens)
            addAll(dynamicAsianTokens)
        }
    }

    val defaultStartIndex = 0 // Starts at 'A' (shows A..Z + # in default viewport)
    val windowSize = VerticalIndexHelper.defaultWindowSize // 27 items in viewport
    val maxStartIndex = (fullTokenList.size - windowSize).coerceAtLeast(0)

    // Continuous scroll offset as Float
    var scrollOffsetFloat by remember(fullTokenList) {
        mutableFloatStateOf(defaultStartIndex.coerceAtMost(maxStartIndex).toFloat())
    }

    // Lacak state sentuhan jari secara absolut
    var pointerY by remember { mutableFloatStateOf(-1f) }
    var isTouching by remember { mutableStateOf(false) }

    var activeLetter by remember { mutableStateOf<String?>(null) }
    var activePreviewOffsetY by remember { mutableFloatStateOf(0f) }
    var railHeightPx by remember { mutableFloatStateOf(1f) }

    // Mesin Auto-Scroll & Seleksi (60fps mulus)
    LaunchedEffect(isTouching, pointerY, railHeightPx, maxStartIndex) {
        if (!isTouching || railHeightPx <= 1f) return@LaunchedEffect

        val itemHeight = railHeightPx / windowSize.toFloat()
        val hotzoneTop = itemHeight * 2.5f // Sensitivitas area atas
        val hotzoneBottom = railHeightPx - (itemHeight * 2.5f) // Sensitivitas area bawah

        while (isTouching) {
            // 1. Seleksi Huruf yang tepat berada di bawah jari
            val clampedY = pointerY.coerceIn(0f, railHeightPx - 1f)
            val relativeIndex = (clampedY / itemHeight).toInt().coerceIn(0, windowSize - 1)
            val currentStart = scrollOffsetFloat.roundToInt().coerceIn(0, maxStartIndex)
            val targetIndex = currentStart + relativeIndex

            if (targetIndex in fullTokenList.indices) {
                val token = fullTokenList[targetIndex]
                if (activeLetter != token) {
                    activeLetter = token
                    onLetterSelected(token)
                }
            }

            // 2. Animasi Preview Bubble mengikuti jari
            val halfRail = railHeightPx / 2f
            activePreviewOffsetY = (clampedY - halfRail).coerceIn(-halfRail + 24f, halfRail - 24f)

            // 3. Logika Auto-Scroll saat ditahan di ujung
            var scrolled = false
            if (pointerY < hotzoneTop && scrollOffsetFloat > 0f) {
                // Makin ke atas makin kenceng
                val intensity = (1f - (pointerY / hotzoneTop).coerceIn(0f, 1f))
                scrollOffsetFloat = (scrollOffsetFloat - (intensity * 0.35f)).coerceAtLeast(0f)
                scrolled = true
            } else if (pointerY > hotzoneBottom && scrollOffsetFloat < maxStartIndex) {
                // Makin ke bawah makin kenceng
                val intensity = ((pointerY - hotzoneBottom) / (railHeightPx - hotzoneBottom)).coerceIn(0f, 1f)
                scrollOffsetFloat = (scrollOffsetFloat + (intensity * 0.35f)).coerceAtMost(maxStartIndex.toFloat())
                scrolled = true
            }

            if (scrolled) {
                delay(16) // Delay 16ms = ~60fps smooth scrolling
            } else {
                break // Jari diam di tengah, stop looping sampai bergerak lagi
            }
        }
    }

    // Slice currently visible 27 tokens
    val currentStartIndex = scrollOffsetFloat.roundToInt().coerceIn(0, maxStartIndex)
    val visibleTokens = remember(currentStartIndex, fullTokenList) {
        val end = (currentStartIndex + windowSize).coerceAtMost(fullTokenList.size)
        fullTokenList.subList(currentStartIndex, end)
    }

    Box(
        modifier = modifier
            .padding(top = 8.dp, end = 4.dp, bottom = 84.dp)
            .fillMaxHeight()
            .testTag("vertical_alphabet_index_container")
    ) {
        // Floating Circular Preview
        if (activeLetter != null) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 34.dp)
                    .size(50.dp)
                    .offset { IntOffset(0, activePreviewOffsetY.roundToInt()) }
                    .testTag("alphabet_scroll_preview")
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = activeLetter!!,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontSize = 22.sp
                        )
                    )
                }
            }
        }

        // Fixed Viewport Vertical Alphabet Rail
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(22.dp)
                .fillMaxHeight()
                .onGloballyPositioned { coordinates ->
                    railHeightPx = coordinates.size.height.toFloat().coerceAtLeast(1f)
                }
                .pointerInput(fullTokenList, maxStartIndex) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        isTouching = true
                        pointerY = down.position.y

                        do {
                            val event = awaitPointerEvent()
                            val pointer = event.changes.firstOrNull()
                            if (pointer != null) {
                                pointer.consume()
                                pointerY = pointer.position.y
                            }
                        } while (event.changes.any { it.pressed })

                        isTouching = false
                        activeLetter = null
                    }
                }
                .testTag("alphabet_fast_scroll_rail"),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            visibleTokens.forEach { token ->
                val isSelected = activeLetter == token
                val hasData = availableTokens.contains(token)

                val textColor = when {
                    isSelected -> MaterialTheme.colorScheme.primary
                    hasData -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                    else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f)
                }

                val fontWeight = when {
                    isSelected -> FontWeight.ExtraBold
                    hasData -> FontWeight.SemiBold
                    else -> FontWeight.Normal
                }

                Text(
                    text = token,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.sp,
                        fontWeight = fontWeight,
                        color = textColor
                    ),
                    modifier = Modifier.padding(vertical = 0.2.dp)
                )
            }
        }
    }
}

/**
 * Vertical fast scrollbar / drag thumb for Date Added and Date Modified sorting.
 * Features:
 * - Single vertical thumb/scrollbar replacing the alphabet index
 * - Free fluid dragging from top to bottom
 * - Matches LazyColumn scroll position instantly
 * - Preserves the exact same rail bounds and right-side area
 */
@Composable
fun VerticalFastScrollBar(
    listState: LazyListState,
    totalItemsCount: Int,
    modifier: Modifier = Modifier,
    bottomPadding: Dp = 84.dp
) {
    val canScroll by remember {
        derivedStateOf {
            val visibleCount = listState.layoutInfo.visibleItemsInfo.size
            val totalCount = listState.layoutInfo.totalItemsCount
            (totalCount > visibleCount && visibleCount > 0) || listState.canScrollForward || listState.canScrollBackward
        }
    }

    if (!canScroll) return

    val coroutineScope = rememberCoroutineScope()
    var isDragging by remember { mutableStateOf(false) }
    var trackHeightPx by remember { mutableFloatStateOf(1f) }

    val scrollFraction by remember {
        derivedStateOf {
            if (totalItemsCount <= 1) 0f
            else {
                val firstIndex = listState.firstVisibleItemIndex
                val firstOffset = listState.firstVisibleItemScrollOffset
                val visibleItems = listState.layoutInfo.visibleItemsInfo
                val itemSize = visibleItems.firstOrNull()?.size?.toFloat() ?: 1f
                val estimatedOffset = firstIndex.toFloat() + (firstOffset / itemSize).coerceIn(0f, 1f)
                (estimatedOffset / (totalItemsCount - 1).toFloat()).coerceIn(0f, 1f)
            }
        }
    }

    val thumbHeightDp = 48.dp
    val density = LocalDensity.current
    val thumbHeightPx = with(density) { thumbHeightDp.toPx() }

    Box(
        modifier = modifier
            .padding(top = 8.dp, end = 4.dp, bottom = bottomPadding)
            .fillMaxHeight()
            .width(22.dp)
            .onGloballyPositioned { coordinates ->
                trackHeightPx = coordinates.size.height.toFloat().coerceAtLeast(1f)
            }
            .pointerInput(totalItemsCount) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    isDragging = true
                    val maxScrollableHeight = (trackHeightPx - thumbHeightPx).coerceAtLeast(1f)
                    val initialFraction = ((down.position.y - thumbHeightPx / 2f) / maxScrollableHeight).coerceIn(0f, 1f)
                    val targetIndex = (initialFraction * (totalItemsCount - 1)).roundToInt().coerceIn(0, (totalItemsCount - 1).coerceAtLeast(0))
                    coroutineScope.launch {
                        listState.scrollToItem(targetIndex)
                    }

                    do {
                        val event = awaitPointerEvent()
                        val pointer = event.changes.firstOrNull()
                        if (pointer != null) {
                            pointer.consume()
                            val frac = ((pointer.position.y - thumbHeightPx / 2f) / maxScrollableHeight).coerceIn(0f, 1f)
                            val idx = (frac * (totalItemsCount - 1)).roundToInt().coerceIn(0, (totalItemsCount - 1).coerceAtLeast(0))
                            coroutineScope.launch {
                                listState.scrollToItem(idx)
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    isDragging = false
                }
            }
            .testTag("fast_scroll_scrollbar_container")
    ) {
        val maxOffsetPx = (trackHeightPx - thumbHeightPx).coerceAtLeast(0f)
        val thumbOffsetPx = maxOffsetPx * scrollFraction

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset { IntOffset(0, thumbOffsetPx.roundToInt()) }
                .width(4.dp)
                .height(thumbHeightDp)
                .clip(RoundedCornerShape(percent = 50))
                .background(
                    if (isDragging) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                .testTag("fast_scroll_thumb")
        )
    }
}

/**
 * Vertical fast scrollbar / drag thumb for LazyVerticalGrid (e.g. Artist / Album screens in Date Added sort).
 */
@Composable
fun VerticalFastGridScrollBar(
    gridState: LazyGridState,
    totalItemsCount: Int,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var isDragging by remember { mutableStateOf(false) }
    var trackHeightPx by remember { mutableFloatStateOf(1f) }

    val scrollFraction by remember {
        derivedStateOf {
            if (totalItemsCount <= 1) 0f
            else {
                val firstIndex = gridState.firstVisibleItemIndex
                val firstOffset = gridState.firstVisibleItemScrollOffset
                val visibleItems = gridState.layoutInfo.visibleItemsInfo
                val itemSize = visibleItems.firstOrNull()?.size?.height?.toFloat() ?: 1f
                val estimatedOffset = firstIndex.toFloat() + (firstOffset / itemSize).coerceIn(0f, 1f)
                (estimatedOffset / (totalItemsCount - 1).toFloat()).coerceIn(0f, 1f)
            }
        }
    }

    val thumbHeightDp = 48.dp
    val density = LocalDensity.current
    val thumbHeightPx = with(density) { thumbHeightDp.toPx() }

    Box(
        modifier = modifier
            .padding(top = 8.dp, end = 4.dp, bottom = 84.dp)
            .fillMaxHeight()
            .width(22.dp)
            .onGloballyPositioned { coordinates ->
                trackHeightPx = coordinates.size.height.toFloat().coerceAtLeast(1f)
            }
            .pointerInput(totalItemsCount) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    isDragging = true
                    val maxScrollableHeight = (trackHeightPx - thumbHeightPx).coerceAtLeast(1f)
                    val initialFraction = ((down.position.y - thumbHeightPx / 2f) / maxScrollableHeight).coerceIn(0f, 1f)
                    val targetIndex = (initialFraction * (totalItemsCount - 1)).roundToInt().coerceIn(0, (totalItemsCount - 1).coerceAtLeast(0))
                    coroutineScope.launch {
                        gridState.scrollToItem(targetIndex)
                    }

                    do {
                        val event = awaitPointerEvent()
                        val pointer = event.changes.firstOrNull()
                        if (pointer != null) {
                            pointer.consume()
                            val frac = ((pointer.position.y - thumbHeightPx / 2f) / maxScrollableHeight).coerceIn(0f, 1f)
                            val idx = (frac * (totalItemsCount - 1)).roundToInt().coerceIn(0, (totalItemsCount - 1).coerceAtLeast(0))
                            coroutineScope.launch {
                                gridState.scrollToItem(idx)
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    isDragging = false
                }
            }
            .testTag("fast_scroll_grid_scrollbar_container")
    ) {
        val maxOffsetPx = (trackHeightPx - thumbHeightPx).coerceAtLeast(0f)
        val thumbOffsetPx = maxOffsetPx * scrollFraction

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset { IntOffset(0, thumbOffsetPx.roundToInt()) }
                .width(4.dp)
                .height(thumbHeightDp)
                .clip(RoundedCornerShape(percent = 50))
                .background(
                    if (isDragging) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                .testTag("fast_scroll_grid_thumb")
        )
    }
}
