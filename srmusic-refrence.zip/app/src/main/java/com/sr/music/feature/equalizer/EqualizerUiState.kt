package com.sr.music.feature.equalizer

data class EqualizerUiState(
    val isBitPerfectEnabled: Boolean = false,
    val selectedAudioOutput: String = "Default",
    val isEqualizerEnabled: Boolean = true,
    val selectedPreset: String = "Flat",
    val preampGain: Float = 0f, // 0 to 12 dB
    val bands: List<Float> = List(10) { 0f }, // -15 dB to +15 dB
    val bassBoost: Float = 0f, // 0 to 10 dB
    val vocalBoost: Float = 0f, // 0 to 10 dB
    val trebleBoost: Float = 0f // 0 to 10 dB
) {
    val isEqActive: Boolean
        get() = isEqualizerEnabled && !isBitPerfectEnabled
}
