package com.sr.music.feature.equalizer

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class EqualizerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(EqualizerUiState())
    val uiState: StateFlow<EqualizerUiState> = _uiState.asStateFlow()

    fun toggleBitPerfect(enabled: Boolean) {
        _uiState.update { it.copy(isBitPerfectEnabled = enabled) }
    }

    fun selectAudioOutput(output: String) {
        _uiState.update { it.copy(selectedAudioOutput = output) }
    }

    fun toggleEqualizer(enabled: Boolean) {
        _uiState.update { it.copy(isEqualizerEnabled = enabled) }
    }

    fun updatePreamp(gain: Float) {
        _uiState.update { it.copy(preampGain = gain.coerceIn(0f, 12f)) }
    }

    fun updateBand(index: Int, gain: Float) {
        if (index in 0 until 10) {
            val newBands = _uiState.value.bands.toMutableList()
            newBands[index] = gain.coerceIn(-15f, 15f)
            _uiState.update { it.copy(bands = newBands, selectedPreset = "Custom") }
        }
    }

    fun updateBassBoost(gain: Float) {
        _uiState.update { it.copy(bassBoost = gain.coerceIn(0f, 10f)) }
    }

    fun updateVocalBoost(gain: Float) {
        _uiState.update { it.copy(vocalBoost = gain.coerceIn(0f, 10f)) }
    }

    fun updateTrebleBoost(gain: Float) {
        _uiState.update { it.copy(trebleBoost = gain.coerceIn(0f, 10f)) }
    }

    fun applyPreset(presetName: String) {
        val bands = when (presetName) {
            "Bass Boost" -> listOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f)
            "Rock" -> listOf(4.5f, 3f, -1.5f, -2.5f, -1f, 1f, 3.5f, 5f, 4f, 4.5f)
            "Pop" -> listOf(-1.5f, 1.5f, 3f, 4.5f, 3.5f, 0f, -1.5f, -1.5f, -1f, -1f)
            "Classical" -> listOf(4.5f, 3.5f, 3f, 2.5f, -1.5f, -1.5f, 0f, 2f, 3.5f, 4f)
            "Vocal" -> listOf(-2f, -1.5f, 1f, 3.5f, 5f, 4.5f, 3f, 1.5f, 0f, -1f)
            "Jazz" -> listOf(3f, 2f, 1f, 2f, -1.5f, -1.5f, 0f, 1.5f, 3f, 3.5f)
            "Electronic" -> listOf(4.5f, 3.5f, 1f, 0f, -2f, 2f, 1f, 2.5f, 4f, 4.5f)
            else -> List(10) { 0f } // Flat
        }
        _uiState.update { it.copy(bands = bands, selectedPreset = presetName) }
    }

    fun resetBands() {
        _uiState.update {
            it.copy(
                bands = List(10) { 0f },
                selectedPreset = "Flat"
            )
        }
    }

    fun reset() {
        _uiState.update {
            it.copy(
                preampGain = 0f,
                bands = List(10) { 0f },
                bassBoost = 0f,
                vocalBoost = 0f,
                trebleBoost = 0f,
                selectedPreset = "Flat"
            )
        }
    }
}
