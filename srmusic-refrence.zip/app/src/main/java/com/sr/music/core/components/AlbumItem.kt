package com.sr.music.core.components

import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sr.music.core.theme.AlbumArtShape
import com.sr.music.domain.model.Album

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Alignment

@Composable
fun AlbumItem(
    album: Album,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isGrid: Boolean = false,
    gridColumns: Int = 2,
    isCarousel: Boolean = false,
    itemWidth: Dp = 150.dp
) {
    if (isCarousel) {
        // Horizontal Carousel item (realistic music-player size)
        Column(
            modifier = modifier
                .width(itemWidth)
                .clip(AlbumArtShape)
                .clickable { onClick() }
                .padding(4.dp)
                .testTag("album_carousel_item_${album.id}")
        ) {
            ArtworkCard(
                artworkUrl = album.artworkUrl,
                size = itemWidth,
                shapeType = ArtworkShape.ROUNDED_SQUARE,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = album.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.5.sp
                ),
                maxLines = 1,
                modifier = Modifier.basicMarquee()
            )

            Text(
                text = album.artist,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.5.sp
                ),
                maxLines = 1,
                modifier = Modifier.basicMarquee()
            )
        }
    } else if (isGrid) {
        val titleSize = when (gridColumns) {
            4 -> 11.sp
            3 -> 12.sp
            else -> 14.sp
        }
        val subtitleSize = when (gridColumns) {
            4 -> 10.sp
            3 -> 11.sp
            else -> 12.sp
        }

        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(AlbumArtShape)
                .clickable { onClick() }
                .padding(if (gridColumns >= 3) 4.dp else 6.dp)
                .testTag("album_grid_item_${album.id}")
        ) {
            ArtworkCard(
                artworkUrl = album.artworkUrl,
                size = 160.dp,
                shapeType = ArtworkShape.ROUNDED_SQUARE,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = album.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = titleSize
                ),
                maxLines = 1,
                modifier = Modifier.basicMarquee()
            )

            Text(
                text = album.artist,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = subtitleSize
                ),
                maxLines = 1,
                modifier = Modifier.basicMarquee()
            )
        }
    } else {
        // Vertical List mode
        Row(
            modifier = modifier
                .fillMaxWidth()
                .clickable { onClick() }
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .testTag("album_list_item_${album.id}"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArtworkCard(
                artworkUrl = album.artworkUrl,
                size = 48.dp,
                shapeType = ArtworkShape.ROUNDED_SQUARE
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = album.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    maxLines = 1,
                    modifier = Modifier.basicMarquee()
                )

                Text(
                    text = "${album.artist} • ${album.year}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    ),
                    maxLines = 1,
                    modifier = Modifier.basicMarquee()
                )
            }
        }
    }
}
