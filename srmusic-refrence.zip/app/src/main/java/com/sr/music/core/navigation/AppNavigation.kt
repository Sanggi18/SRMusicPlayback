package com.sr.music.core.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sr.music.SRMusicApplication
import com.sr.music.core.components.AppDrawerSheet
import com.sr.music.core.permission.RequestMediaPermissionEffect
import com.sr.music.core.theme.SRMusicTheme
import kotlinx.coroutines.launch
import com.sr.music.feature.album.AlbumDetailScreen
import com.sr.music.feature.album.AlbumScreen
import com.sr.music.feature.album.AlbumViewModel
import com.sr.music.feature.artist.ArtistDetailScreen
import com.sr.music.feature.artist.ArtistScreen
import com.sr.music.feature.artist.ArtistViewModel
import com.sr.music.feature.equalizer.EqualizerScreen
import com.sr.music.feature.equalizer.EqualizerViewModel
import com.sr.music.feature.folder.FolderDetailScreen
import com.sr.music.feature.folder.FolderScreen
import com.sr.music.feature.folder.FolderViewModel
import com.sr.music.feature.home.HomeScreen
import com.sr.music.feature.home.HomeViewModel
import com.sr.music.feature.lyrics.LyricsScreen
import com.sr.music.feature.lyrics.LyricsViewModel
import com.sr.music.feature.player.ExpandablePlayerSheet
import com.sr.music.feature.player.PlayerViewModel
import com.sr.music.feature.settings.SettingsScreen
import com.sr.music.feature.settings.SettingsViewModel
import com.sr.music.feature.settings.app.AppSettingsScreen
import com.sr.music.feature.settings.app.ChangelogScreen
import com.sr.music.feature.settings.app.CreditsScreen
import com.sr.music.feature.settings.app.InfoScreen
import com.sr.music.feature.settings.app.SupportScreen
import com.sr.music.feature.settings.appearance.AppThemeScreen
import com.sr.music.feature.settings.appearance.AppearanceScreen
import com.sr.music.feature.settings.appearance.CustomThemesScreen
import com.sr.music.feature.settings.appearance.FontStyleScreen
import com.sr.music.feature.settings.audio.AudioSettingsScreen
import com.sr.music.feature.settings.library.LibrarySettingsScreen
import com.sr.music.feature.settings.navigation.NavigationSettingsScreen
import com.sr.music.feature.song.SongScreen
import com.sr.music.feature.song.SongViewModel

@Composable
fun SRMusicApp(
    playerViewModel: PlayerViewModel = viewModel(),
    homeViewModel: HomeViewModel = viewModel(),
    artistViewModel: ArtistViewModel = viewModel(),
    albumViewModel: AlbumViewModel = viewModel(),
    songViewModel: SongViewModel = viewModel(),
    folderViewModel: FolderViewModel = viewModel(),
    equalizerViewModel: EqualizerViewModel = viewModel(),
    lyricsViewModel: LyricsViewModel = viewModel(),
    settingsViewModel: SettingsViewModel = viewModel()
) {
    val settingsUiState by settingsViewModel.uiState.collectAsState()
    val playerUiState by playerViewModel.uiState.collectAsState()
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    LaunchedEffect(playerUiState.currentSong) {
        lyricsViewModel.setSong(playerUiState.currentSong)
    }

    RequestMediaPermissionEffect(
        onPermissionGranted = {
            scope.launch {
                SRMusicApplication.musicRepository.syncLibrary()
            }
        }
    )

    SRMusicTheme(
        themeMode = settingsUiState.settings.themeMode,
        selectedPresetThemeId = settingsUiState.settings.selectedPresetThemeId,
        selectedPresetVariantId = settingsUiState.settings.selectedPresetVariantId,
        catppuccinVariant = settingsUiState.settings.catppuccinVariant,
        amoled = settingsUiState.settings.amoledEnabled,
        accentColor = settingsUiState.settings.accentColor,
        customAccentHex = settingsUiState.settings.customAccentHex,
        dynamicColor = settingsUiState.settings.dynamicColor,
        fontStyle = settingsUiState.settings.fontStyle
    ) {
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route

        // Active bottom tabs based on user preference
        val activeTabs = settingsUiState.settings.visibleBottomTabs.mapNotNull {
            BottomNavItem.fromRoute(it)
        }

        val isBottomBarVisible = currentRoute in settingsUiState.settings.visibleBottomTabs
        val playerExpandProgress = remember { Animatable(0f) }
        val isPlayerExpanded = playerExpandProgress.value > 0.01f

        androidx.activity.compose.BackHandler(enabled = drawerState.isOpen) {
            scope.launch { drawerState.close() }
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = drawerState.isOpen,
            drawerContent = {
                AppDrawerSheet(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        scope.launch { drawerState.close() }
                        navController.navigate(route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onCloseDrawer = {
                        scope.launch { drawerState.close() }
                    }
                )
            }
        ) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                bottomBar = {
                    if (isBottomBarVisible && !isPlayerExpanded) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            tonalElevation = 0.dp
                        ) {
                            activeTabs.forEach { item ->
                                val isSelected = currentRoute == item.route
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        navController.navigate(item.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.title
                                        )
                                    },
                                    label = { Text(item.title) },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                        selectedTextColor = MaterialTheme.colorScheme.onSurface,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag("bottom_nav_${item.title.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier.fillMaxSize()
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Level 1: Primary Bottom Navigation Destinations

                        // Home
                        composable(Screen.Home.route) {
                            HomeScreen(
                                viewModel = homeViewModel,
                                onSongClick = { song, songs ->
                                    val index = songs.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
                                    playerViewModel.playSongs(songs, index)
                                    lyricsViewModel.setSong(song)
                                },
                                onArtistClick = { artist ->
                                    navController.navigate(Screen.ArtistDetail.createRoute(artist.id))
                                },
                                onAlbumClick = { album ->
                                    navController.navigate(Screen.AlbumDetail.createRoute(album.id))
                                },
                                onMenuClick = {
                                    scope.launch { drawerState.open() }
                                },
                                onNavigateToEqualizer = { navController.navigate(Screen.Equalizer.route) },
                                onNavigateToLyrics = { navController.navigate(Screen.Lyrics.route) },
                                onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                                currentPlayingSongId = playerUiState.currentSong?.id,
                                onPlayNext = { playerViewModel.insertNextInQueue(it) },
                                onAddToQueue = { playerViewModel.addToQueue(it) }
                            )
                        }

                        // Song
                        composable(Screen.Song.route) {
                            SongScreen(
                                viewModel = songViewModel,
                                onSongClick = { song, songs ->
                                    val index = songs.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
                                    playerViewModel.playSongs(songs, index)
                                    lyricsViewModel.setSong(song)
                                },
                                onMenuClick = {
                                    scope.launch { drawerState.open() }
                                },
                                onNavigateToEqualizer = { navController.navigate(Screen.Equalizer.route) },
                                onNavigateToLyrics = { navController.navigate(Screen.Lyrics.route) },
                                onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                                currentPlayingSongId = playerUiState.currentSong?.id,
                                onPlayNext = { playerViewModel.insertNextInQueue(it) },
                                onAddToQueue = { playerViewModel.addToQueue(it) },
                                onGoToArtist = { _ ->
                                    navController.navigate(Screen.Artist.route)
                                },
                                onGoToAlbum = { _ ->
                                    navController.navigate(Screen.Album.route)
                                },
                                onGoToFolder = { _ ->
                                    navController.navigate(Screen.Folder.route)
                                }
                            )
                        }

                        // Folder
                        composable(Screen.Folder.route) {
                            FolderScreen(
                                viewModel = folderViewModel,
                                onFolderClick = { folder ->
                                    navController.navigate(Screen.FolderDetail.createRoute(folder.id))
                                },
                                onMenuClick = {
                                    scope.launch { drawerState.open() }
                                },
                                onNavigateToEqualizer = { navController.navigate(Screen.Equalizer.route) },
                                onNavigateToLyrics = { navController.navigate(Screen.Lyrics.route) },
                                onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                                onPlayFolder = { folder ->
                                    playerViewModel.playFolder(folder)
                                },
                                onPlayNextFolder = { folder ->
                                    playerViewModel.insertFolderNext(folder)
                                },
                                onAddToQueueFolder = { folder ->
                                    playerViewModel.addFolderToQueue(folder)
                                }
                            )
                        }

                        // Artist
                        composable(Screen.Artist.route) {
                            ArtistScreen(
                                viewModel = artistViewModel,
                                onArtistClick = { artist ->
                                    navController.navigate(Screen.ArtistDetail.createRoute(artist.id))
                                },
                                onMenuClick = {
                                    scope.launch { drawerState.open() }
                                },
                                onNavigateToEqualizer = { navController.navigate(Screen.Equalizer.route) },
                                onNavigateToLyrics = { navController.navigate(Screen.Lyrics.route) },
                                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                            )
                        }

                        // Album
                        composable(Screen.Album.route) {
                            AlbumScreen(
                                viewModel = albumViewModel,
                                onAlbumClick = { album ->
                                    navController.navigate(Screen.AlbumDetail.createRoute(album.id))
                                },
                                onMenuClick = {
                                    scope.launch { drawerState.open() }
                                },
                                onNavigateToEqualizer = { navController.navigate(Screen.Equalizer.route) },
                                onNavigateToLyrics = { navController.navigate(Screen.Lyrics.route) },
                                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                            )
                        }

                        // Equalizer
                    composable(Screen.Equalizer.route) {
                        EqualizerScreen(
                            viewModel = equalizerViewModel,
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Lyrics
                    composable(Screen.Lyrics.route) {
                        LyricsScreen(
                            viewModel = lyricsViewModel,
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings (Main Screen)
                    composable(Screen.Settings.route) {
                        SettingsScreen(
                            viewModel = settingsViewModel,
                            onNavigateToAppearance = { navController.navigate(Screen.SettingsAppearance.route) },
                            onNavigateToAudio = { navController.navigate(Screen.SettingsAudio.route) },
                            onNavigateToLibrary = { navController.navigate(Screen.SettingsLibrary.route) },
                            onNavigateToApp = { navController.navigate(Screen.SettingsApp.route) },
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Level 2: Settings Child Navigation

                    // Settings -> Appearance
                    composable(Screen.SettingsAppearance.route) {
                        AppearanceScreen(
                            viewModel = settingsViewModel,
                            onNavigateToTheme = { navController.navigate(Screen.SettingsTheme.route) },
                            onNavigateToFontStyle = { navController.navigate(Screen.SettingsFontStyle.route) },
                            onNavigateToBottomTabs = { navController.navigate(Screen.SettingsNavigation.route) },
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> Appearance -> Font Style
                    composable(Screen.SettingsFontStyle.route) {
                        FontStyleScreen(
                            viewModel = settingsViewModel,
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> Appearance -> App Theme
                    composable(Screen.SettingsTheme.route) {
                        AppThemeScreen(
                            viewModel = settingsViewModel,
                            onNavigateToCustomThemes = { navController.navigate(Screen.SettingsCustomThemes.route) },
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> Appearance -> App Theme -> Custom Themes
                    composable(Screen.SettingsCustomThemes.route) {
                        CustomThemesScreen(
                            viewModel = settingsViewModel,
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> Navigation
                    composable(Screen.SettingsNavigation.route) {
                        NavigationSettingsScreen(
                            viewModel = settingsViewModel,
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> Audio
                    composable(Screen.SettingsAudio.route) {
                        AudioSettingsScreen(
                            viewModel = settingsViewModel,
                            onNavigateToEqualizer = { navController.navigate(Screen.Equalizer.route) },
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> Library
                    composable(Screen.SettingsLibrary.route) {
                        LibrarySettingsScreen(
                            viewModel = settingsViewModel,
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> App
                    composable(Screen.SettingsApp.route) {
                        AppSettingsScreen(
                            viewModel = settingsViewModel,
                            onNavigateToCredits = { navController.navigate(Screen.SettingsAppCredits.route) },
                            onNavigateToSupport = { navController.navigate(Screen.SettingsAppSupport.route) },
                            onNavigateToInfo = { navController.navigate(Screen.SettingsAppInfo.route) },
                            onNavigateToChangelog = { navController.navigate(Screen.SettingsAppChangelog.route) },
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> App -> Credits
                    composable(Screen.SettingsAppCredits.route) {
                        CreditsScreen(
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> App -> Support
                    composable(Screen.SettingsAppSupport.route) {
                        SupportScreen(
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> App -> Info
                    composable(Screen.SettingsAppInfo.route) {
                        InfoScreen(
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Settings -> App -> Changelog
                    composable(Screen.SettingsAppChangelog.route) {
                        ChangelogScreen(
                            onBackClick = { navController.popBackStack() }
                        )
                    }

                    // Other Detail Screens

                    // Artist Detail
                    composable(
                        route = Screen.ArtistDetail.route,
                        arguments = listOf(navArgument("artistId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val artistId = backStackEntry.arguments?.getString("artistId") ?: ""
                        ArtistDetailScreen(
                            artistId = artistId,
                            onBackClick = { navController.popBackStack() },
                            onSongClick = { song, songs ->
                                val index = songs.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
                                playerViewModel.playSongs(songs, index)
                                lyricsViewModel.setSong(song)
                            },
                            currentPlayingSongId = playerUiState.currentSong?.id,
                            onPlayNext = { playerViewModel.insertNextInQueue(it) },
                            onAddToQueue = { playerViewModel.addToQueue(it) }
                        )
                    }

                    // Album Detail
                    composable(
                        route = Screen.AlbumDetail.route,
                        arguments = listOf(navArgument("albumId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val albumId = backStackEntry.arguments?.getString("albumId") ?: ""
                        AlbumDetailScreen(
                            albumId = albumId,
                            onBackClick = { navController.popBackStack() },
                            onSongClick = { song, songs ->
                                val index = songs.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
                                playerViewModel.playSongs(songs, index)
                                lyricsViewModel.setSong(song)
                            },
                            currentPlayingSongId = playerUiState.currentSong?.id,
                            onPlayNext = { playerViewModel.insertNextInQueue(it) },
                            onAddToQueue = { playerViewModel.addToQueue(it) }
                        )
                    }

                    // Folder Detail
                    composable(
                        route = Screen.FolderDetail.route,
                        arguments = listOf(navArgument("folderId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val folderId = backStackEntry.arguments?.getString("folderId") ?: ""
                        FolderDetailScreen(
                            folderId = folderId,
                            onBackClick = { navController.popBackStack() },
                            onSongClick = { song, songs ->
                                val index = songs.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
                                playerViewModel.playSongs(songs, index)
                                lyricsViewModel.setSong(song)
                            },
                            currentPlayingSongId = playerUiState.currentSong?.id,
                            onPlayNext = { playerViewModel.insertNextInQueue(it) },
                            onAddToQueue = { playerViewModel.addToQueue(it) }
                        )
                    }
                }

                // Interactive Expandable Player Sheet (Mini Player + Full Screen Now Playing with real-time drag transition)
                if (isBottomBarVisible) {
                    ExpandablePlayerSheet(
                        playerViewModel = playerViewModel,
                        lyricsViewModel = lyricsViewModel,
                        onNavigateToEqualizer = {
                            navController.navigate(Screen.Equalizer.route)
                        },
                        expandProgress = playerExpandProgress,
                        bottomBarHeight = innerPadding.calculateBottomPadding(),
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
}
