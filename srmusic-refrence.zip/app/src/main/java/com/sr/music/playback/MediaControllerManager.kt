package com.sr.music.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.sr.music.domain.model.Song
import com.sr.music.feature.player.PlayerUiState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MediaControllerManager private constructor(private val context: Context) {

    companion object {
        @Volatile
        private var instance: MediaControllerManager? = null

        fun getInstance(context: Context): MediaControllerManager {
            return instance ?: synchronized(this) {
                instance ?: MediaControllerManager(context.applicationContext).also { instance = it }
            }
        }
    }

    private val mainScope = CoroutineScope(Dispatchers.Main + Job())
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _uiState = MutableStateFlow(PlayerUiState(currentPositionMs = 0L, durationMs = 0L))
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var activeQueue: List<Song> = emptyList()
    private var tickerJob: Job? = null

    init {
        connectToService()
    }

    private fun connectToService() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, MusicPlaybackService::class.java)
        )
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture = future

        future.addListener({
            try {
                val mediaController = future.get()
                controller = mediaController
                mediaController.addListener(PlayerEventListener())
                syncStateFromController(mediaController)
            } catch (e: Exception) {
                // Service connection retry will happen on next command if needed
            }
        }, MoreExecutors.directExecutor())
    }

    private inner class PlayerEventListener : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            syncStateFromController(player)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updateTicker(isPlaying)
        }
    }

    private fun syncStateFromController(player: Player) {
        val currentMediaItem = player.currentMediaItem
        val currentSong = currentMediaItem?.let { item ->
            // Match with activeQueue in memory first for fast reference
            activeQueue.find { it.id == item.mediaId } ?: MediaItemMapper.toSong(item)
        }

        val duration = if (player.duration > 0) player.duration else (currentSong?.durationMs ?: 0L)
        val position = player.currentPosition.coerceAtLeast(0L)
        val isPlaying = player.isPlaying
        val isShuffle = player.shuffleModeEnabled
        val isRepeat = player.repeatMode != Player.REPEAT_MODE_OFF

        _uiState.update { current ->
            current.copy(
                currentSong = currentSong,
                isPlaying = isPlaying,
                currentPositionMs = position,
                durationMs = duration,
                isShuffleEnabled = isShuffle,
                isRepeatEnabled = isRepeat,
                isFavorite = currentSong?.isFavorite ?: current.isFavorite,
                queue = activeQueue,
                isMiniPlayerDismissed = if (isPlaying && current.isMiniPlayerDismissed) false else current.isMiniPlayerDismissed
            )
        }

        updateTicker(isPlaying)
    }

    private fun updateTicker(isPlaying: Boolean) {
        tickerJob?.cancel()
        if (isPlaying) {
            tickerJob = mainScope.launch {
                while (isActive) {
                    delay(250L)
                    val ctrl = controller
                    if (ctrl != null && ctrl.isPlaying) {
                        val pos = ctrl.currentPosition.coerceAtLeast(0L)
                        val dur = if (ctrl.duration > 0) ctrl.duration else _uiState.value.durationMs
                        _uiState.update {
                            it.copy(
                                currentPositionMs = pos,
                                durationMs = dur
                            )
                        }
                    }
                }
            }
        }
    }

    fun playSongs(songs: List<Song>, startIndex: Int = 0, startPositionMs: Long = 0L) {
        if (songs.isEmpty()) return
        activeQueue = songs
        val validIndex = startIndex.coerceIn(0, songs.size - 1)
        val targetSong = songs[validIndex]

        _uiState.update {
            it.copy(
                currentSong = targetSong,
                isPlaying = true,
                isMiniPlayerDismissed = false,
                currentPositionMs = startPositionMs,
                durationMs = targetSong.durationMs,
                queue = songs,
                isFavorite = targetSong.isFavorite
            )
        }

        val ctrl = controller
        if (ctrl != null) {
            val mediaItems = MediaItemMapper.toMediaItems(songs)
            ctrl.setMediaItems(mediaItems, validIndex, startPositionMs)
            ctrl.prepare()
            ctrl.play()
        } else {
            // Reconnect if not yet connected
            connectToService()
        }
    }

    fun playSong(song: Song) {
        val existingIndex = activeQueue.indexOfFirst { it.id == song.id }
        if (existingIndex >= 0) {
            val ctrl = controller
            if (ctrl != null) {
                ctrl.seekToDefaultPosition(existingIndex)
                ctrl.play()
            }
        } else {
            playSongs(listOf(song), 0, 0L)
        }
    }

    fun togglePlayPause() {
        val ctrl = controller ?: return
        if (ctrl.isPlaying) {
            ctrl.pause()
        } else {
            if (ctrl.playbackState == Player.STATE_IDLE && activeQueue.isNotEmpty()) {
                val mediaItems = MediaItemMapper.toMediaItems(activeQueue)
                val targetIndex = (_uiState.value.currentSong?.let { s -> activeQueue.indexOfFirst { it.id == s.id } } ?: 0).coerceAtLeast(0)
                ctrl.setMediaItems(mediaItems, targetIndex, _uiState.value.currentPositionMs)
                ctrl.prepare()
            }
            ctrl.play()
        }
    }

    fun play() {
        controller?.play()
    }

    fun pause() {
        controller?.pause()
    }

    fun playNext() {
        val ctrl = controller ?: return
        if (ctrl.hasNextMediaItem()) {
            ctrl.seekToNextMediaItem()
        } else if (activeQueue.isNotEmpty()) {
            // Loop back to start if at end
            ctrl.seekToDefaultPosition(0)
            ctrl.play()
        }
    }

    fun playPrevious() {
        val ctrl = controller ?: return
        if (ctrl.currentPosition > 3000L) {
            ctrl.seekTo(0L)
        } else if (ctrl.hasPreviousMediaItem()) {
            ctrl.seekToPreviousMediaItem()
        } else if (activeQueue.isNotEmpty()) {
            ctrl.seekToDefaultPosition(activeQueue.size - 1)
            ctrl.play()
        } else {
            ctrl.seekTo(0L)
        }
    }

    fun seekTo(positionMs: Long) {
        _uiState.update { it.copy(currentPositionMs = positionMs) }
        controller?.seekTo(positionMs)
    }

    fun toggleShuffle() {
        val ctrl = controller ?: return
        val newShuffle = !ctrl.shuffleModeEnabled
        ctrl.shuffleModeEnabled = newShuffle
        _uiState.update { it.copy(isShuffleEnabled = newShuffle) }
    }

    fun toggleRepeat() {
        val ctrl = controller ?: return
        val nextMode = when (ctrl.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        ctrl.repeatMode = nextMode
        _uiState.update { it.copy(isRepeatEnabled = nextMode != Player.REPEAT_MODE_OFF) }
    }

    fun addToQueue(song: Song) {
        if (activeQueue.any { it.id == song.id }) return
        val newQueue = activeQueue + song
        activeQueue = newQueue
        _uiState.update { it.copy(queue = newQueue) }
        controller?.addMediaItem(MediaItemMapper.toMediaItem(song))
    }

    fun insertNextInQueue(song: Song) {
        val currentSong = _uiState.value.currentSong
        val currentIndex = if (currentSong != null) activeQueue.indexOfFirst { it.id == currentSong.id } else -1
        val insertIndex = if (currentIndex >= 0) currentIndex + 1 else 0

        val mutable = activeQueue.toMutableList()
        mutable.removeAll { it.id == song.id }
        val targetIndex = insertIndex.coerceIn(0, mutable.size)
        mutable.add(targetIndex, song)
        activeQueue = mutable
        _uiState.update { it.copy(queue = mutable) }

        val ctrl = controller
        if (ctrl != null) {
            ctrl.addMediaItem(targetIndex, MediaItemMapper.toMediaItem(song))
        }
    }

    fun removeFromQueue(songId: String) {
        val index = activeQueue.indexOfFirst { it.id == songId }
        if (index >= 0) {
            val mutable = activeQueue.toMutableList()
            mutable.removeAt(index)
            activeQueue = mutable
            _uiState.update { it.copy(queue = mutable) }
            controller?.removeMediaItem(index)
        }
    }

    fun dismissMiniPlayer() {
        _uiState.update { it.copy(isMiniPlayerDismissed = true) }
        pause()
    }

    fun restoreMiniPlayer() {
        _uiState.update { it.copy(isMiniPlayerDismissed = false) }
    }

    fun setFavorite(isFavorite: Boolean) {
        _uiState.update { it.copy(isFavorite = isFavorite) }
    }
}
