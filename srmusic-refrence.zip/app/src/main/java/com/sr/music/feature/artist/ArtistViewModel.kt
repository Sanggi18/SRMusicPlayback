package com.sr.music.feature.artist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sr.music.SRMusicApplication
import com.sr.music.core.components.SortOption
import com.sr.music.domain.model.Artist
import com.sr.music.domain.repository.MusicRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ArtistViewModel(
    private val repository: MusicRepository = SRMusicApplication.musicRepository
) : ViewModel() {

    private var rawArtists: List<Artist> = emptyList()
    private val _uiState = MutableStateFlow(ArtistUiState())
    val uiState: StateFlow<ArtistUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.artists.collectLatest { artistList ->
                rawArtists = artistList
                applyFilterAndSort()
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        applyFilterAndSort()
    }

    fun updateSort(option: SortOption) {
        _uiState.update { it.copy(sortOption = option) }
        applyFilterAndSort()
    }

    fun toggleAscending() {
        _uiState.update { it.copy(isAscending = !it.isAscending) }
        applyFilterAndSort()
    }

    fun setGridColumns(cols: Int) {
        _uiState.update { it.copy(gridColumns = cols.coerceIn(1, 4)) }
    }

    private fun String.toSortKey(): String {
        val trimmed = this.trim()
        val first = trimmed.firstOrNull()?.uppercaseChar()
        return if (first != null && first in 'A'..'Z') {
            "0_${trimmed.lowercase()}"
        } else {
            "1_${trimmed.lowercase()}"
        }
    }

    private fun applyFilterAndSort() {
        val query = _uiState.value.searchQuery
        val sort = _uiState.value.sortOption
        val isAsc = _uiState.value.isAscending

        var list = if (query.isBlank()) {
            rawArtists
        } else {
            rawArtists.filter { it.name.contains(query, ignoreCase = true) }
        }

        list = when (sort) {
            SortOption.TITLE, SortOption.NAME, SortOption.ARTIST -> if (isAsc) list.sortedBy { it.name.toSortKey() } else list.sortedByDescending { it.name.toSortKey() }
            SortOption.SONG_COUNT -> if (isAsc) list.sortedBy { it.songCount } else list.sortedByDescending { it.songCount }
            else -> list
        }

        _uiState.update { it.copy(artists = list) }
    }
}
