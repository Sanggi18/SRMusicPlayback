package com.sr.music.feature.settings.appearance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sr.music.core.theme.CatppuccinVariant
import com.sr.music.core.theme.ThemeMode
import com.sr.music.core.theme.ThemePreset
import com.sr.music.core.theme.ThemePresetCatalog
import com.sr.music.core.theme.ThemeSortOption
import com.sr.music.feature.settings.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomThemesScreen(
    viewModel: SettingsViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val settings = uiState.settings
    val scrollState = rememberScrollState()

    var sortOption by remember { mutableStateOf(ThemeSortOption.POPULAR) }
    var selectedPresetForDialog by remember { mutableStateOf<ThemePreset?>(null) }

    val presets = ThemePresetCatalog.getPresets(sortOption)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Custom Themes",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick, modifier = Modifier.testTag("custom_themes_back_button")) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Sort Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Catalog (${presets.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeSortOption.entries.forEach { option ->
                        FilterChip(
                            selected = sortOption == option,
                            onClick = { sortOption = option },
                            label = { Text(option.displayName) },
                            modifier = Modifier.testTag("theme_sort_${option.name.lowercase()}")
                        )
                    }
                }
            }

            // Theme Cards Grid/List
            presets.forEach { preset ->
                val isCurrentPreset = (settings.themeMode == ThemeMode.PRESET && settings.selectedPresetThemeId == preset.id) ||
                        (settings.themeMode == ThemeMode.CATPPUCCIN && preset.id == "catppuccin")

                val activeVariantName = if (isCurrentPreset) {
                    if (settings.themeMode == ThemeMode.CATPPUCCIN) {
                        settings.catppuccinVariant.displayName
                    } else {
                        preset.variants.find { it.id == settings.selectedPresetVariantId }?.name ?: preset.defaultVariant.name
                    }
                } else null

                ThemePreviewCard(
                    preset = preset,
                    isSelected = isCurrentPreset,
                    selectedVariantName = activeVariantName,
                    onClick = {
                        selectedPresetForDialog = preset
                    }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Theme Variant Selection Dialog
    selectedPresetForDialog?.let { preset ->
        val currentVariantId = if (preset.id == "catppuccin" && settings.themeMode == ThemeMode.CATPPUCCIN) {
            settings.catppuccinVariant.name.lowercase()
        } else if (settings.selectedPresetThemeId == preset.id) {
            settings.selectedPresetVariantId
        } else {
            preset.defaultVariant.id
        }

        ThemeVariantDialog(
            preset = preset,
            initialVariantId = currentVariantId,
            onVariantSelected = { variant ->
                if (preset.id == "catppuccin") {
                    val catVariant = when (variant.id) {
                        "latte" -> CatppuccinVariant.LATTE
                        "frappe" -> CatppuccinVariant.FRAPPE
                        "macchiato" -> CatppuccinVariant.MACCHIATO
                        else -> CatppuccinVariant.MOCHA
                    }
                    viewModel.setCatppuccinVariant(catVariant)
                } else {
                    viewModel.setPresetTheme(preset.id, variant.id)
                }
                selectedPresetForDialog = null
            },
            onDismiss = { selectedPresetForDialog = null }
        )
    }
}
