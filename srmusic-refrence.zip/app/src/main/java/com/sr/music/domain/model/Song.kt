package com.sr.music.domain.model

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val trackNumber: Int = 1,
    val artworkUrl: String? = null,
    val genre: String? = null,
    val year: Int? = null,
    val folderPath: String = "/storage/emulated/0/Music",
    val uri: String = "",
    val sampleRateHz: Int? = null,
    val bitDepth: Int? = null,
    val channelCount: Int? = null,
    val bitRateKbps: Int? = null,
    val codec: String? = null,
    val isFavorite: Boolean = false,
    val embeddedLyrics: Lyrics? = null
) {
    val durationFormatted: String
        get() {
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format("%d:%02d", minutes, seconds)
        }

    val sampleRateFormatted: String
        get() {
            val sr = sampleRateHz ?: return ""
            return if (sr >= 1000) {
                val khz = sr / 1000.0
                if (khz == khz.toLong().toDouble()) {
                    "${khz.toLong()} kHz"
                } else {
                    String.format("%.1f kHz", khz)
                }
            } else {
                "$sr Hz"
            }
        }

    val bitRateFormatted: String
        get() {
            val br = bitRateKbps ?: return ""
            return "$br kbps"
        }

    val bitRate: String
        get() = bitRateFormatted

    val sampleRate: String
        get() = sampleRateFormatted

    val format: String
        get() = codec ?: ""
}
