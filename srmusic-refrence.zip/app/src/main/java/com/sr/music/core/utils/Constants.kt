package com.sr.music.core.utils

object Constants {
    const val ROUTE_HOME = "home"
    const val ROUTE_ARTIST = "artist"
    const val ROUTE_ALBUM = "album"
    const val ROUTE_SONG = "song"
    const val ROUTE_FOLDER = "folder"
    const val ROUTE_NOW_PLAYING = "now_playing"
    const val ROUTE_EQUALIZER = "equalizer"
    const val ROUTE_LYRICS = "lyrics"
    const val ROUTE_SETTINGS = "settings"

    // Settings Nested Routes
    const val ROUTE_SETTINGS_APPEARANCE = "settings_appearance"
    const val ROUTE_SETTINGS_THEME = "settings_theme"
    const val ROUTE_SETTINGS_CUSTOM_THEMES = "settings_custom_themes"
    const val ROUTE_SETTINGS_FONT_STYLE = "settings_font_style"
    const val ROUTE_SETTINGS_NAVIGATION = "settings_navigation"
    const val ROUTE_SETTINGS_AUDIO = "settings_audio"
    const val ROUTE_SETTINGS_LIBRARY = "settings_library"
    const val ROUTE_SETTINGS_APP = "settings_app"
    const val ROUTE_SETTINGS_APP_CREDITS = "settings_app_credits"
    const val ROUTE_SETTINGS_APP_SUPPORT = "settings_app_support"
    const val ROUTE_SETTINGS_APP_INFO = "settings_app_info"
    const val ROUTE_SETTINGS_APP_CHANGELOG = "settings_app_changelog"

    const val ROUTE_ALBUM_DETAIL = "album_detail/{albumId}"
    const val ROUTE_ARTIST_DETAIL = "artist_detail/{artistId}"
    const val ROUTE_FOLDER_DETAIL = "folder_detail/{folderId}"

    const val APP_VERSION = "1.0.0 (Phase 1 UI Foundation)"
}
