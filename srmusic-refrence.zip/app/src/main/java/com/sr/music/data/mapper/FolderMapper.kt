package com.sr.music.data.mapper

import com.sr.music.data.local.entity.FolderEntity
import com.sr.music.domain.model.Folder

fun FolderEntity.toDomainModel(): Folder {
    return Folder(
        id = id,
        name = name,
        path = path,
        songCount = songCount,
        parentPath = parentPath
    )
}
