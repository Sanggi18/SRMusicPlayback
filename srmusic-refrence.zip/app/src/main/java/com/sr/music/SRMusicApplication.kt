package com.sr.music

import android.app.Application
import com.sr.music.core.utils.AppPreferences
import com.sr.music.data.repository.MusicRepositoryImpl
import com.sr.music.domain.repository.MusicRepository

class SRMusicApplication : Application() {

    companion object {
        lateinit var instance: SRMusicApplication
            private set

        val musicRepository: MusicRepository by lazy {
            MusicRepositoryImpl(instance)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        AppPreferences.init(this)
    }
}

