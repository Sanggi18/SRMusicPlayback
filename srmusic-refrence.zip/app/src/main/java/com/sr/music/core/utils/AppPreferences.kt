package com.sr.music.core.utils

import android.content.Context
import android.content.SharedPreferences
import com.sr.music.core.theme.AccentColor
import com.sr.music.core.theme.AppFontStyle
import com.sr.music.core.theme.CatppuccinVariant
import com.sr.music.core.theme.ThemeMode
import com.sr.music.domain.model.AppSettings

class AppPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("srmusic_prefs", Context.MODE_PRIVATE)

    companion object {
        @Volatile
        private var INSTANCE: AppPreferences? = null

        fun init(context: Context): AppPreferences {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AppPreferences(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun get(): AppPreferences? = INSTANCE
    }

    fun loadSettings(): AppSettings {
        val defaultTabs = listOf("home", "song", "folder", "artist", "album")
        val savedTabsString = prefs.getString("visible_bottom_tabs", null)
        val tabs = if (!savedTabsString.isNullOrBlank()) {
            val loaded = savedTabsString.split(",").filter { it.isNotBlank() && it != "settings" }
            if (loaded.isNotEmpty()) loaded else defaultTabs
        } else {
            defaultTabs
        }

        val themeModeStr = prefs.getString("theme_mode", ThemeMode.LIGHT.name) ?: ThemeMode.LIGHT.name
        val themeMode = try { ThemeMode.valueOf(themeModeStr) } catch (_: Exception) { ThemeMode.LIGHT }

        val presetThemeId = prefs.getString("preset_theme_id", "catppuccin") ?: "catppuccin"
        val presetVariantId = prefs.getString("preset_variant_id", "latte") ?: "latte"

        val catpStr = prefs.getString("catppuccin_variant", CatppuccinVariant.LATTE.name) ?: CatppuccinVariant.LATTE.name
        val catpVariant = try { CatppuccinVariant.valueOf(catpStr) } catch (_: Exception) { CatppuccinVariant.LATTE }

        val amoled = prefs.getBoolean("amoled_enabled", false)

        val accentStr = prefs.getString("accent_color", AccentColor.PURPLE.name) ?: AccentColor.PURPLE.name
        val accentColor = try { AccentColor.valueOf(accentStr) } catch (_: Exception) { AccentColor.PURPLE }

        val customAccentHex = prefs.getString("custom_accent_hex", "#6750A4") ?: "#6750A4"
        val dynamicColor = prefs.getBoolean("dynamic_color", false)

        val fontStyleStr = prefs.getString("font_style", AppFontStyle.SYSTEM_DEFAULT.name) ?: AppFontStyle.SYSTEM_DEFAULT.name
        val fontStyle = try { AppFontStyle.valueOf(fontStyleStr) } catch (_: Exception) { AppFontStyle.fromId(fontStyleStr) }

        val embedArtwork = prefs.getBoolean("prefer_embedded_artwork", true)
        val procArtwork = prefs.getBoolean("procedural_artwork", true)
        val splitArtist = prefs.getBoolean("split_multi_artist", true)
        val filterShort = prefs.getBoolean("filter_short_audio", true)

        val gapless = prefs.getBoolean("gapless_playback", true)
        val crossfade = prefs.getInt("crossfade_duration", 0)
        val replayGain = prefs.getBoolean("replay_gain_enabled", false)
        val replayGainMode = prefs.getString("replay_gain_mode", "Track") ?: "Track"
        val playbackSpeed = prefs.getFloat("playback_speed", 1.0f)
        val bitPerfect = prefs.getBoolean("bit_perfect_enabled", false)

        return AppSettings(
            themeMode = themeMode,
            selectedPresetThemeId = presetThemeId,
            selectedPresetVariantId = presetVariantId,
            catppuccinVariant = catpVariant,
            amoledEnabled = amoled,
            accentColor = accentColor,
            customAccentHex = customAccentHex,
            dynamicColor = dynamicColor,
            fontStyle = fontStyle,
            visibleBottomTabs = tabs,
            gaplessPlayback = gapless,
            crossfadeDurationSec = crossfade,
            isReplayGainEnabled = replayGain,
            replayGainMode = replayGainMode,
            playbackSpeed = playbackSpeed,
            isBitPerfectEnabled = bitPerfect,
            preferEmbeddedArtwork = embedArtwork,
            proceduralArtwork = procArtwork,
            splitMultiArtist = splitArtist,
            filterShortAudio = filterShort
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit().apply {
            putString("visible_bottom_tabs", settings.visibleBottomTabs.joinToString(","))
            putString("theme_mode", settings.themeMode.name)
            putString("preset_theme_id", settings.selectedPresetThemeId)
            putString("preset_variant_id", settings.selectedPresetVariantId)
            putString("catppuccin_variant", settings.catppuccinVariant.name)
            putBoolean("amoled_enabled", settings.amoledEnabled)
            putString("accent_color", settings.accentColor.name)
            putString("custom_accent_hex", settings.customAccentHex)
            putBoolean("dynamic_color", settings.dynamicColor)
            putString("font_style", settings.fontStyle.name)
            putBoolean("gapless_playback", settings.gaplessPlayback)
            putInt("crossfade_duration", settings.crossfadeDurationSec)
            putBoolean("replay_gain_enabled", settings.isReplayGainEnabled)
            putString("replay_gain_mode", settings.replayGainMode)
            putFloat("playback_speed", settings.playbackSpeed)
            putBoolean("bit_perfect_enabled", settings.isBitPerfectEnabled)
            putBoolean("prefer_embedded_artwork", settings.preferEmbeddedArtwork)
            putBoolean("procedural_artwork", settings.proceduralArtwork)
            putBoolean("split_multi_artist", settings.splitMultiArtist)
            putBoolean("filter_short_audio", settings.filterShortAudio)
            apply()
        }
    }
}
