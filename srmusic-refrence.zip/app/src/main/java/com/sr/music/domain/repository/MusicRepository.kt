package com.sr.music.domain.repository

import com.sr.music.domain.model.Album
import com.sr.music.domain.model.Artist
import com.sr.music.domain.model.Folder
import com.sr.music.domain.model.Song
import kotlinx.coroutines.flow.Flow

data class SyncResult(
    val addedCount: Int = 0,
    val updatedCount: Int = 0,
    val removedCount: Int = 0,
    val totalCount: Int = 0,
    val isSuccess: Boolean = true,
    val errorMessage: String? = null
)

interface MusicRepository {
    val songs: Flow<List<Song>>
    val recentlyAddedSongs: Flow<List<Song>>
    val albums: Flow<List<Album>>
    val artists: Flow<List<Artist>>
    val folders: Flow<List<Folder>>
    val favoriteSongs: Flow<List<Song>>
    val songCount: Flow<Int>

    suspend fun syncLibrary(forceFullScan: Boolean = false): SyncResult
    fun getSongsByAlbum(album: String, artist: String): Flow<List<Song>>
    fun getSongsByArtist(artist: String): Flow<List<Song>>
    fun getSongsByFolder(folderPath: String): Flow<List<Song>>
    fun searchSongs(query: String): Flow<List<Song>>
    fun searchAlbums(query: String): Flow<List<Album>>
    fun searchArtists(query: String): Flow<List<Artist>>
    fun searchFolders(query: String): Flow<List<Folder>>
    suspend fun toggleFavorite(songId: String)
    suspend fun updatePlayCount(songId: String)
    suspend fun deleteSong(songId: String)
}
