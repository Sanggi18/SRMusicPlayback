package com.sr.music.data.mediastore

import android.content.ContentUris
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File

sealed interface MediaStoreScanResult {
    data class Success(val audioFiles: List<ScannedAudio>) : MediaStoreScanResult
    data class Failure(val exception: Exception) : MediaStoreScanResult
}

class MediaStoreScanner(private val context: Context) {

    fun scanAudioFiles(
        filterShortAudio: Boolean = true,
        minDurationMs: Long = 15000L
    ): MediaStoreScanResult {
        val audioList = mutableListOf<ScannedAudio>()
        val contentResolver = context.contentResolver

        val collectionUri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ARTIST_ID,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.MIME_TYPE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            projection.add(MediaStore.Audio.Media.ALBUM_ARTIST)
            projection.add(MediaStore.Audio.Media.GENRE)
        }

        val selection = StringBuilder("${MediaStore.Audio.Media.IS_MUSIC} != 0")
        if (filterShortAudio) {
            selection.append(" AND ${MediaStore.Audio.Media.DURATION} >= $minDurationMs")
        }

        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            contentResolver.query(
                collectionUri,
                projection.toTypedArray(),
                selection.toString(),
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val artistIdCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST_ID)
                val albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val trackCol = cursor.getColumnIndex(MediaStore.Audio.Media.TRACK)
                val yearCol = cursor.getColumnIndex(MediaStore.Audio.Media.YEAR)
                val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val dateAddedCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                val dateModifiedCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED)
                val mimeTypeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)

                val albumArtistCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ARTIST)
                } else -1

                val genreCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.GENRE)
                } else -1

                while (cursor.moveToNext()) {
                    val mediaStoreId = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(collectionUri, mediaStoreId)
                    val contentUriString = contentUri.toString()

                    val rawPath = if (dataCol != -1) cursor.getString(dataCol) ?: "" else ""
                    val path = if (rawPath.isBlank()) {
                        contentUriString
                    } else {
                        rawPath
                    }

                    val fallbackFileName = if (path.isNotBlank()) {
                        File(path).nameWithoutExtension
                    } else "Track $mediaStoreId"

                    val rawTitle = if (titleCol != -1) cursor.getString(titleCol) else null
                    val title = if (rawTitle.isNullOrBlank() || rawTitle == "<unknown>") {
                        fallbackFileName.ifBlank { "Unknown Title" }
                    } else {
                        rawTitle.trim()
                    }

                    val rawArtist = if (artistCol != -1) cursor.getString(artistCol) else null
                    val artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") {
                        "Unknown Artist"
                    } else {
                        rawArtist.trim()
                    }

                    val artistId = if (artistIdCol != -1) cursor.getLong(artistIdCol) else 0L

                    val rawAlbum = if (albumCol != -1) cursor.getString(albumCol) else null
                    val album = if (rawAlbum.isNullOrBlank() || rawAlbum == "<unknown>") {
                        "Unknown Album"
                    } else {
                        rawAlbum.trim()
                    }

                    val albumId = if (albumIdCol != -1) cursor.getLong(albumIdCol) else 0L

                    val albumArtist = if (albumArtistCol != -1) cursor.getString(albumArtistCol)?.trim() else null

                    val durationMs = if (durationCol != -1) cursor.getLong(durationCol) else 0L
                    val rawTrack = if (trackCol != -1) cursor.getInt(trackCol) else 1
                    val trackNumber = if (rawTrack >= 1000) rawTrack % 1000 else (if (rawTrack > 0) rawTrack else 1)
                    val discNumber = if (rawTrack >= 1000) rawTrack / 1000 else 1

                    val year = if (yearCol != -1) {
                        val y = cursor.getInt(yearCol)
                        if (y > 0) y else null
                    } else null

                    val genre = if (genreCol != -1) cursor.getString(genreCol)?.trim() else null

                    val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                    val dateAdded = if (dateAddedCol != -1) cursor.getLong(dateAddedCol) else System.currentTimeMillis() / 1000
                    val dateModified = if (dateModifiedCol != -1) cursor.getLong(dateModifiedCol) else System.currentTimeMillis() / 1000
                    val mimeType = if (mimeTypeCol != -1) cursor.getString(mimeTypeCol) else null

                    val folderPath = if (path.isNotBlank()) {
                        try {
                            File(path).parent ?: "/storage/emulated/0/Music"
                        } catch (_: Exception) {
                            "/storage/emulated/0/Music"
                        }
                    } else {
                        "/storage/emulated/0/Music"
                    }

                    // Extract actual raw audio metadata via MediaMetadataRetriever
                    val audioMetadata = extractAudioMetadata(contentUri, path, mimeType)

                    audioList.add(
                        ScannedAudio(
                            mediaStoreId = mediaStoreId,
                            uri = contentUriString,
                            title = title,
                            artist = artist,
                            artistId = artistId,
                            album = album,
                            albumId = albumId,
                            albumArtist = albumArtist,
                            durationMs = durationMs,
                            trackNumber = trackNumber,
                            discNumber = discNumber,
                            year = year,
                            genre = genre,
                            path = path,
                            folderPath = folderPath,
                            size = size,
                            dateAdded = dateAdded,
                            dateModified = dateModified,
                            mimeType = mimeType,
                            sampleRateHz = audioMetadata.sampleRateHz,
                            bitDepth = audioMetadata.bitDepth,
                            channelCount = audioMetadata.channelCount,
                            bitRateKbps = audioMetadata.bitRateKbps,
                            codec = audioMetadata.codec
                        )
                    )
                }
            }
            return MediaStoreScanResult.Success(audioList)
        } catch (e: Exception) {
            return MediaStoreScanResult.Failure(e)
        }
    }

    private data class ExtractedAudioMetadata(
        val sampleRateHz: Int? = null,
        val bitDepth: Int? = null,
        val channelCount: Int? = null,
        val bitRateKbps: Int? = null,
        val codec: String? = null
    )

    private fun extractAudioMetadata(
        contentUri: Uri,
        filePath: String,
        mimeType: String?
    ): ExtractedAudioMetadata {
        var channelCount: Int? = null

        val retriever = MediaMetadataRetriever()
        var sampleRate: Int? = null
        var bitRateKbps: Int? = null
        var bitDepth: Int? = null
        var codec: String? = null

        try {
            if (filePath.isNotBlank() && File(filePath).exists()) {
                retriever.setDataSource(filePath)
            } else {
                retriever.setDataSource(context, contentUri)
            }

            val sr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)
            if (!sr.isNullOrBlank()) {
                val parsed = sr.toIntOrNull()
                if (parsed != null && parsed > 0) {
                    sampleRate = parsed
                }
            }

            val br = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            if (!br.isNullOrBlank()) {
                val parsed = br.toIntOrNull()
                if (parsed != null && parsed > 0) {
                    bitRateKbps = parsed / 1000
                }
            }

            val mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            if (!mime.isNullOrBlank()) {
                codec = mime
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val bits = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE)
                if (!bits.isNullOrBlank()) {
                    val parsed = bits.toIntOrNull()
                    if (parsed != null && parsed > 0) {
                        bitDepth = parsed
                    }
                }
            }
        } catch (_: Exception) {
            // Keep as null if not extractable
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        // Extract channel count from audio track format
        val extractor = MediaExtractor()
        try {
            if (filePath.isNotBlank() && File(filePath).exists()) {
                extractor.setDataSource(filePath)
            } else {
                extractor.setDataSource(context, contentUri, null)
            }
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME)
                if (mime?.startsWith("audio/") == true) {
                    if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        val cc = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (cc > 0) {
                            channelCount = cc
                        }
                    }
                    if (sampleRate == null && format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        val sr = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (sr > 0) {
                            sampleRate = sr
                        }
                    }
                    if (bitRateKbps == null && format.containsKey(MediaFormat.KEY_BIT_RATE)) {
                        val br = format.getInteger(MediaFormat.KEY_BIT_RATE)
                        if (br > 0) {
                            bitRateKbps = br / 1000
                        }
                    }
                    break
                }
            }
        } catch (_: Exception) {
            // Keep as null if not extractable
        } finally {
            try {
                extractor.release()
            } catch (_: Exception) {}
        }

        if (codec == null && !mimeType.isNullOrBlank()) {
            codec = mimeType
        }

        return ExtractedAudioMetadata(
            sampleRateHz = sampleRate,
            bitDepth = bitDepth,
            channelCount = channelCount,
            bitRateKbps = bitRateKbps,
            codec = codec
        )
    }
}
