package com.sr.music.domain.model

enum class EmbeddedLyricsFormat {
    NONE,
    SYNCED,
    WORD_BY_WORD,
    UNSYNCHRONIZED
}

data class LyricWord(
    val timestampMs: Long,
    val text: String
)

data class LyricLine(
    val timestampMs: Long,
    val text: String,
    val words: List<LyricWord> = emptyList()
)

data class Lyrics(
    val songId: String,
    val format: EmbeddedLyricsFormat = EmbeddedLyricsFormat.SYNCED,
    val isSynced: Boolean = true,
    val lines: List<LyricLine> = emptyList(),
    val plainText: String = ""
)
