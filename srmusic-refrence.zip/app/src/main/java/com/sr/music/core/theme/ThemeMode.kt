package com.sr.music.core.theme

enum class ThemeMode(val displayName: String) {
    SYSTEM("Follow System"),
    LIGHT("Light"),
    DARK("Dark"),
    AMOLED("AMOLED"),
    CATPPUCCIN("Catppuccin"),
    PRESET("Custom Theme")
}

enum class CatppuccinVariant(val displayName: String) {
    LATTE("Latte (Light)"),
    FRAPPE("Frappé (Dark)"),
    MACCHIATO("Macchiato (Dark)"),
    MOCHA("Mocha (Dark)")
}
