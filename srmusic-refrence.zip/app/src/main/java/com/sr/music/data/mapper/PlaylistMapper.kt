package com.sr.music.data.mapper

import com.sr.music.data.local.entity.PlaylistEntity
import com.sr.music.domain.model.Playlist

fun PlaylistEntity.toDomainModel(): Playlist {
    return Playlist(
        id = id.toString(),
        name = name,
        songCount = songCount,
        artworkUrl = artworkUrl
    )
}
