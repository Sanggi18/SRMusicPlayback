package com.sr.music.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sr.music.core.components.EmptyState

private data class SearchableSettingItem(
    val title: String,
    val subtitle: String,
    val category: String,
    val icon: ImageVector,
    val onAction: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateToAppearance: () -> Unit = {},
    onNavigateToAudio: () -> Unit = {},
    onNavigateToLibrary: () -> Unit = {},
    onNavigateToApp: () -> Unit = {},
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    val allSearchableItems = remember(onNavigateToAppearance, onNavigateToAudio, onNavigateToLibrary, onNavigateToApp) {
        listOf(
            // Appearance
            SearchableSettingItem("App Theme", "Theme mode, Dark, Light, AMOLED, Custom Themes", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),
            SearchableSettingItem("Dynamic Color", "Android Material You wallpaper-derived colors", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),
            SearchableSettingItem("Accent Color", "Custom RGB sliders and HEX color picker", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),
            SearchableSettingItem("Custom Themes", "Catppuccin, Tokyo Night, Dracula, Nord, Cyberpunk presets", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),
            SearchableSettingItem("Bottom Tabs", "Reorder, show, and hide bottom navigation tabs", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),
            SearchableSettingItem("Switch Style", "Material 3 / iOS toggle switches", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),
            SearchableSettingItem("Now Playing", "Player layout and artwork display", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),
            SearchableSettingItem("Lyrics Style", "Typography and animation effects", "Appearance", Icons.Rounded.Palette, onNavigateToAppearance),

            // Audio
            SearchableSettingItem("Equalizer", "10-Band Graphic EQ, Presets, Tone Controls", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),
            SearchableSettingItem("Bit Perfect Mode", "Hardware direct audio output without DSP", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),
            SearchableSettingItem("Audio Output", "Auto-detect, AAudio, AudioTrack, OpenSL ES", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),
            SearchableSettingItem("Preamp Gain", "Preamplifier gain volume boost", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),
            SearchableSettingItem("Gapless Playback", "Seamless track transitions", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),
            SearchableSettingItem("Crossfade", "Smooth volume fading between tracks", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),
            SearchableSettingItem("ReplayGain", "Volume normalization across library", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),
            SearchableSettingItem("Playback Speed", "Adjust audio playback rate", "Audio", Icons.Rounded.Equalizer, onNavigateToAudio),

            // Library
            SearchableSettingItem("Music Folders", "Select included & excluded audio folders", "Library", Icons.Rounded.LibraryMusic, onNavigateToLibrary),
            SearchableSettingItem("Media Scanner", "Scan device storage for audio files", "Library", Icons.Rounded.LibraryMusic, onNavigateToLibrary),
            SearchableSettingItem("Artwork Settings", "Embedded & procedural album art", "Library", Icons.Rounded.LibraryMusic, onNavigateToLibrary),
            SearchableSettingItem("Split Multi-Artist", "Separate multiple artists by delimiter", "Library", Icons.Rounded.LibraryMusic, onNavigateToLibrary),
            SearchableSettingItem("Filter Short Audio", "Exclude ringtones and notification sounds", "Library", Icons.Rounded.LibraryMusic, onNavigateToLibrary),

            // App
            SearchableSettingItem("Open Source Credits", "Third-party libraries & open source licenses", "App", Icons.Rounded.Info, onNavigateToApp),
            SearchableSettingItem("Support Development", "Developer support & project donations", "App", Icons.Rounded.Info, onNavigateToApp),
            SearchableSettingItem("Info SRMusic", "Version, build & system information", "App", Icons.Rounded.Info, onNavigateToApp),
            SearchableSettingItem("Changelog", "Release notes and recent updates", "App", Icons.Rounded.Info, onNavigateToApp)
        )
    }

    val filteredItems = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            emptyList()
        } else {
            val query = searchQuery.trim().lowercase()
            allSearchableItems.filter {
                it.title.lowercase().contains(query) ||
                        it.subtitle.lowercase().contains(query) ||
                        it.category.lowercase().contains(query)
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Local Settings Search Container
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("settings_search_bar")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search Settings",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Box(modifier = Modifier.weight(1f)) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "Search settings...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_search_input")
                        )
                    }

                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("settings_search_clear")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Clear,
                                contentDescription = "Clear search",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            if (searchQuery.isNotBlank()) {
                // Search Results
                if (filteredItems.isEmpty()) {
                    EmptyState(
                        title = "No settings found",
                        subtitle = "No settings match '$searchQuery'"
                    )
                } else {
                    filteredItems.forEach { item ->
                        SearchResultItemCard(item = item)
                    }
                }
            } else {
                // Main Settings Category Cards
                // 1. Appearance >
                SettingsCategoryCard(
                    icon = Icons.Rounded.Palette,
                    title = "Appearance",
                    subtitle = "App Theme, Bottom Tabs, Lyrics Style",
                    onClick = onNavigateToAppearance,
                    testTag = "settings_category_appearance"
                )

                // 2. Audio >
                SettingsCategoryCard(
                    icon = Icons.Rounded.Equalizer,
                    title = "Audio",
                    subtitle = "DSP, ReplayGain, Speed, Pitch, Crossfade, Output",
                    onClick = onNavigateToAudio,
                    testTag = "settings_category_audio"
                )

                // 3. Library >
                SettingsCategoryCard(
                    icon = Icons.Rounded.LibraryMusic,
                    title = "Library",
                    subtitle = "Music Folders, Scanner, Blacklist, Auto-rescan",
                    onClick = onNavigateToLibrary,
                    testTag = "settings_category_library"
                )

                // 4. App >
                SettingsCategoryCard(
                    icon = Icons.Rounded.Info,
                    title = "App",
                    subtitle = "Version, Backup & Restore, Cache, Reset",
                    onClick = onNavigateToApp,
                    testTag = "settings_category_app"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SearchResultItemCard(
    item: SearchableSettingItem
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = item.onAction)
            .testTag("setting_result_${item.title.lowercase().replace(" ", "_")}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = item.category,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 10.sp
                                ),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = item.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun SettingsCategoryCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
