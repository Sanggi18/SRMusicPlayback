package com.sr.music.data.mapper

import com.sr.music.data.local.entity.AlbumEntity
import com.sr.music.domain.model.Album

fun AlbumEntity.toDomainModel(): Album {
    return Album(
        id = id,
        title = title,
        artist = artist,
        year = year,
        songCount = songCount,
        artworkUrl = artworkUrl
    )
}
