package com.sr.music.feature.song

import com.sr.music.core.components.SortOption
import com.sr.music.domain.model.Song

data class SongUiState(
    val songs: List<Song> = emptyList(),
    val searchQuery: String = "",
    val sortOption: SortOption = SortOption.TITLE,
    val selectedIndex: String? = null,
    val isAscending: Boolean = true,
    val isLoading: Boolean = false
)
