package com.sr.music.core.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sr.music.core.theme.AlbumArtShape

enum class ArtworkShape {
    CIRCLE,
    ROUNDED_SQUARE
}

@Composable
fun ArtworkCard(
    artworkUrl: String?,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    shapeType: ArtworkShape = ArtworkShape.ROUNDED_SQUARE,
    cornerRadius: Dp = 12.dp,
    contentDescription: String? = "Artwork"
) {
    val shape: Shape = when (shapeType) {
        ArtworkShape.CIRCLE -> CircleShape
        ArtworkShape.ROUNDED_SQUARE -> AlbumArtShape
    }

    // 100% Offline Procedural Gradient Artwork
    val seed = (contentDescription ?: "Artwork").hashCode()
    val colorIndex = kotlin.math.abs(seed) % 6
    val (startColor, endColor) = when (colorIndex) {
        0 -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.secondaryContainer
        1 -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.tertiaryContainer
        2 -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.primaryContainer
        3 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.85f) to MaterialTheme.colorScheme.secondary.copy(alpha = 0.85f)
        4 -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.85f) to MaterialTheme.colorScheme.tertiary.copy(alpha = 0.85f)
        else -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.surfaceVariant
    }

    val gradient = Brush.linearGradient(listOf(startColor, endColor))

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {
        val icon = when {
            shapeType == ArtworkShape.CIRCLE -> Icons.Default.Person
            size >= 140.dp -> Icons.Default.Album
            else -> Icons.Default.MusicNote
        }
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
            modifier = Modifier.size(size * 0.42f)
        )
    }
}
