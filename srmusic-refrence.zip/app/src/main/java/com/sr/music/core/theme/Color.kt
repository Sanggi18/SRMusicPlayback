package com.sr.music.core.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// SRMusic Default Palette
// ==========================================

// Light Base
val SRMusicBgLight = Color(0xFFFFFFFF)
val SRMusicSurfaceLight = Color(0xFFF7F7F7)
val SRMusicSurfaceVariantLight = Color(0xFFEFEFF4)
val SRMusicOnBgLight = Color(0xFF1C1B1F)
val SRMusicOnSurfaceLight = Color(0xFF1C1B1F)
val SRMusicOnSurfaceVariantLight = Color(0xFF49454F)
val SRMusicOutlineLight = Color(0xFFCAC4D0)
val SRMusicOutlineVariantLight = Color(0xFFE6E0E9)

// Dark Base
val SRMusicBgDark = Color(0xFF1C1B1F)
val SRMusicSurfaceDark = Color(0xFF25232A)
val SRMusicSurfaceVariantDark = Color(0xFF302D38)
val SRMusicOnBgDark = Color(0xFFE6E1E5)
val SRMusicOnSurfaceDark = Color(0xFFE6E1E5)
val SRMusicOnSurfaceVariantDark = Color(0xFFCAC4D0)
val SRMusicOutlineDark = Color(0xFF938F99)
val SRMusicOutlineVariantDark = Color(0xFF49454F)

// AMOLED Base (True Black #000000)
val AmoledBg = Color(0xFF000000)
val AmoledSurface = Color(0xFF0A0A0E)
val AmoledSurfaceVariant = Color(0xFF141418)
val AmoledOnBg = Color(0xFFE6E1E5)
val AmoledOnSurface = Color(0xFFE6E1E5)
val AmoledOnSurfaceVariant = Color(0xFFCAC4D0)
val AmoledOutline = Color(0xFF79747E)
val AmoledOutlineVariant = Color(0xFF383838)

// ==========================================
// Catppuccin Official Palettes
// ==========================================

// Catppuccin Latte (Light)
object CatppuccinLatte {
    val Rosewater = Color(0xFFDC8A78)
    val Flamingo = Color(0xFFDD7878)
    val Pink = Color(0xFFEA76CB)
    val Mauve = Color(0xFF8839EF)
    val Red = Color(0xFFD20F39)
    val Maroon = Color(0xFFE64553)
    val Peach = Color(0xFFFE640B)
    val Yellow = Color(0xFFDF8E1D)
    val Green = Color(0xFF40A02B)
    val Teal = Color(0xFF179299)
    val Sky = Color(0xFF04A5E5)
    val Sapphire = Color(0xFF209FB5)
    val Blue = Color(0xFF1E66F5)
    val Lavender = Color(0xFF7287FD)
    val Text = Color(0xFF4C4F69)
    val Subtext1 = Color(0xFF5C5F77)
    val Subtext0 = Color(0xFF6C6F85)
    val Overlay2 = Color(0xFF7C7F93)
    val Overlay1 = Color(0xFF8C8FA1)
    val Overlay0 = Color(0xFF9CA0B0)
    val Surface2 = Color(0xFFACB0BE)
    val Surface1 = Color(0xFFBCC0CC)
    val Surface0 = Color(0xFFCCD0DA)
    val Base = Color(0xFFEFF1F5)
    val Mantle = Color(0xFFE6E9EF)
    val Crust = Color(0xFFDCE0E8)
}

// Catppuccin Frappé (Dark)
object CatppuccinFrappe {
    val Rosewater = Color(0xFFF2D5CF)
    val Flamingo = Color(0xFFEEBEBE)
    val Pink = Color(0xFFF4B8E4)
    val Mauve = Color(0xFFCA9EE6)
    val Red = Color(0xFFE78284)
    val Maroon = Color(0xFFEA999C)
    val Peach = Color(0xFFEF9F76)
    val Yellow = Color(0xFFE5C890)
    val Green = Color(0xFFA6D189)
    val Teal = Color(0xFF81C8BE)
    val Sky = Color(0xFF99D1DB)
    val Sapphire = Color(0xFF85C1DC)
    val Blue = Color(0xFF8CAAEE)
    val Lavender = Color(0xFFBABBF1)
    val Text = Color(0xFFC6D0F5)
    val Subtext1 = Color(0xFFB5BFE2)
    val Subtext0 = Color(0xFFA5ADCE)
    val Overlay2 = Color(0xFF949CBB)
    val Overlay1 = Color(0xFF838BA7)
    val Overlay0 = Color(0xFF737994)
    val Surface2 = Color(0xFF626880)
    val Surface1 = Color(0xFF51576D)
    val Surface0 = Color(0xFF414559)
    val Base = Color(0xFF303446)
    val Mantle = Color(0xFF292C3C)
    val Crust = Color(0xFF232634)
}

// Catppuccin Macchiato (Dark)
object CatppuccinMacchiato {
    val Rosewater = Color(0xFFF4DBD6)
    val Flamingo = Color(0xFFF0C6C6)
    val Pink = Color(0xFFF5BDE6)
    val Mauve = Color(0xFFC6A0F6)
    val Red = Color(0xFFED8796)
    val Maroon = Color(0xFFEE99A0)
    val Peach = Color(0xFFF5A97F)
    val Yellow = Color(0xFFEED49F)
    val Green = Color(0xFFA6DA95)
    val Teal = Color(0xFF8BD5CA)
    val Sky = Color(0xFF91D7E3)
    val Sapphire = Color(0xFF7DC4E4)
    val Blue = Color(0xFF8AADF4)
    val Lavender = Color(0xFFB7BDF8)
    val Text = Color(0xFFCAD3F5)
    val Subtext1 = Color(0xFFB8C0E0)
    val Subtext0 = Color(0xFFA5ADCB)
    val Overlay2 = Color(0xFF939AB7)
    val Overlay1 = Color(0xFF8087A2)
    val Overlay0 = Color(0xFF6E738D)
    val Surface2 = Color(0xFF5B6078)
    val Surface1 = Color(0xFF494D64)
    val Surface0 = Color(0xFF363A4F)
    val Base = Color(0xFF24273A)
    val Mantle = Color(0xFF1E2030)
    val Crust = Color(0xFF181926)
}

// Catppuccin Mocha (Dark)
object CatppuccinMocha {
    val Rosewater = Color(0xFFF5E0DC)
    val Flamingo = Color(0xFFF2CDCD)
    val Pink = Color(0xFFF5C2E7)
    val Mauve = Color(0xFFCBA6F7)
    val Red = Color(0xFFF38BA8)
    val Maroon = Color(0xFFEBA0AC)
    val Peach = Color(0xFFFAB387)
    val Yellow = Color(0xFFF9E2AF)
    val Green = Color(0xFFA6E3A1)
    val Teal = Color(0xFF94E2D5)
    val Sky = Color(0xFF89DCEB)
    val Sapphire = Color(0xFF74C7EC)
    val Blue = Color(0xFF89B4FA)
    val Lavender = Color(0xFFB4BEFE)
    val Text = Color(0xFFCDD6F4)
    val Subtext1 = Color(0xFFBAC2DE)
    val Subtext0 = Color(0xFFA6ADC8)
    val Overlay2 = Color(0xFF9399B2)
    val Overlay1 = Color(0xFF7F849C)
    val Overlay0 = Color(0xFF6C7086)
    val Surface2 = Color(0xFF585B70)
    val Surface1 = Color(0xFF45475A)
    val Surface0 = Color(0xFF313244)
    val Base = Color(0xFF1E1E2E)
    val Mantle = Color(0xFF181825)
    val Crust = Color(0xFF11111B)
}

// ==========================================
// Accent Color Specs
// ==========================================

data class AccentSpec(
    val primaryLight: Color,
    val onPrimaryLight: Color,
    val primaryContainerLight: Color,
    val onPrimaryContainerLight: Color,
    val secondaryLight: Color,
    val primaryDark: Color,
    val onPrimaryDark: Color,
    val primaryContainerDark: Color,
    val onPrimaryContainerDark: Color,
    val secondaryDark: Color
)

val PurpleAccent = AccentSpec(
    primaryLight = Color(0xFF6750A4),
    onPrimaryLight = Color(0xFFFFFFFF),
    primaryContainerLight = Color(0xFFE8DEF8),
    onPrimaryContainerLight = Color(0xFF21005D),
    secondaryLight = Color(0xFF625B71),
    primaryDark = Color(0xFFD0BCFF),
    onPrimaryDark = Color(0xFF381E72),
    primaryContainerDark = Color(0xFF4F378B),
    onPrimaryContainerDark = Color(0xFFEADDFF),
    secondaryDark = Color(0xFFCCC2DC)
)

val BlueAccent = AccentSpec(
    primaryLight = Color(0xFF1E66F5),
    onPrimaryLight = Color(0xFFFFFFFF),
    primaryContainerLight = Color(0xFFDCE8FD),
    onPrimaryContainerLight = Color(0xFF001E50),
    secondaryLight = Color(0xFF535F70),
    primaryDark = Color(0xFF89B4FA),
    onPrimaryDark = Color(0xFF003062),
    primaryContainerDark = Color(0xFF004689),
    onPrimaryContainerDark = Color(0xFFD6E4FF),
    secondaryDark = Color(0xFFBBC7DB)
)

val TealAccent = AccentSpec(
    primaryLight = Color(0xFF006A6A),
    onPrimaryLight = Color(0xFFFFFFFF),
    primaryContainerLight = Color(0xFF9CF1F0),
    onPrimaryContainerLight = Color(0xFF002020),
    secondaryLight = Color(0xFF4A6363),
    primaryDark = Color(0xFF80D5D4),
    onPrimaryDark = Color(0xFF003737),
    primaryContainerDark = Color(0xFF004F4F),
    onPrimaryContainerDark = Color(0xFF9CF1F0),
    secondaryDark = Color(0xFFB1CCCC)
)

val GreenAccent = AccentSpec(
    primaryLight = Color(0xFF2E6C2E),
    onPrimaryLight = Color(0xFFFFFFFF),
    primaryContainerLight = Color(0xFFB0F4AC),
    onPrimaryContainerLight = Color(0xFF002204),
    secondaryLight = Color(0xFF53634F),
    primaryDark = Color(0xFF95D892),
    onPrimaryDark = Color(0xFF003A0B),
    primaryContainerDark = Color(0xFF145318),
    onPrimaryContainerDark = Color(0xFFB0F4AC),
    secondaryDark = Color(0xFFBBCBB2)
)

val PinkAccent = AccentSpec(
    primaryLight = Color(0xFF9C27B0),
    onPrimaryLight = Color(0xFFFFFFFF),
    primaryContainerLight = Color(0xFFFFD7F5),
    onPrimaryContainerLight = Color(0xFF380044),
    secondaryLight = Color(0xFF6B586B),
    primaryDark = Color(0xFFF5BDE6),
    onPrimaryDark = Color(0xFF510064),
    primaryContainerDark = Color(0xFF73008D),
    onPrimaryContainerDark = Color(0xFFFFD7F5),
    secondaryDark = Color(0xFFD6C0D5)
)

val OrangeAccent = AccentSpec(
    primaryLight = Color(0xFF8C5000),
    onPrimaryLight = Color(0xFFFFFFFF),
    primaryContainerLight = Color(0xFFFFDCBE),
    onPrimaryContainerLight = Color(0xFF2C1600),
    secondaryLight = Color(0xFF715A42),
    primaryDark = Color(0xFFFFB870),
    onPrimaryDark = Color(0xFF4A2800),
    primaryContainerDark = Color(0xFF6A3B00),
    onPrimaryContainerDark = Color(0xFFFFDCBE),
    secondaryDark = Color(0xFFDFC2A3)
)
