package com.sr.music.feature.player

import com.sr.music.domain.model.Song

data class PlayerUiState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val isMiniPlayerDismissed: Boolean = false,
    val currentPositionMs: Long = 84000, // 1:24 default for rich preview
    val durationMs: Long = 280000,
    val isShuffleEnabled: Boolean = false,
    val isRepeatEnabled: Boolean = false,
    val isFavorite: Boolean = false,
    val queue: List<Song> = emptyList(),
    val playbackSpeed: Float = 1.0f
) {
    val progress: Float
        get() = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
}
