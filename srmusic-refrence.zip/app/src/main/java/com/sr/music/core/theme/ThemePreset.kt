package com.sr.music.core.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

data class ThemeVariant(
    val id: String,
    val name: String,
    val isDark: Boolean = true,
    val previewPrimary: Color,
    val previewBackground: Color,
    val previewSurface: Color,
    val previewSecondary: Color,
    val palette: ColorScheme
)

data class ThemePreset(
    val id: String,
    val name: String,
    val category: String = "Community",
    val popularity: Int,
    val variants: List<ThemeVariant>
) {
    val defaultVariant: ThemeVariant get() = variants.first()
}

enum class ThemeSortOption(val displayName: String) {
    POPULAR("Popular"),
    NAME("Name")
}

object ThemePresetCatalog {

    // 1. Catppuccin
    val catppuccin = ThemePreset(
        id = "catppuccin",
        name = "Catppuccin",
        popularity = 1,
        variants = listOf(
            ThemeVariant(
                id = "mocha",
                name = "Mocha",
                isDark = true,
                previewPrimary = CatppuccinMocha.Mauve,
                previewBackground = CatppuccinMocha.Base,
                previewSurface = CatppuccinMocha.Mantle,
                previewSecondary = CatppuccinMocha.Lavender,
                palette = ThemePalette.buildCatppuccin(CatppuccinVariant.MOCHA)
            ),
            ThemeVariant(
                id = "macchiato",
                name = "Macchiato",
                isDark = true,
                previewPrimary = CatppuccinMacchiato.Mauve,
                previewBackground = CatppuccinMacchiato.Base,
                previewSurface = CatppuccinMacchiato.Mantle,
                previewSecondary = CatppuccinMacchiato.Lavender,
                palette = ThemePalette.buildCatppuccin(CatppuccinVariant.MACCHIATO)
            ),
            ThemeVariant(
                id = "frappe",
                name = "Frappé",
                isDark = true,
                previewPrimary = CatppuccinFrappe.Mauve,
                previewBackground = CatppuccinFrappe.Base,
                previewSurface = CatppuccinFrappe.Mantle,
                previewSecondary = CatppuccinFrappe.Lavender,
                palette = ThemePalette.buildCatppuccin(CatppuccinVariant.FRAPPE)
            ),
            ThemeVariant(
                id = "latte",
                name = "Latte",
                isDark = false,
                previewPrimary = CatppuccinLatte.Mauve,
                previewBackground = CatppuccinLatte.Base,
                previewSurface = CatppuccinLatte.Mantle,
                previewSecondary = CatppuccinLatte.Lavender,
                palette = ThemePalette.buildCatppuccin(CatppuccinVariant.LATTE)
            )
        )
    )

    // 2. Tokyo Night
    val tokyoNight = ThemePreset(
        id = "tokyo_night",
        name = "Tokyo Night",
        popularity = 2,
        variants = listOf(
            ThemeVariant(
                id = "night",
                name = "Night",
                isDark = true,
                previewPrimary = Color(0xFF7AA2F7),
                previewBackground = Color(0xFF1A1B26),
                previewSurface = Color(0xFF24283B),
                previewSecondary = Color(0xFFBB9AF7),
                palette = darkColorScheme(
                    primary = Color(0xFF7AA2F7),
                    onPrimary = Color(0xFF15161E),
                    primaryContainer = Color(0xFF2F3549),
                    onPrimaryContainer = Color(0xFFC0CAF5),
                    secondary = Color(0xFFBB9AF7),
                    onSecondary = Color(0xFF15161E),
                    secondaryContainer = Color(0xFF3B4261),
                    onSecondaryContainer = Color(0xFFC0CAF5),
                    tertiary = Color(0xFF7DCFFF),
                    onTertiary = Color(0xFF15161E),
                    background = Color(0xFF1A1B26),
                    onBackground = Color(0xFFC0CAF5),
                    surface = Color(0xFF24283B),
                    onSurface = Color(0xFFC0CAF5),
                    surfaceVariant = Color(0xFF2F3549),
                    onSurfaceVariant = Color(0xFFA9B1D6),
                    outline = Color(0xFF565F89),
                    outlineVariant = Color(0xFF414868)
                )
            ),
            ThemeVariant(
                id = "storm",
                name = "Storm",
                isDark = true,
                previewPrimary = Color(0xFF7AA2F7),
                previewBackground = Color(0xFF24283B),
                previewSurface = Color(0xFF1F2335),
                previewSecondary = Color(0xFFBB9AF7),
                palette = darkColorScheme(
                    primary = Color(0xFF7AA2F7),
                    onPrimary = Color(0xFF1F2335),
                    primaryContainer = Color(0xFF292E42),
                    onPrimaryContainer = Color(0xFFC0CAF5),
                    secondary = Color(0xFFBB9AF7),
                    onSecondary = Color(0xFF1F2335),
                    secondaryContainer = Color(0xFF3B4261),
                    onSecondaryContainer = Color(0xFFC0CAF5),
                    tertiary = Color(0xFF7DCFFF),
                    onTertiary = Color(0xFF1F2335),
                    background = Color(0xFF24283B),
                    onBackground = Color(0xFFC0CAF5),
                    surface = Color(0xFF1F2335),
                    onSurface = Color(0xFFC0CAF5),
                    surfaceVariant = Color(0xFF292E42),
                    onSurfaceVariant = Color(0xFFA9B1D6),
                    outline = Color(0xFF565F89),
                    outlineVariant = Color(0xFF414868)
                )
            ),
            ThemeVariant(
                id = "moon",
                name = "Moon",
                isDark = true,
                previewPrimary = Color(0xFF82AAFF),
                previewBackground = Color(0xFF222436),
                previewSurface = Color(0xFF1E2030),
                previewSecondary = Color(0xFFC099FF),
                palette = darkColorScheme(
                    primary = Color(0xFF82AAFF),
                    onPrimary = Color(0xFF1E2030),
                    primaryContainer = Color(0xFF2D3149),
                    onPrimaryContainer = Color(0xFFC8D3F5),
                    secondary = Color(0xFFC099FF),
                    onSecondary = Color(0xFF1E2030),
                    secondaryContainer = Color(0xFF3B4261),
                    onSecondaryContainer = Color(0xFFC8D3F5),
                    tertiary = Color(0xFF86E1FC),
                    onTertiary = Color(0xFF1E2030),
                    background = Color(0xFF222436),
                    onBackground = Color(0xFFC8D3F5),
                    surface = Color(0xFF1E2030),
                    onSurface = Color(0xFFC8D3F5),
                    surfaceVariant = Color(0xFF2D3149),
                    onSurfaceVariant = Color(0xFFA9B1D6),
                    outline = Color(0xFF565F89),
                    outlineVariant = Color(0xFF414868)
                )
            )
        )
    )

    // 3. Dracula
    val dracula = ThemePreset(
        id = "dracula",
        name = "Dracula",
        popularity = 3,
        variants = listOf(
            ThemeVariant(
                id = "dracula",
                name = "Dracula",
                isDark = true,
                previewPrimary = Color(0xFFBD93F9),
                previewBackground = Color(0xFF282A36),
                previewSurface = Color(0xFF21222C),
                previewSecondary = Color(0xFFFF79C6),
                palette = darkColorScheme(
                    primary = Color(0xFFBD93F9),
                    onPrimary = Color(0xFF282A36),
                    primaryContainer = Color(0xFF44475A),
                    onPrimaryContainer = Color(0xFFF8F8F2),
                    secondary = Color(0xFFFF79C6),
                    onSecondary = Color(0xFF282A36),
                    secondaryContainer = Color(0xFF44475A),
                    onSecondaryContainer = Color(0xFFF8F8F2),
                    tertiary = Color(0xFF8BE9FD),
                    onTertiary = Color(0xFF282A36),
                    background = Color(0xFF282A36),
                    onBackground = Color(0xFFF8F8F2),
                    surface = Color(0xFF21222C),
                    onSurface = Color(0xFFF8F8F2),
                    surfaceVariant = Color(0xFF44475A),
                    onSurfaceVariant = Color(0xFF6272A4),
                    outline = Color(0xFF6272A4),
                    outlineVariant = Color(0xFF44475A)
                )
            ),
            ThemeVariant(
                id = "dracula_soft",
                name = "Dracula Soft",
                isDark = true,
                previewPrimary = Color(0xFFD1B3FF),
                previewBackground = Color(0xFF343746),
                previewSurface = Color(0xFF282A36),
                previewSecondary = Color(0xFFFF92D0),
                palette = darkColorScheme(
                    primary = Color(0xFFD1B3FF),
                    onPrimary = Color(0xFF282A36),
                    primaryContainer = Color(0xFF4D5166),
                    onPrimaryContainer = Color(0xFFF8F8F2),
                    secondary = Color(0xFFFF92D0),
                    onSecondary = Color(0xFF282A36),
                    secondaryContainer = Color(0xFF4D5166),
                    onSecondaryContainer = Color(0xFFF8F8F2),
                    tertiary = Color(0xFFA4FFFF),
                    onTertiary = Color(0xFF282A36),
                    background = Color(0xFF343746),
                    onBackground = Color(0xFFF8F8F2),
                    surface = Color(0xFF282A36),
                    onSurface = Color(0xFFF8F8F2),
                    surfaceVariant = Color(0xFF4D5166),
                    onSurfaceVariant = Color(0xFF798BB4),
                    outline = Color(0xFF798BB4),
                    outlineVariant = Color(0xFF4D5166)
                )
            )
        )
    )

    // 6. One Dark Pro
    val oneDarkPro = ThemePreset(
        id = "one_dark_pro",
        name = "One Dark Pro",
        popularity = 6,
        variants = listOf(
            ThemeVariant(
                id = "dark",
                name = "Dark",
                isDark = true,
                previewPrimary = Color(0xFF61AFEF),
                previewBackground = Color(0xFF282C34),
                previewSurface = Color(0xFF21252B),
                previewSecondary = Color(0xFFC678DD),
                palette = darkColorScheme(
                    primary = Color(0xFF61AFEF),
                    onPrimary = Color(0xFF21252B),
                    primaryContainer = Color(0xFF353B45),
                    onPrimaryContainer = Color(0xFFABB2BF),
                    secondary = Color(0xFFC678DD),
                    onSecondary = Color(0xFF21252B),
                    secondaryContainer = Color(0xFF353B45),
                    onSecondaryContainer = Color(0xFFABB2BF),
                    tertiary = Color(0xFF98C379),
                    onTertiary = Color(0xFF21252B),
                    background = Color(0xFF282C34),
                    onBackground = Color(0xFFABB2BF),
                    surface = Color(0xFF21252B),
                    onSurface = Color(0xFFABB2BF),
                    surfaceVariant = Color(0xFF353B45),
                    onSurfaceVariant = Color(0xFF5C6370),
                    outline = Color(0xFF5C6370),
                    outlineVariant = Color(0xFF3E4451)
                )
            ),
            ThemeVariant(
                id = "black",
                name = "Black",
                isDark = true,
                previewPrimary = Color(0xFF61AFEF),
                previewBackground = Color(0xFF181A1F),
                previewSurface = Color(0xFF121417),
                previewSecondary = Color(0xFFC678DD),
                palette = darkColorScheme(
                    primary = Color(0xFF61AFEF),
                    onPrimary = Color(0xFF121417),
                    primaryContainer = Color(0xFF282C34),
                    onPrimaryContainer = Color(0xFFABB2BF),
                    secondary = Color(0xFFC678DD),
                    onSecondary = Color(0xFF121417),
                    secondaryContainer = Color(0xFF282C34),
                    onSecondaryContainer = Color(0xFFABB2BF),
                    tertiary = Color(0xFF98C379),
                    onTertiary = Color(0xFF121417),
                    background = Color(0xFF181A1F),
                    onBackground = Color(0xFFABB2BF),
                    surface = Color(0xFF121417),
                    onSurface = Color(0xFFABB2BF),
                    surfaceVariant = Color(0xFF282C34),
                    onSurfaceVariant = Color(0xFF5C6370),
                    outline = Color(0xFF5C6370),
                    outlineVariant = Color(0xFF21252B)
                )
            )
        )
    )

    // 7. Nord
    val nord = ThemePreset(
        id = "nord",
        name = "Nord",
        popularity = 7,
        variants = listOf(
            ThemeVariant(
                id = "nord",
                name = "Nord",
                isDark = true,
                previewPrimary = Color(0xFF88C0D0),
                previewBackground = Color(0xFF2E3440),
                previewSurface = Color(0xFF3B4252),
                previewSecondary = Color(0xFF81A1C1),
                palette = darkColorScheme(
                    primary = Color(0xFF88C0D0),
                    onPrimary = Color(0xFF2E3440),
                    primaryContainer = Color(0xFF434C5E),
                    onPrimaryContainer = Color(0xFFECEFF4),
                    secondary = Color(0xFF81A1C1),
                    onSecondary = Color(0xFF2E3440),
                    secondaryContainer = Color(0xFF4C566A),
                    onSecondaryContainer = Color(0xFFECEFF4),
                    tertiary = Color(0xFFB48EAD),
                    onTertiary = Color(0xFF2E3440),
                    background = Color(0xFF2E3440),
                    onBackground = Color(0xFFECEFF4),
                    surface = Color(0xFF3B4252),
                    onSurface = Color(0xFFECEFF4),
                    surfaceVariant = Color(0xFF434C5E),
                    onSurfaceVariant = Color(0xFFD8DEE9),
                    outline = Color(0xFF4C566A),
                    outlineVariant = Color(0xFF434C5E)
                )
            ),
            ThemeVariant(
                id = "polar_night",
                name = "Polar Night",
                isDark = true,
                previewPrimary = Color(0xFF8FBCBB),
                previewBackground = Color(0xFF242933),
                previewSurface = Color(0xFF2E3440),
                previewSecondary = Color(0xFF88C0D0),
                palette = darkColorScheme(
                    primary = Color(0xFF8FBCBB),
                    onPrimary = Color(0xFF242933),
                    primaryContainer = Color(0xFF3B4252),
                    onPrimaryContainer = Color(0xFFE5E9F0),
                    secondary = Color(0xFF88C0D0),
                    onSecondary = Color(0xFF242933),
                    secondaryContainer = Color(0xFF434C5E),
                    onSecondaryContainer = Color(0xFFE5E9F0),
                    tertiary = Color(0xFF5E81AC),
                    onTertiary = Color(0xFF242933),
                    background = Color(0xFF242933),
                    onBackground = Color(0xFFE5E9F0),
                    surface = Color(0xFF2E3440),
                    onSurface = Color(0xFFE5E9F0),
                    surfaceVariant = Color(0xFF3B4252),
                    onSurfaceVariant = Color(0xFFD8DEE9),
                    outline = Color(0xFF4C566A),
                    outlineVariant = Color(0xFF3B4252)
                )
            )
        )
    )

    // 8. Spotify
    val spotify = ThemePreset(
        id = "spotify",
        name = "Spotify",
        popularity = 8,
        variants = listOf(
            ThemeVariant(
                id = "dark",
                name = "Dark",
                isDark = true,
                previewPrimary = Color(0xFF1DB954),
                previewBackground = Color(0xFF121212),
                previewSurface = Color(0xFF181818),
                previewSecondary = Color(0xFF1ED760),
                palette = darkColorScheme(
                    primary = Color(0xFF1DB954),
                    onPrimary = Color(0xFF000000),
                    primaryContainer = Color(0xFF282828),
                    onPrimaryContainer = Color(0xFFFFFFFF),
                    secondary = Color(0xFF1ED760),
                    onSecondary = Color(0xFF000000),
                    secondaryContainer = Color(0xFF282828),
                    onSecondaryContainer = Color(0xFFFFFFFF),
                    tertiary = Color(0xFFB3B3B3),
                    onTertiary = Color(0xFF000000),
                    background = Color(0xFF121212),
                    onBackground = Color(0xFFFFFFFF),
                    surface = Color(0xFF181818),
                    onSurface = Color(0xFFFFFFFF),
                    surfaceVariant = Color(0xFF282828),
                    onSurfaceVariant = Color(0xFFB3B3B3),
                    outline = Color(0xFF535353),
                    outlineVariant = Color(0xFF3E3E3E)
                )
            ),
            ThemeVariant(
                id = "amoled",
                name = "AMOLED",
                isDark = true,
                previewPrimary = Color(0xFF1DB954),
                previewBackground = Color(0xFF000000),
                previewSurface = Color(0xFF0A0A0A),
                previewSecondary = Color(0xFF1ED760),
                palette = darkColorScheme(
                    primary = Color(0xFF1DB954),
                    onPrimary = Color(0xFF000000),
                    primaryContainer = Color(0xFF181818),
                    onPrimaryContainer = Color(0xFFFFFFFF),
                    secondary = Color(0xFF1ED760),
                    onSecondary = Color(0xFF000000),
                    secondaryContainer = Color(0xFF181818),
                    onSecondaryContainer = Color(0xFFFFFFFF),
                    tertiary = Color(0xFFB3B3B3),
                    onTertiary = Color(0xFF000000),
                    background = Color(0xFF000000),
                    onBackground = Color(0xFFFFFFFF),
                    surface = Color(0xFF0A0A0A),
                    onSurface = Color(0xFFFFFFFF),
                    surfaceVariant = Color(0xFF181818),
                    onSurfaceVariant = Color(0xFFB3B3B3),
                    outline = Color(0xFF333333),
                    outlineVariant = Color(0xFF222222)
                )
            )
        )
    )

    // 13. Gruvbox
    val gruvbox = ThemePreset(
        id = "gruvbox",
        name = "Gruvbox",
        popularity = 13,
        variants = listOf(
            ThemeVariant(
                id = "dark",
                name = "Dark",
                isDark = true,
                previewPrimary = Color(0xFFFE8019),
                previewBackground = Color(0xFF282828),
                previewSurface = Color(0xFF1D2021),
                previewSecondary = Color(0xFFFABD2F),
                palette = darkColorScheme(
                    primary = Color(0xFFFE8019),
                    onPrimary = Color(0xFF282828),
                    primaryContainer = Color(0xFF3C3836),
                    onPrimaryContainer = Color(0xFFEBDBB2),
                    secondary = Color(0xFFFABD2F),
                    onSecondary = Color(0xFF282828),
                    secondaryContainer = Color(0xFF504945),
                    onSecondaryContainer = Color(0xFFEBDBB2),
                    tertiary = Color(0xFFB8BB26),
                    onTertiary = Color(0xFF282828),
                    background = Color(0xFF282828),
                    onBackground = Color(0xFFEBDBB2),
                    surface = Color(0xFF1D2021),
                    onSurface = Color(0xFFEBDBB2),
                    surfaceVariant = Color(0xFF3C3836),
                    onSurfaceVariant = Color(0xFFA89984),
                    outline = Color(0xFF665C54),
                    outlineVariant = Color(0xFF504945)
                )
            ),
            ThemeVariant(
                id = "soft",
                name = "Soft",
                isDark = true,
                previewPrimary = Color(0xFFE78A4E),
                previewBackground = Color(0xFF32302F),
                previewSurface = Color(0xFF282828),
                previewSecondary = Color(0xFFD8A657),
                palette = darkColorScheme(
                    primary = Color(0xFFE78A4E),
                    onPrimary = Color(0xFF32302F),
                    primaryContainer = Color(0xFF3C3836),
                    onPrimaryContainer = Color(0xFFD5C4A1),
                    secondary = Color(0xFFD8A657),
                    onSecondary = Color(0xFF32302F),
                    secondaryContainer = Color(0xFF504945),
                    onSecondaryContainer = Color(0xFFD5C4A1),
                    tertiary = Color(0xFFA9B665),
                    onTertiary = Color(0xFF32302F),
                    background = Color(0xFF32302F),
                    onBackground = Color(0xFFD5C4A1),
                    surface = Color(0xFF282828),
                    onSurface = Color(0xFFD5C4A1),
                    surfaceVariant = Color(0xFF3C3836),
                    onSurfaceVariant = Color(0xFFA89984),
                    outline = Color(0xFF665C54),
                    outlineVariant = Color(0xFF504945)
                )
            )
        )
    )

    // 12. Monokai Pro
    val monokaiPro = ThemePreset(
        id = "monokai_pro",
        name = "Monokai Pro",
        popularity = 12,
        variants = listOf(
            ThemeVariant(
                id = "default",
                name = "Default",
                isDark = true,
                previewPrimary = Color(0xFFFFD866),
                previewBackground = Color(0xFF2D2A2E),
                previewSurface = Color(0xFF221F22),
                previewSecondary = Color(0xFFFF6188),
                palette = darkColorScheme(
                    primary = Color(0xFFFFD866),
                    onPrimary = Color(0xFF221F22),
                    primaryContainer = Color(0xFF403E41),
                    onPrimaryContainer = Color(0xFFFCFCFA),
                    secondary = Color(0xFFFF6188),
                    onSecondary = Color(0xFF221F22),
                    secondaryContainer = Color(0xFF403E41),
                    onSecondaryContainer = Color(0xFFFCFCFA),
                    tertiary = Color(0xFF78DCE8),
                    onTertiary = Color(0xFF221F22),
                    background = Color(0xFF2D2A2E),
                    onBackground = Color(0xFFFCFCFA),
                    surface = Color(0xFF221F22),
                    onSurface = Color(0xFFFCFCFA),
                    surfaceVariant = Color(0xFF403E41),
                    onSurfaceVariant = Color(0xFF939293),
                    outline = Color(0xFF727072),
                    outlineVariant = Color(0xFF5B595C)
                )
            )
        )
    )

    // 4. SynthWave '84
    val synthWave84 = ThemePreset(
        id = "synthwave_84",
        name = "SynthWave '84",
        popularity = 4,
        variants = listOf(
            ThemeVariant(
                id = "default",
                name = "Default",
                isDark = true,
                previewPrimary = Color(0xFFFF7EDB),
                previewBackground = Color(0xFF262335),
                previewSurface = Color(0xFF241B2F),
                previewSecondary = Color(0xFF36F9F6),
                palette = darkColorScheme(
                    primary = Color(0xFFFF7EDB),
                    onPrimary = Color(0xFF241B2F),
                    primaryContainer = Color(0xFF34294F),
                    onPrimaryContainer = Color(0xFFF92AAD),
                    secondary = Color(0xFF36F9F6),
                    onSecondary = Color(0xFF241B2F),
                    secondaryContainer = Color(0xFF34294F),
                    onSecondaryContainer = Color(0xFFF92AAD),
                    tertiary = Color(0xFFFE4450),
                    onTertiary = Color(0xFF241B2F),
                    background = Color(0xFF262335),
                    onBackground = Color(0xFFF92AAD),
                    surface = Color(0xFF241B2F),
                    onSurface = Color(0xFFFFFFFF),
                    surfaceVariant = Color(0xFF34294F),
                    onSurfaceVariant = Color(0xFF848BBD),
                    outline = Color(0xFF614D85),
                    outlineVariant = Color(0xFF493B66)
                )
            )
        )
    )

    // 5. Night Owl
    val nightOwl = ThemePreset(
        id = "night_owl",
        name = "Night Owl",
        popularity = 5,
        variants = listOf(
            ThemeVariant(
                id = "default",
                name = "Default",
                isDark = true,
                previewPrimary = Color(0xFF82AAFF),
                previewBackground = Color(0xFF011627),
                previewSurface = Color(0xFF0B2942),
                previewSecondary = Color(0xFF7FDBCA),
                palette = darkColorScheme(
                    primary = Color(0xFF82AAFF),
                    onPrimary = Color(0xFF011627),
                    primaryContainer = Color(0xFF113456),
                    onPrimaryContainer = Color(0xFFD6DEEB),
                    secondary = Color(0xFF7FDBCA),
                    onSecondary = Color(0xFF011627),
                    secondaryContainer = Color(0xFF113456),
                    onSecondaryContainer = Color(0xFFD6DEEB),
                    tertiary = Color(0xFFC792EA),
                    onTertiary = Color(0xFF011627),
                    background = Color(0xFF011627),
                    onBackground = Color(0xFFD6DEEB),
                    surface = Color(0xFF0B2942),
                    onSurface = Color(0xFFD6DEEB),
                    surfaceVariant = Color(0xFF113456),
                    onSurfaceVariant = Color(0xFF5F7E97),
                    outline = Color(0xFF5F7E97),
                    outlineVariant = Color(0xFF1D3B5A)
                )
            )
        )
    )

    // 10. Cyberpunk
    val cyberpunk = ThemePreset(
        id = "cyberpunk",
        name = "Cyberpunk",
        popularity = 10,
        variants = listOf(
            ThemeVariant(
                id = "neon",
                name = "Neon",
                isDark = true,
                previewPrimary = Color(0xFF00F0FF),
                previewBackground = Color(0xFF120E24),
                previewSurface = Color(0xFF1D153A),
                previewSecondary = Color(0xFFFFE600),
                palette = darkColorScheme(
                    primary = Color(0xFF00F0FF),
                    onPrimary = Color(0xFF120E24),
                    primaryContainer = Color(0xFF281D4C),
                    onPrimaryContainer = Color(0xFF00FF9F),
                    secondary = Color(0xFFFFE600),
                    onSecondary = Color(0xFF120E24),
                    secondaryContainer = Color(0xFF281D4C),
                    onSecondaryContainer = Color(0xFF00FF9F),
                    tertiary = Color(0xFFFF0055),
                    onTertiary = Color(0xFF120E24),
                    background = Color(0xFF120E24),
                    onBackground = Color(0xFF00FF9F),
                    surface = Color(0xFF1D153A),
                    onSurface = Color(0xFF00FF9F),
                    surfaceVariant = Color(0xFF281D4C),
                    onSurfaceVariant = Color(0xFF715B9B),
                    outline = Color(0xFF00F0FF),
                    outlineVariant = Color(0xFF493673)
                )
            )
        )
    )

    // 11. Moonlight
    val moonlight = ThemePreset(
        id = "moonlight",
        name = "Moonlight",
        popularity = 11,
        variants = listOf(
            ThemeVariant(
                id = "default",
                name = "Default",
                isDark = true,
                previewPrimary = Color(0xFF82AAFF),
                previewBackground = Color(0xFF212337),
                previewSurface = Color(0xFF191A2A),
                previewSecondary = Color(0xFFC099FF),
                palette = darkColorScheme(
                    primary = Color(0xFF82AAFF),
                    onPrimary = Color(0xFF191A2A),
                    primaryContainer = Color(0xFF2F334D),
                    onPrimaryContainer = Color(0xFFC8D3F5),
                    secondary = Color(0xFFC099FF),
                    onSecondary = Color(0xFF191A2A),
                    secondaryContainer = Color(0xFF3B4068),
                    onSecondaryContainer = Color(0xFFC8D3F5),
                    tertiary = Color(0xFF4FD6BE),
                    onTertiary = Color(0xFF191A2A),
                    background = Color(0xFF212337),
                    onBackground = Color(0xFFC8D3F5),
                    surface = Color(0xFF191A2A),
                    onSurface = Color(0xFFC8D3F5),
                    surfaceVariant = Color(0xFF2F334D),
                    onSurfaceVariant = Color(0xFF828BB8),
                    outline = Color(0xFF596399),
                    outlineVariant = Color(0xFF3B4068)
                )
            )
        )
    )

    // 9. Shade Of Purple
    val shadeOfPurple = ThemePreset(
        id = "shade_of_purple",
        name = "Shade Of Purple",
        popularity = 9,
        variants = listOf(
            ThemeVariant(
                id = "default",
                name = "Default",
                isDark = true,
                previewPrimary = Color(0xFFFAD000),
                previewBackground = Color(0xFF222244),
                previewSurface = Color(0xFF1E1E3F),
                previewSecondary = Color(0xFFA599E9),
                palette = darkColorScheme(
                    primary = Color(0xFFFAD000),
                    onPrimary = Color(0xFF1E1E3F),
                    primaryContainer = Color(0xFF2D2B55),
                    onPrimaryContainer = Color(0xFFF1F1F1),
                    secondary = Color(0xFFA599E9),
                    onSecondary = Color(0xFF1E1E3F),
                    secondaryContainer = Color(0xFF3D3768),
                    onSecondaryContainer = Color(0xFFF1F1F1),
                    tertiary = Color(0xFFB362FF),
                    onTertiary = Color(0xFF1E1E3F),
                    background = Color(0xFF222244),
                    onBackground = Color(0xFFF1F1F1),
                    surface = Color(0xFF1E1E3F),
                    onSurface = Color(0xFFF1F1F1),
                    surfaceVariant = Color(0xFF2D2B55),
                    onSurfaceVariant = Color(0xFFA599E9),
                    outline = Color(0xFF695CA8),
                    outlineVariant = Color(0xFF3D3768)
                )
            )
        )
    )

    // 14. JellyFish
    val jellyFish = ThemePreset(
        id = "jellyfish",
        name = "JellyFish",
        popularity = 14,
        variants = listOf(
            ThemeVariant(
                id = "default",
                name = "Default",
                isDark = true,
                previewPrimary = Color(0xFF9370DB),
                previewBackground = Color(0xFF191B28),
                previewSurface = Color(0xFF12141F),
                previewSecondary = Color(0xFF00CED1),
                palette = darkColorScheme(
                    primary = Color(0xFF9370DB),
                    onPrimary = Color(0xFF12141F),
                    primaryContainer = Color(0xFF272A3C),
                    onPrimaryContainer = Color(0xFFE8EDF1),
                    secondary = Color(0xFF00CED1),
                    onSecondary = Color(0xFF12141F),
                    secondaryContainer = Color(0xFF272A3C),
                    onSecondaryContainer = Color(0xFFE8EDF1),
                    tertiary = Color(0xFFFF69B4),
                    onTertiary = Color(0xFF12141F),
                    background = Color(0xFF191B28),
                    onBackground = Color(0xFFE8EDF1),
                    surface = Color(0xFF12141F),
                    onSurface = Color(0xFFE8EDF1),
                    surfaceVariant = Color(0xFF272A3C),
                    onSurfaceVariant = Color(0xFF8F9BA8),
                    outline = Color(0xFF5E6B7A),
                    outlineVariant = Color(0xFF373B52)
                )
            )
        )
    )

    val allPresets: List<ThemePreset> = listOf(
        catppuccin,
        tokyoNight,
        dracula,
        synthWave84,
        nightOwl,
        oneDarkPro,
        nord,
        spotify,
        shadeOfPurple,
        cyberpunk,
        moonlight,
        monokaiPro,
        gruvbox,
        jellyFish
    )

    fun getPresets(sortBy: ThemeSortOption): List<ThemePreset> {
        return when (sortBy) {
            ThemeSortOption.POPULAR -> allPresets.sortedBy { it.popularity }
            ThemeSortOption.NAME -> allPresets.sortedBy { it.name }
        }
    }

    fun getPreset(id: String): ThemePreset? {
        return allPresets.find { it.id == id }
    }

    fun getVariant(presetId: String, variantId: String): ThemeVariant? {
        val preset = getPreset(presetId) ?: return null
        return preset.variants.find { it.id == variantId } ?: preset.defaultVariant
    }
}
