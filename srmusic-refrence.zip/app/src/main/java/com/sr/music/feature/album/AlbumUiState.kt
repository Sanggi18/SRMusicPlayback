package com.sr.music.feature.album

import com.sr.music.core.components.SortOption
import com.sr.music.domain.model.Album

data class AlbumUiState(
    val albums: List<Album> = emptyList(),
    val searchQuery: String = "",
    val sortOption: SortOption = SortOption.TITLE,
    val selectedIndex: String? = null,
    val isAscending: Boolean = true,
    val gridColumns: Int = 2, // 2-column grid matching Albums.png screenshot
    val isLoading: Boolean = false
)
