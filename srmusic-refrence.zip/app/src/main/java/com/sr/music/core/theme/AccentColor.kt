package com.sr.music.core.theme

import androidx.compose.ui.graphics.Color

enum class AccentColor(
    val displayName: String,
    val hexPreview: Long,
    val hexString: String,
    val r: Int,
    val g: Int,
    val b: Int
) {
    RED("Red", 0xFFB3261E, "#B3261E", 179, 38, 30),
    ORANGE("Orange", 0xFFE65100, "#E65100", 230, 81, 0),
    AMBER("Amber", 0xFFFF8F00, "#FF8F00", 255, 143, 0),
    YELLOW("Yellow", 0xFFFBC02D, "#FBC02D", 251, 192, 45),
    LIME("Lime", 0xFF689F38, "#689F38", 104, 159, 56),
    GREEN("Green", 0xFF2E7D32, "#2E7D32", 46, 125, 50),
    TEAL("Teal", 0xFF00695C, "#00695C", 0, 105, 92),
    CYAN("Cyan", 0xFF00838F, "#00838F", 0, 131, 143),
    BLUE("Blue", 0xFF1565C0, "#1565C0", 21, 101, 192),
    INDIGO("Indigo", 0xFF3F51B5, "#3F51B5", 63, 81, 181),
    PURPLE("Purple", 0xFF6750A4, "#6750A4", 103, 80, 164),
    PINK("Pink", 0xFFC2185B, "#C2185B", 194, 24, 91);

    val color: Color
        get() = Color(hexPreview)

    val rgbText: String
        get() = "$r, $g, $b"

    companion object {
        fun fromHex(hex: String): AccentColor? {
            val normalized = hex.trim().removePrefix("#").uppercase()
            return entries.firstOrNull { it.hexString.removePrefix("#").uppercase() == normalized }
        }

        fun parseHexToRgb(hex: String): Triple<Int, Int, Int>? {
            val clean = hex.trim().removePrefix("#")
            if (clean.length != 6) return null
            return try {
                val colorInt = clean.toLong(16)
                val r = ((colorInt shr 16) and 0xFF).toInt()
                val g = ((colorInt shr 8) and 0xFF).toInt()
                val b = (colorInt and 0xFF).toInt()
                Triple(r, g, b)
            } catch (_: Exception) {
                null
            }
        }
    }
}
