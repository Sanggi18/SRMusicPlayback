package com.sr.music.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.sr.music.data.local.SRMusicDatabase
import com.sr.music.data.local.entity.AlbumEntity
import com.sr.music.data.local.entity.ArtistEntity
import com.sr.music.data.local.entity.FolderEntity
import com.sr.music.data.local.entity.SongEntity
import com.sr.music.data.mapper.toDomainModel
import com.sr.music.data.mapper.toEntity
import com.sr.music.data.mediastore.MediaStoreScanResult
import com.sr.music.data.mediastore.MediaStoreScanner
import com.sr.music.domain.model.Album
import com.sr.music.domain.model.Artist
import com.sr.music.domain.model.Folder
import com.sr.music.domain.model.Song
import com.sr.music.domain.repository.MusicRepository
import com.sr.music.domain.repository.SyncResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

class MusicRepositoryImpl(
    private val context: Context,
    private val database: SRMusicDatabase = SRMusicDatabase.getInstance(context),
    private val scanner: MediaStoreScanner = MediaStoreScanner(context)
) : MusicRepository {

    private val songDao = database.songDao()
    private val albumDao = database.albumDao()
    private val artistDao = database.artistDao()
    private val folderDao = database.folderDao()
    private val playlistDao = database.playlistDao()

    override val songs: Flow<List<Song>> = songDao.getAllSongs()
        .map { entities -> entities.map { it.toDomainModel() } }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)

    override val recentlyAddedSongs: Flow<List<Song>> = songDao.getRecentlyAddedSongs()
        .map { entities -> entities.map { it.toDomainModel() } }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)

    override val albums: Flow<List<Album>> = albumDao.getAllAlbums()
        .map { entities -> entities.map { it.toDomainModel() } }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)

    override val artists: Flow<List<Artist>> = artistDao.getAllArtists()
        .map { entities -> entities.map { it.toDomainModel() } }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)

    override val folders: Flow<List<Folder>> = folderDao.getAllFolders()
        .map { entities -> entities.map { it.toDomainModel() } }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)

    override val favoriteSongs: Flow<List<Song>> = songDao.getFavoriteSongs()
        .map { entities -> entities.map { it.toDomainModel() } }
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)

    override val songCount: Flow<Int> = songDao.getSongCount()
        .distinctUntilChanged()
        .flowOn(Dispatchers.IO)

    override suspend fun syncLibrary(forceFullScan: Boolean): SyncResult = withContext(Dispatchers.IO) {
        val scanResult = scanner.scanAudioFiles(filterShortAudio = true)

        // CORRECTION 1 & 2: Explicitly guard against scan failure.
        // Never proceed or delete anything if the scan failed!
        val scannedAudioList = when (scanResult) {
            is MediaStoreScanResult.Failure -> {
                val dbCount = songDao.getSongCountDirect()
                return@withContext SyncResult(
                    totalCount = dbCount,
                    isSuccess = false,
                    errorMessage = scanResult.exception.localizedMessage ?: "MediaStore query failed"
                )
            }
            is MediaStoreScanResult.Success -> scanResult.audioFiles
        }

        if (scannedAudioList.isEmpty() && !forceFullScan) {
            val dbCount = songDao.getSongCountDirect()
            return@withContext SyncResult(totalCount = dbCount, isSuccess = true)
        }

        try {
            // CORRECTION 3: Wrap the entire sync and derived update in an atomic database transaction
            database.withTransaction {
                val currentMetaList = songDao.getAllSongSyncMeta()
                val currentMetaMap = currentMetaList.associateBy { it.mediaStoreId }
                val scannedMap = scannedAudioList.associateBy { it.mediaStoreId }

                var addedCount = 0
                var updatedCount = 0
                var removedCount = 0

                val songsToInsert = mutableListOf<SongEntity>()

                // 1. Detect new and modified tracks
                for (scanned in scannedAudioList) {
                    val existingMeta = currentMetaMap[scanned.mediaStoreId]
                    if (existingMeta == null) {
                        // Brand new track
                        songsToInsert.add(scanned.toEntity())
                        addedCount++
                    } else if (existingMeta.dateModified != scanned.dateModified || existingMeta.size != scanned.size) {
                        // Existing track modified: preserve user state
                        val existingSong = songDao.getSongById(existingMeta.id)
                        songsToInsert.add(
                            scanned.toEntity(
                                existingFavorite = existingSong?.isFavorite ?: false,
                                existingPlayCount = existingSong?.playCount ?: 0,
                                existingLastPlayed = existingSong?.lastPlayedTime ?: 0L,
                                existingLyrics = existingSong?.embeddedLyrics
                            )
                        )
                        updatedCount++
                    }
                }

                // 2. Detect removed tracks (only runs on confirmed successful scan)
                val removedIds = mutableListOf<String>()
                for (meta in currentMetaList) {
                    if (!scannedMap.containsKey(meta.mediaStoreId)) {
                        removedIds.add(meta.id)
                        removedCount++
                    }
                }

                if (removedIds.isNotEmpty()) {
                    songDao.deleteSongsByIds(removedIds)
                    playlistDao.deleteOrphanTracks()
                }

                if (songsToInsert.isNotEmpty()) {
                    songsToInsert.chunked(500).forEach { chunk ->
                        songDao.insertSongs(chunk)
                    }
                }

                // 3. Re-derive Albums, Artists, Folders strictly when real changes occurred
                val hasChanges = addedCount > 0 || updatedCount > 0 || removedCount > 0
                if (hasChanges) {
                    val allSongs = songDao.getAllSongsList()
                    updateDerivedEntities(allSongs)
                }

                val finalCount = songDao.getSongCountDirect()
                SyncResult(
                    addedCount = addedCount,
                    updatedCount = updatedCount,
                    removedCount = removedCount,
                    totalCount = finalCount,
                    isSuccess = true
                )
            }
        } catch (e: Exception) {
            SyncResult(
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "Sync transaction failed"
            )
        }
    }

    private suspend fun updateDerivedEntities(allSongs: List<SongEntity>) {
        if (allSongs.isEmpty()) {
            albumDao.deleteAllAlbums()
            artistDao.deleteAllArtists()
            folderDao.deleteAllFolders()
            return
        }

        // Derive Albums: Distinct by Title + Album Artist (fallback to artist if albumArtist is null/blank)
        val albumGroups = allSongs.groupBy { song ->
            val albumTitle = song.album.trim().lowercase()
            val effectiveArtist = (if (!song.albumArtist.isNullOrBlank()) song.albumArtist else song.artist).trim().lowercase()
            "${albumTitle}__${effectiveArtist}"
        }
        val albumEntities = albumGroups.map { (key, songs) ->
            val first = songs.first()
            val effectiveArtistName = if (!first.albumArtist.isNullOrBlank()) {
                first.albumArtist.trim()
            } else {
                first.artist.trim().ifBlank { "Unknown Artist" }
            }
            val artworkUri = if (first.albumId > 0) {
                ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"),
                    first.albumId
                ).toString()
            } else null

            AlbumEntity(
                id = key,
                title = first.album.ifBlank { "Unknown Album" },
                artist = effectiveArtistName,
                year = songs.mapNotNull { it.year }.minOrNull(),
                songCount = songs.size,
                artworkUrl = artworkUri
            )
        }

        // Derive Artists
        val artistGroups = allSongs.groupBy { it.artist.trim() }
        val artistEntities = artistGroups.map { (artistName, songs) ->
            val distinctAlbumCount = songs.map { it.album.trim().lowercase() }.distinct().size
            val first = songs.first()
            val artworkUri = if (first.albumId > 0) {
                ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"),
                    first.albumId
                ).toString()
            } else null

            ArtistEntity(
                id = artistName.ifBlank { "Unknown Artist" },
                name = artistName.ifBlank { "Unknown Artist" },
                songCount = songs.size,
                albumCount = distinctAlbumCount,
                artworkUrl = artworkUri
            )
        }

        // Derive Folders
        val folderGroups = allSongs.groupBy { it.folderPath }
        val folderEntities = folderGroups.map { (folderPath, songs) ->
            val folderFile = File(folderPath)
            FolderEntity(
                id = folderPath,
                name = folderFile.name.ifBlank { "Music" },
                path = folderPath,
                songCount = songs.size,
                parentPath = folderFile.parent
            )
        }

        albumDao.deleteAllAlbums()
        albumDao.insertAlbums(albumEntities)

        artistDao.deleteAllArtists()
        artistDao.insertArtists(artistEntities)

        folderDao.deleteAllFolders()
        folderDao.insertFolders(folderEntities)
    }

    override fun getSongsByAlbum(album: String, artist: String): Flow<List<Song>> {
        return songDao.getSongsByAlbum(album, artist)
            .map { entities -> entities.map { it.toDomainModel() } }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
    }

    override fun getSongsByArtist(artist: String): Flow<List<Song>> {
        return songDao.getSongsByArtist(artist)
            .map { entities -> entities.map { it.toDomainModel() } }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
    }

    override fun getSongsByFolder(folderPath: String): Flow<List<Song>> {
        return songDao.getSongsByFolder(folderPath)
            .map { entities -> entities.map { it.toDomainModel() } }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
    }

    override fun searchSongs(query: String): Flow<List<Song>> {
        return songDao.searchSongs(query)
            .map { entities -> entities.map { it.toDomainModel() } }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
    }

    override fun searchAlbums(query: String): Flow<List<Album>> {
        return albumDao.searchAlbums(query)
            .map { entities -> entities.map { it.toDomainModel() } }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
    }

    override fun searchArtists(query: String): Flow<List<Artist>> {
        return artistDao.searchArtists(query)
            .map { entities -> entities.map { it.toDomainModel() } }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
    }

    override fun searchFolders(query: String): Flow<List<Folder>> {
        return folderDao.searchFolders(query)
            .map { entities -> entities.map { it.toDomainModel() } }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)
    }

    override suspend fun toggleFavorite(songId: String) = withContext(Dispatchers.IO) {
        val song = songDao.getSongById(songId) ?: return@withContext
        val newFav = !song.isFavorite
        songDao.updateFavorite(songId, newFav)
    }

    override suspend fun updatePlayCount(songId: String) = withContext(Dispatchers.IO) {
        songDao.incrementPlayCount(songId, System.currentTimeMillis())
    }

    override suspend fun deleteSong(songId: String) = withContext(Dispatchers.IO) {
        songDao.deleteSongById(songId)
        playlistDao.deleteOrphanTracks()
    }
}
