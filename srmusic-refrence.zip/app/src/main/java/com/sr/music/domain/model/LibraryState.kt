package com.sr.music.domain.model

sealed class LibraryState {
    object Loading : LibraryState()
    object Initializing : LibraryState()
    object Ready : LibraryState()
    object Empty : LibraryState()
    data class Error(val message: String) : LibraryState()
}
