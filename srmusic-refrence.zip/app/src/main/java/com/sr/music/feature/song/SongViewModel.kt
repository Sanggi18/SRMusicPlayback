package com.sr.music.feature.song

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sr.music.SRMusicApplication
import com.sr.music.core.components.SortOption
import com.sr.music.domain.model.Song
import com.sr.music.domain.repository.MusicRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SongViewModel(
    private val repository: MusicRepository = SRMusicApplication.musicRepository
) : ViewModel() {

    private var rawSongs: List<Song> = emptyList()
    private val _uiState = MutableStateFlow(SongUiState())
    val uiState: StateFlow<SongUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.songs.collectLatest { songList ->
                rawSongs = songList
                applyFilterAndSort()
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        applyFilterAndSort()
    }

    fun updateSort(option: SortOption) {
        _uiState.update { it.copy(sortOption = option) }
        applyFilterAndSort()
    }

    fun toggleAscending() {
        _uiState.update { it.copy(isAscending = !it.isAscending) }
        applyFilterAndSort()
    }

    fun shuffleList() {
        _uiState.update { it.copy(songs = it.songs.shuffled()) }
    }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id)
        }
    }

    fun deleteSong(song: Song) {
        viewModelScope.launch {
            repository.deleteSong(song.id)
            _uiState.update { state ->
                val updated = state.songs.filterNot { it.id == song.id }
                state.copy(songs = updated)
            }
        }
    }

    private fun String.toSortKey(): String {
        val trimmed = this.trim()
        val first = trimmed.firstOrNull()?.uppercaseChar()
        return if (first != null && first in 'A'..'Z') {
            "0_${trimmed.lowercase()}"
        } else {
            "1_${trimmed.lowercase()}"
        }
    }

    private fun applyFilterAndSort() {
        val query = _uiState.value.searchQuery
        val sort = _uiState.value.sortOption
        val isAsc = _uiState.value.isAscending

        var list = if (query.isBlank()) {
            rawSongs
        } else {
            rawSongs.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.album.contains(query, ignoreCase = true)
            }
        }

        list = when (sort) {
            SortOption.TITLE, SortOption.NAME -> if (isAsc) list.sortedBy { it.title.toSortKey() } else list.sortedByDescending { it.title.toSortKey() }
            SortOption.ALBUM -> if (isAsc) list.sortedBy { it.album.toSortKey() } else list.sortedByDescending { it.album.toSortKey() }
            SortOption.ARTIST -> if (isAsc) list.sortedBy { it.artist.toSortKey() } else list.sortedByDescending { it.artist.toSortKey() }
            SortOption.DATE_MODIFIED -> if (isAsc) list.sortedBy { it.durationMs } else list.sortedByDescending { it.durationMs }
            SortOption.DATE_ADDED -> if (isAsc) list.sortedBy { it.year ?: 0 } else list.sortedByDescending { it.year ?: 0 }
            SortOption.DURATION -> if (isAsc) list.sortedBy { it.durationMs } else list.sortedByDescending { it.durationMs }
            SortOption.SONG_COUNT -> list
        }

        _uiState.update { it.copy(songs = list) }
    }
}
