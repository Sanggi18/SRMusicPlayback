package com.sr.music.core.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

@Composable
fun SRMusicTheme(
    themeMode: ThemeMode = ThemeMode.LIGHT,
    selectedPresetThemeId: String = "catppuccin",
    selectedPresetVariantId: String = "latte",
    catppuccinVariant: CatppuccinVariant = CatppuccinVariant.LATTE,
    amoled: Boolean = false,
    accentColor: AccentColor = AccentColor.PURPLE,
    customAccentHex: String = "#6750A4",
    dynamicColor: Boolean = false,
    fontStyle: AppFontStyle = AppFontStyle.SYSTEM_DEFAULT,
    content: @Composable () -> Unit
) {
    val systemInDark = isSystemInDarkTheme()
    val context = LocalContext.current
    val supportsDynamic = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    // Dynamic Color applies ONLY to: Follow System, Light, Dark, AMOLED
    val isDynamicAllowed = themeMode == ThemeMode.SYSTEM ||
            themeMode == ThemeMode.LIGHT ||
            themeMode == ThemeMode.DARK ||
            themeMode == ThemeMode.AMOLED

    val isDynamicActive = dynamicColor && supportsDynamic && isDynamicAllowed

    val colorScheme = when (themeMode) {
        ThemeMode.SYSTEM -> {
            if (isDynamicActive) {
                if (systemInDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            } else {
                if (systemInDark) {
                    ThemePalette.buildDark(accentColor, customAccentHex)
                } else {
                    ThemePalette.buildLight(accentColor, customAccentHex)
                }
            }
        }
        ThemeMode.LIGHT -> {
            if (isDynamicActive) {
                dynamicLightColorScheme(context)
            } else {
                ThemePalette.buildLight(accentColor, customAccentHex)
            }
        }
        ThemeMode.DARK -> {
            if (isDynamicActive) {
                dynamicDarkColorScheme(context)
            } else {
                ThemePalette.buildDark(accentColor, customAccentHex)
            }
        }
        ThemeMode.AMOLED -> {
            if (isDynamicActive) {
                dynamicDarkColorScheme(context).copy(
                    background = AmoledBg,
                    surface = AmoledSurface,
                    surfaceVariant = AmoledSurfaceVariant
                )
            } else {
                ThemePalette.buildAmoled(accentColor, customAccentHex)
            }
        }
        ThemeMode.CATPPUCCIN -> {
            val base = ThemePalette.buildCatppuccin(catppuccinVariant)
            val isDark = catppuccinVariant != CatppuccinVariant.LATTE
            ThemePalette.applyAccent(base, isDark, accentColor, customAccentHex)
        }
        ThemeMode.PRESET -> {
            val variant = ThemePresetCatalog.getVariant(selectedPresetThemeId, selectedPresetVariantId)
            val base = variant?.palette ?: ThemePalette.buildCatppuccin(catppuccinVariant)
            val isDark = variant?.isDark ?: true
            ThemePalette.applyAccent(base, isDark, accentColor, customAccentHex)
        }
    }

    val typography = remember(fontStyle) {
        createAppTypography(fontStyle.fontFamily)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = Shapes,
        content = content
    )
}
