package com.sr.music.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sr.music.SRMusicApplication
import com.sr.music.domain.model.Album
import com.sr.music.domain.model.Artist
import com.sr.music.domain.model.LibraryState
import com.sr.music.domain.model.Song
import com.sr.music.domain.repository.MusicRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repository: MusicRepository = SRMusicApplication.musicRepository
) : ViewModel() {

    private var rawRecentlyAddedSongs: List<Song> = emptyList()
    private var rawAlbums: List<Album> = emptyList()
    private var rawArtists: List<Artist> = emptyList()

    private val _uiState = MutableStateFlow(HomeUiState(libraryState = LibraryState.Loading, isLoading = true))
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                repository.artists,
                repository.albums,
                repository.recentlyAddedSongs
            ) { artists, albums, songs ->
                Triple(artists, albums, songs)
            }.collectLatest { (artists, albums, songs) ->
                rawArtists = artists
                rawAlbums = albums
                rawRecentlyAddedSongs = songs

                val state = if (artists.isEmpty() && albums.isEmpty() && songs.isEmpty()) {
                    LibraryState.Empty
                } else {
                    LibraryState.Ready
                }

                val query = _uiState.value.searchQuery
                val filteredTracks = if (query.isBlank()) {
                    rawRecentlyAddedSongs.take(15)
                } else {
                    rawRecentlyAddedSongs.filter {
                        it.title.contains(query, ignoreCase = true) ||
                        it.artist.contains(query, ignoreCase = true) ||
                        it.album.contains(query, ignoreCase = true)
                    }
                }

                _uiState.update {
                    it.copy(
                        libraryState = state,
                        isLoading = false,
                        recentArtists = rawArtists.take(10),
                        recentAlbums = rawAlbums.take(10),
                        recentTracks = filteredTracks
                    )
                }
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        updateHomeData()
    }

    private fun updateHomeData() {
        val query = _uiState.value.searchQuery
        val filteredTracks = if (query.isBlank()) {
            rawRecentlyAddedSongs.take(15)
        } else {
            rawRecentlyAddedSongs.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.album.contains(query, ignoreCase = true)
            }
        }

        _uiState.update {
            it.copy(
                recentArtists = rawArtists.take(10),
                recentAlbums = rawAlbums.take(10),
                recentTracks = filteredTracks
            )
        }
    }
}
