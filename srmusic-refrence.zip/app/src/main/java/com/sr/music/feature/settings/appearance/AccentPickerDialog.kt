package com.sr.music.feature.settings.appearance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sr.music.core.theme.AccentColor

@Composable
fun AccentPickerDialog(
    currentAccent: AccentColor,
    currentHex: String = currentAccent.hexString,
    defaultHex: String = "#6750A4",
    onAccentSelected: (AccentColor, String) -> Unit,
    onDismiss: () -> Unit
) {
    var red by remember {
        val rgb = AccentColor.parseHexToRgb(currentHex) ?: Triple(currentAccent.r, currentAccent.g, currentAccent.b)
        mutableIntStateOf(rgb.first)
    }
    var green by remember {
        val rgb = AccentColor.parseHexToRgb(currentHex) ?: Triple(currentAccent.r, currentAccent.g, currentAccent.b)
        mutableIntStateOf(rgb.second)
    }
    var blue by remember {
        val rgb = AccentColor.parseHexToRgb(currentHex) ?: Triple(currentAccent.r, currentAccent.g, currentAccent.b)
        mutableIntStateOf(rgb.third)
    }

    var hue by remember {
        val hsv = FloatArray(3)
        android.graphics.Color.RGBToHSV(red, green, blue, hsv)
        mutableFloatStateOf(hsv[0])
    }

    var hexInput by remember { mutableStateOf(formatHex(red, green, blue)) }
    val scrollState = rememberScrollState()

    val currentColor = Color(red, green, blue)
    val currentHexCalculated = formatHex(red, green, blue)
    val matchedPreset = AccentColor.fromHex(currentHexCalculated)

    // Helper to update RGB and Hue in sync
    fun updateRgbFromChannels(r: Int, g: Int, b: Int) {
        red = r.coerceIn(0, 255)
        green = g.coerceIn(0, 255)
        blue = b.coerceIn(0, 255)
        val hsv = FloatArray(3)
        android.graphics.Color.RGBToHSV(red, green, blue, hsv)
        hue = hsv[0]
        hexInput = formatHex(red, green, blue)
    }

    // Helper to update RGB from Hue slider
    fun updateFromHue(newHue: Float) {
        hue = newHue.coerceIn(0f, 360f)
        val hsv = FloatArray(3)
        android.graphics.Color.RGBToHSV(red, green, blue, hsv)
        val s = if (hsv[1] < 0.35f) 0.85f else hsv[1]
        val v = if (hsv[2] < 0.35f) 0.90f else hsv[2]
        val colorInt = android.graphics.Color.HSVToColor(floatArrayOf(hue, s, v))
        red = android.graphics.Color.red(colorInt)
        green = android.graphics.Color.green(colorInt)
        blue = android.graphics.Color.blue(colorInt)
        hexInput = formatHex(red, green, blue)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Accent Color",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(vertical = 2.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. Accent information / preview
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(72.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(currentColor)
                                .border(
                                    1.5.dp,
                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                    RoundedCornerShape(10.dp)
                                )
                                .testTag("accent_dialog_preview")
                        )

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = matchedPreset?.displayName ?: "Custom Accent",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1
                            )
                            Text(
                                text = currentHexCalculated,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            Text(
                                text = "R: $red  G: $green  B: $blue",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                maxLines = 1
                            )
                        }
                    }
                }

                // 2. Accent Color Spectrum Slider (Hue)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Hue Spectrum",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    HueSpectrumSlider(
                        hue = hue,
                        onHueChange = { updateFromHue(it) }
                    )
                }

                // 3. RGB Sliders (with − and + buttons)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "RGB Sliders",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    RgbSliderRow(
                        label = "R",
                        value = red,
                        activeColor = Color(0xFFE53935),
                        controlColor = currentColor,
                        onValueChange = { updateRgbFromChannels(it, green, blue) },
                        testTag = "slider_red"
                    )

                    RgbSliderRow(
                        label = "G",
                        value = green,
                        activeColor = Color(0xFF43A047),
                        controlColor = currentColor,
                        onValueChange = { updateRgbFromChannels(red, it, blue) },
                        testTag = "slider_green"
                    )

                    RgbSliderRow(
                        label = "B",
                        value = blue,
                        activeColor = Color(0xFF1E88E5),
                        controlColor = currentColor,
                        onValueChange = { updateRgbFromChannels(red, green, it) },
                        testTag = "slider_blue"
                    )
                }

                // 4. HEX value/input
                OutlinedTextField(
                    value = hexInput,
                    onValueChange = { input ->
                        hexInput = input
                        val parsed = AccentColor.parseHexToRgb(input)
                        if (parsed != null) {
                            red = parsed.first
                            green = parsed.second
                            blue = parsed.third
                            val hsv = FloatArray(3)
                            android.graphics.Color.RGBToHSV(red, green, blue, hsv)
                            hue = hsv[0]
                        }
                    },
                    label = { Text("HEX Color (#RRGGBB)") },
                    placeholder = { Text("#6750A4") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("accent_hex_input")
                )

                // 5. Reset to Default button
                TextButton(
                    onClick = {
                        val rgb = AccentColor.parseHexToRgb(defaultHex) ?: Triple(103, 80, 164)
                        red = rgb.first
                        green = rgb.second
                        blue = rgb.third
                        val hsv = FloatArray(3)
                        android.graphics.Color.RGBToHSV(red, green, blue, hsv)
                        hue = hsv[0]
                        hexInput = formatHex(red, green, blue)
                    },
                    modifier = Modifier
                        .align(Alignment.End)
                        .testTag("accent_dialog_reset_button")
                ) {
                    Text("Reset to Default")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalAccent = matchedPreset ?: AccentColor.PURPLE
                    onAccentSelected(finalAccent, currentHexCalculated)
                    onDismiss()
                },
                modifier = Modifier.testTag("accent_dialog_apply_button")
            ) {
                Text("Apply")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("accent_dialog_cancel_button")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun HueSpectrumSlider(
    hue: Float,
    onHueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val spectrumColors = remember {
        listOf(
            Color(0xFFFF0000), // 0° Red
            Color(0xFFFF7F00), // 30° Orange
            Color(0xFFFFFF00), // 60° Yellow
            Color(0xFF00FF00), // 120° Green
            Color(0xFF00FFFF), // 180° Cyan
            Color(0xFF0000FF), // 240° Blue
            Color(0xFF8B00FF), // 280° Purple
            Color(0xFFFF007F), // 330° Pink
            Color(0xFFFF0000)  // 360° Red
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(34.dp),
        contentAlignment = Alignment.Center
    ) {
        // Rainbow track background
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Brush.horizontalGradient(spectrumColors))
        )

        Slider(
            value = hue,
            onValueChange = onHueChange,
            valueRange = 0f..360f,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.Transparent,
                inactiveTrackColor = Color.Transparent
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("accent_spectrum_slider")
        )
    }
}

@Composable
private fun RgbSliderRow(
    label: String,
    value: Int,
    activeColor: Color,
    controlColor: Color,
    onValueChange: (Int) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        // Minus Button
        IconButton(
            onClick = { onValueChange((value - 1).coerceIn(0, 255)) },
            modifier = Modifier
                .size(32.dp)
                .testTag("${testTag}_minus")
        ) {
            Text(
                text = "−",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = controlColor
                )
            )
        }

        Text(
            text = "$label: $value",
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.width(48.dp)
        )

        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.toInt()) },
            valueRange = 0f..255f,
            colors = SliderDefaults.colors(
                thumbColor = activeColor,
                activeTrackColor = activeColor
            ),
            modifier = Modifier
                .weight(1f)
                .testTag(testTag)
        )

        // Plus Button
        IconButton(
            onClick = { onValueChange((value + 1).coerceIn(0, 255)) },
            modifier = Modifier
                .size(32.dp)
                .testTag("${testTag}_plus")
        ) {
            Text(
                text = "+",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = controlColor
                )
            )
        }
    }
}

private fun formatHex(r: Int, g: Int, b: Int): String {
    return String.format("#%02X%02X%02X", r, g, b)
}
