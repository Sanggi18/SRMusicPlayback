package com.sr.music.feature.folder

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.sr.music.core.components.EmptyState
import com.sr.music.core.components.FolderItem
import com.sr.music.core.components.SearchPill
import com.sr.music.core.components.SortBar
import com.sr.music.core.components.SortOption
import com.sr.music.core.components.VerticalFastScrollBar
import com.sr.music.domain.model.Folder

@Composable
fun FolderScreen(
    viewModel: FolderViewModel,
    onFolderClick: (Folder) -> Unit,
    onMenuClick: () -> Unit = {},
    onNavigateToEqualizer: () -> Unit = {},
    onNavigateToLyrics: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    onPlayFolder: (Folder) -> Unit = {},
    onPlayNextFolder: (Folder) -> Unit = {},
    onAddToQueueFolder: (Folder) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("folder_screen")
    ) {
        SearchPill(
            searchQuery = uiState.searchQuery,
            onQueryChange = viewModel::updateSearchQuery,
            placeholder = "Search folders...",
            onMenuClick = onMenuClick
        )

        SortBar(
            currentSort = uiState.sortOption,
            isAscending = uiState.isAscending,
            onSortChange = viewModel::updateSort,
            onToggleAscending = viewModel::toggleAscending,
            availableOptions = listOf(SortOption.NAME, SortOption.SONG_COUNT)
        )

        if (uiState.folders.isEmpty()) {
            EmptyState(
                title = "No folders found",
                subtitle = "No folders match your search query"
            )
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(uiState.folders, key = { it.id }) { folder ->
                        FolderItem(
                            folder = folder,
                            onClick = { onFolderClick(folder) },
                            onPlay = { onPlayFolder(folder) },
                            onPlayNext = { onPlayNextFolder(folder) },
                            onAddToQueue = { onAddToQueueFolder(folder) }
                        )
                    }
                }

                VerticalFastScrollBar(
                    listState = listState,
                    totalItemsCount = uiState.folders.size,
                    modifier = Modifier.align(Alignment.CenterEnd)
                )
            }
        }
    }
}
