package com.sr.music.core.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme

object ThemePalette {

    // Material You / Manual Accent Light Palette
    fun buildLight(
        accent: AccentColor = AccentColor.PURPLE,
        customHex: String = ""
    ): ColorScheme {
        val ap = AccentPalettes.getLight(accent, customHex)
        return lightColorScheme(
            primary = ap.primary,
            onPrimary = ap.onPrimary,
            primaryContainer = ap.primaryContainer,
            onPrimaryContainer = ap.onPrimaryContainer,
            secondary = ap.secondary,
            onSecondary = ap.onSecondary,
            secondaryContainer = ap.secondaryContainer,
            onSecondaryContainer = ap.onSecondaryContainer,
            tertiary = ap.tertiary,
            onTertiary = ap.onTertiary,
            tertiaryContainer = ap.tertiaryContainer,
            onTertiaryContainer = ap.onTertiaryContainer,
            background = SRMusicBgLight,
            onBackground = SRMusicOnBgLight,
            surface = SRMusicSurfaceLight,
            onSurface = SRMusicOnSurfaceLight,
            surfaceVariant = SRMusicSurfaceVariantLight,
            onSurfaceVariant = SRMusicOnSurfaceVariantLight,
            outline = SRMusicOutlineLight,
            outlineVariant = SRMusicOutlineVariantLight
        )
    }

    // Material You / Manual Accent Dark Palette
    fun buildDark(
        accent: AccentColor = AccentColor.PURPLE,
        customHex: String = ""
    ): ColorScheme {
        val ap = AccentPalettes.getDark(accent, customHex)
        return darkColorScheme(
            primary = ap.primary,
            onPrimary = ap.onPrimary,
            primaryContainer = ap.primaryContainer,
            onPrimaryContainer = ap.onPrimaryContainer,
            secondary = ap.secondary,
            onSecondary = ap.onSecondary,
            secondaryContainer = ap.secondaryContainer,
            onSecondaryContainer = ap.onSecondaryContainer,
            tertiary = ap.tertiary,
            onTertiary = ap.onTertiary,
            tertiaryContainer = ap.tertiaryContainer,
            onTertiaryContainer = ap.onTertiaryContainer,
            background = SRMusicBgDark,
            onBackground = SRMusicOnBgDark,
            surface = SRMusicSurfaceDark,
            onSurface = SRMusicOnSurfaceDark,
            surfaceVariant = SRMusicSurfaceVariantDark,
            onSurfaceVariant = SRMusicOnSurfaceVariantDark,
            outline = SRMusicOutlineDark,
            outlineVariant = SRMusicOutlineVariantDark
        )
    }

    // AMOLED Pure Black Palette (#000000)
    fun buildAmoled(
        accent: AccentColor = AccentColor.PURPLE,
        customHex: String = ""
    ): ColorScheme {
        val ap = AccentPalettes.getDark(accent, customHex)
        return darkColorScheme(
            primary = ap.primary,
            onPrimary = ap.onPrimary,
            primaryContainer = ap.primaryContainer,
            onPrimaryContainer = ap.onPrimaryContainer,
            secondary = ap.secondary,
            onSecondary = ap.onSecondary,
            secondaryContainer = ap.secondaryContainer,
            onSecondaryContainer = ap.onSecondaryContainer,
            tertiary = ap.tertiary,
            onTertiary = ap.onTertiary,
            tertiaryContainer = ap.tertiaryContainer,
            onTertiaryContainer = ap.onTertiaryContainer,
            background = AmoledBg,
            onBackground = AmoledOnBg,
            surface = AmoledSurface,
            onSurface = AmoledOnSurface,
            surfaceVariant = AmoledSurfaceVariant,
            onSurfaceVariant = AmoledOnSurfaceVariant,
            outline = AmoledOutline,
            outlineVariant = AmoledOutlineVariant
        )
    }

    // Catppuccin Flavors (Fixed official palettes)
    fun buildCatppuccin(variant: CatppuccinVariant): ColorScheme {
        return when (variant) {
            CatppuccinVariant.LATTE -> lightColorScheme(
                primary = CatppuccinLatte.Mauve,
                onPrimary = CatppuccinLatte.Base,
                primaryContainer = CatppuccinLatte.Surface1,
                onPrimaryContainer = CatppuccinLatte.Text,
                secondary = CatppuccinLatte.Lavender,
                onSecondary = CatppuccinLatte.Base,
                secondaryContainer = CatppuccinLatte.Surface0,
                onSecondaryContainer = CatppuccinLatte.Text,
                tertiary = CatppuccinLatte.Sapphire,
                onTertiary = CatppuccinLatte.Base,
                background = CatppuccinLatte.Base,
                onBackground = CatppuccinLatte.Text,
                surface = CatppuccinLatte.Mantle,
                onSurface = CatppuccinLatte.Text,
                surfaceVariant = CatppuccinLatte.Crust,
                onSurfaceVariant = CatppuccinLatte.Subtext0,
                outline = CatppuccinLatte.Overlay0,
                outlineVariant = CatppuccinLatte.Surface2
            )
            CatppuccinVariant.FRAPPE -> darkColorScheme(
                primary = CatppuccinFrappe.Mauve,
                onPrimary = CatppuccinFrappe.Base,
                primaryContainer = CatppuccinFrappe.Surface1,
                onPrimaryContainer = CatppuccinFrappe.Text,
                secondary = CatppuccinFrappe.Lavender,
                onSecondary = CatppuccinFrappe.Base,
                secondaryContainer = CatppuccinFrappe.Surface0,
                onSecondaryContainer = CatppuccinFrappe.Text,
                tertiary = CatppuccinFrappe.Sapphire,
                onTertiary = CatppuccinFrappe.Base,
                background = CatppuccinFrappe.Base,
                onBackground = CatppuccinFrappe.Text,
                surface = CatppuccinFrappe.Mantle,
                onSurface = CatppuccinFrappe.Text,
                surfaceVariant = CatppuccinFrappe.Surface0,
                onSurfaceVariant = CatppuccinFrappe.Subtext0,
                outline = CatppuccinFrappe.Overlay0,
                outlineVariant = CatppuccinFrappe.Surface2
            )
            CatppuccinVariant.MACCHIATO -> darkColorScheme(
                primary = CatppuccinMacchiato.Mauve,
                onPrimary = CatppuccinMacchiato.Base,
                primaryContainer = CatppuccinMacchiato.Surface1,
                onPrimaryContainer = CatppuccinMacchiato.Text,
                secondary = CatppuccinMacchiato.Lavender,
                onSecondary = CatppuccinMacchiato.Base,
                secondaryContainer = CatppuccinMacchiato.Surface0,
                onSecondaryContainer = CatppuccinMacchiato.Text,
                tertiary = CatppuccinMacchiato.Sapphire,
                onTertiary = CatppuccinMacchiato.Base,
                background = CatppuccinMacchiato.Base,
                onBackground = CatppuccinMacchiato.Text,
                surface = CatppuccinMacchiato.Mantle,
                onSurface = CatppuccinMacchiato.Text,
                surfaceVariant = CatppuccinMacchiato.Surface0,
                onSurfaceVariant = CatppuccinMacchiato.Subtext0,
                outline = CatppuccinMacchiato.Overlay0,
                outlineVariant = CatppuccinMacchiato.Surface2
            )
            CatppuccinVariant.MOCHA -> darkColorScheme(
                primary = CatppuccinMocha.Mauve,
                onPrimary = CatppuccinMocha.Base,
                primaryContainer = CatppuccinMocha.Surface1,
                onPrimaryContainer = CatppuccinMocha.Text,
                secondary = CatppuccinMocha.Lavender,
                onSecondary = CatppuccinMocha.Base,
                secondaryContainer = CatppuccinMocha.Surface0,
                onSecondaryContainer = CatppuccinMocha.Text,
                tertiary = CatppuccinMocha.Sapphire,
                onTertiary = CatppuccinMocha.Base,
                background = CatppuccinMocha.Base,
                onBackground = CatppuccinMocha.Text,
                surface = CatppuccinMocha.Mantle,
                onSurface = CatppuccinMocha.Text,
                surfaceVariant = CatppuccinMocha.Surface0,
                onSurfaceVariant = CatppuccinMocha.Subtext0,
                outline = CatppuccinMocha.Overlay0,
                outlineVariant = CatppuccinMocha.Surface2
            )
        }
    }

    fun applyAccent(
        base: ColorScheme,
        isDark: Boolean,
        accent: AccentColor,
        customHex: String = ""
    ): ColorScheme {
        val ap = if (isDark) AccentPalettes.getDark(accent, customHex) else AccentPalettes.getLight(accent, customHex)
        return base.copy(
            primary = ap.primary,
            onPrimary = ap.onPrimary,
            primaryContainer = ap.primaryContainer,
            onPrimaryContainer = ap.onPrimaryContainer,
            secondary = ap.secondary,
            onSecondary = ap.onSecondary,
            secondaryContainer = ap.secondaryContainer,
            onSecondaryContainer = ap.onSecondaryContainer,
            tertiary = ap.tertiary,
            onTertiary = ap.onTertiary,
            tertiaryContainer = ap.tertiaryContainer,
            onTertiaryContainer = ap.onTertiaryContainer
        )
    }
}
