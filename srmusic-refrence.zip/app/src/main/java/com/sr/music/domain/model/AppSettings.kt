package com.sr.music.domain.model

import com.sr.music.core.theme.AccentColor
import com.sr.music.core.theme.AppFontStyle
import com.sr.music.core.theme.CatppuccinVariant
import com.sr.music.core.theme.ThemeMode

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.LIGHT,
    val selectedPresetThemeId: String = "catppuccin",
    val selectedPresetVariantId: String = "latte",
    val catppuccinVariant: CatppuccinVariant = CatppuccinVariant.LATTE,
    val amoledEnabled: Boolean = false,
    val accentColor: AccentColor = AccentColor.PURPLE,
    val customAccentHex: String = "#6750A4",
    val dynamicColor: Boolean = false,
    val fontStyle: AppFontStyle = AppFontStyle.SYSTEM_DEFAULT,
    val visibleBottomTabs: List<String> = listOf("home", "song", "folder", "artist", "album"),
    val gaplessPlayback: Boolean = true,
    val crossfadeDurationSec: Int = 0,
    val isReplayGainEnabled: Boolean = false,
    val replayGainMode: String = "Track",
    val playbackSpeed: Float = 1.0f,
    val isBitPerfectEnabled: Boolean = false,
    val isEqualizerEnabled: Boolean = false,
    val preampGain: Float = 0f,
    val eqBands: List<Float> = List(10) { 0f },
    val bassBoost: Float = 0f,
    val vocalBoost: Float = 0f,
    val trebleBoost: Float = 0f,
    val preferEmbeddedArtwork: Boolean = true,
    val proceduralArtwork: Boolean = true,
    val splitMultiArtist: Boolean = true,
    val filterShortAudio: Boolean = true
)
