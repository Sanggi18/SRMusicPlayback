package com.sr.music.data.mapper

import android.content.ContentUris
import android.net.Uri
import com.sr.music.data.local.entity.SongEntity
import com.sr.music.data.mediastore.ScannedAudio
import com.sr.music.domain.model.EmbeddedLyricsFormat
import com.sr.music.domain.model.Lyrics
import com.sr.music.domain.model.Song

fun SongEntity.toDomainModel(): Song {
    val artworkUri = if (albumId > 0) {
        ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/albumart"),
            albumId
        ).toString()
    } else null

    val parsedLyrics = embeddedLyrics?.takeIf { it.isNotBlank() }?.let { text ->
        Lyrics(
            songId = id,
            format = EmbeddedLyricsFormat.UNSYNCHRONIZED,
            isSynced = false,
            plainText = text
        )
    }

    val finalUri = if (uri.isNotBlank()) {
        uri
    } else if (mediaStoreId > 0) {
        ContentUris.withAppendedId(
            Uri.parse("content://media/external/audio/media"),
            mediaStoreId
        ).toString()
    } else {
        path
    }

    return Song(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        trackNumber = trackNumber,
        artworkUrl = artworkUri,
        genre = genre,
        year = year,
        folderPath = folderPath,
        uri = finalUri,
        sampleRateHz = sampleRateHz,
        bitDepth = bitDepth,
        channelCount = channelCount,
        bitRateKbps = bitRateKbps,
        codec = codec,
        isFavorite = isFavorite,
        embeddedLyrics = parsedLyrics
    )
}

fun ScannedAudio.toEntity(
    existingFavorite: Boolean = false,
    existingPlayCount: Int = 0,
    existingLastPlayed: Long = 0L,
    existingLyrics: String? = null
): SongEntity {
    return SongEntity(
        id = mediaStoreId.toString(),
        mediaStoreId = mediaStoreId,
        uri = uri,
        title = title,
        artist = artist,
        artistId = artistId,
        album = album,
        albumId = albumId,
        albumArtist = albumArtist,
        durationMs = durationMs,
        trackNumber = trackNumber,
        discNumber = discNumber,
        year = year,
        genre = genre,
        path = path,
        folderPath = folderPath,
        size = size,
        dateAdded = dateAdded,
        dateModified = dateModified,
        mimeType = mimeType,
        sampleRateHz = sampleRateHz,
        bitDepth = bitDepth,
        channelCount = channelCount,
        bitRateKbps = bitRateKbps,
        codec = codec,
        isFavorite = existingFavorite,
        playCount = existingPlayCount,
        lastPlayedTime = existingLastPlayed,
        embeddedLyrics = existingLyrics
    )
}

fun Song.toEntity(
    mediaStoreId: Long = id.toLongOrNull() ?: 0L,
    artistId: Long = 0L,
    albumId: Long = 0L,
    albumArtist: String? = null,
    path: String = "",
    size: Long = 0L,
    dateAdded: Long = System.currentTimeMillis() / 1000,
    dateModified: Long = System.currentTimeMillis() / 1000,
    mimeType: String? = null,
    playCount: Int = 0,
    lastPlayedTime: Long = 0L
): SongEntity {
    return SongEntity(
        id = id,
        mediaStoreId = mediaStoreId,
        uri = uri,
        title = title,
        artist = artist,
        artistId = artistId,
        album = album,
        albumId = albumId,
        albumArtist = albumArtist,
        durationMs = durationMs,
        trackNumber = trackNumber,
        discNumber = 1,
        year = year,
        genre = genre,
        path = path,
        folderPath = folderPath,
        size = size,
        dateAdded = dateAdded,
        dateModified = dateModified,
        mimeType = mimeType,
        sampleRateHz = sampleRateHz,
        bitDepth = bitDepth,
        channelCount = channelCount,
        bitRateKbps = bitRateKbps,
        codec = codec,
        isFavorite = isFavorite,
        playCount = playCount,
        lastPlayedTime = lastPlayedTime,
        embeddedLyrics = embeddedLyrics?.plainText
    )
}
